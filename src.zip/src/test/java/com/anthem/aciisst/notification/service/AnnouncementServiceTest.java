package com.anthem.aciisst.notification.service;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.aciisst.persistence.dao.UserDAO;
import com.anthem.aciisst.persistence.dto.AciisstAncmntDTO;
import com.anthem.aciisst.persistence.dto.User;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AnnouncementServiceTest.class, properties = { "spring.cloud.config.enabled:false" })
public class AnnouncementServiceTest {

	@InjectMocks
	private AnnouncementService announcementService;

	/*@Mock
	AnnouncementRepository repository;*/

	@Mock
	UserDAO userRepository;

	@Before
	public void setup() {
		AciisstAncmntDTO a = new AciisstAncmntDTO();
		a.setAncmntDesc("Descption");
		a.setAncmntId(1234);
		a.setAncmntEfctvDt(new Date());
		a.setDcmntTtlShrtNm("Short Description");
		User user = new User();
		user.setUserId(1245);
		user.setUserCategoryCd("2");
		List<AciisstAncmntDTO> announcementList = Arrays.asList(a);
		/*Mockito.when(repository.getAllUserAnnouncementRead(Mockito.anyString(), Mockito.anyInt(), Mockito.anyObject(), Mockito.anyString()))
				.thenReturn(announcementList);
		Mockito.when(repository.getAllUserAnnouncement(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString()))
				.thenReturn(announcementList);
		Mockito.when(repository.getAllUserAndAccountSpecificAnnouncement(Mockito.anyString(), Mockito.anyInt(),
				Mockito.anyString(),Mockito.anyString())).thenReturn(announcementList);
		Mockito.when(repository.getAllUserAndAccountSpecificAnnouncementRead(Mockito.anyString(), Mockito.anyInt(),
				Mockito.anyString(),Mockito.anyString()))
				.thenReturn(announcementList);*/
		try {
			Mockito.when(userRepository.findByLognUserId(Mockito.anyString())).thenReturn(user);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetAllAnnouncementsSize() throws Exception {
		/*List<AnnouncementResponseView> announcements = announcementService.getAnnouncement("user", "W123");
		assertEquals(announcements.size(), announcements.size());
		assertEquals("Descption", announcements.get(0).getAncmntDescription());*/
	}

	@Test
	public void testGetAllAnnouncements() throws Exception {
		/*List<AnnouncementResponseView> announcements = announcementService.getAnnouncement("user", "W123");
		assertNotNull(announcements);*/
	}

	@Test
	public void testGetAllAlertSize() throws Exception {
	/*	List<AnnouncementResponseView> announcements = announcementService.getAlerts("user", "W123");
		assertEquals(announcements.size(), announcements.size());
		// assertEquals("Descption", announcements.get(0).getAncmntDescription());
*/	}

	@Test
	public void testGetAllAlert() throws Exception {
		/*List<AnnouncementResponseView> announcements = announcementService.getAlerts("user", "W123");
		assertNotNull(announcements);*/
	}

}
