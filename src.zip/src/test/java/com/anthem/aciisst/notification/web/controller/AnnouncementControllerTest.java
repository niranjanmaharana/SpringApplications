package com.anthem.aciisst.notification.web.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.anthem.aciisst.notification.service.AnnouncementService;
import com.anthem.aciisst.notification.web.view.response.AnnouncementResponseView;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AnnouncementController.class, properties = { "spring.cloud.config.enabled:false" })
public class AnnouncementControllerTest {

	@InjectMocks
	private AnnouncementController announcementController;

	@MockBean
	private AnnouncementService announcementService;


	private MockMvc mockMvc;

	@Before
	public void setup() {

		MockitoAnnotations.initMocks(this);

		mockMvc = MockMvcBuilders.standaloneSetup(announcementController).build();
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getGetAnnouncementsStatusCheckTest() {
		try {

			this.mockMvc.perform(get("/notification/announcement?SM_USER_ID=1944500&ACCT_ID=W123"))
					.andExpect(status().isOk());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetAnnouncements() throws Exception {

		List<AnnouncementResponseView> alertList = Arrays.asList(getAnnouncementResponse());
		Mockito.when(announcementService.getAnnouncement(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(alertList);

		String expected = "{\"status\": \"Success\",\"statusDescription\": \"Success Completed\",\"data\": [{\"ancmntId\": 50252,\"ancmntDescription\": \"Test Descp\",\"createDate\":null,\"shortDescription\": \"Short Descption\",\"fileFlag\": true}]}";

		MvcResult result = mockMvc.perform(get("/notification/announcement?SM_USER_ID=1944500&ACCT_ID=W123"))
				.andReturn();

		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);

	}

	@Test
	public void getAlertStatus() {
		try {

			this.mockMvc.perform(get("/notification/alerts?SM_USER_ID=1944500&ACCT_ID=W123"))
					.andExpect(status().isOk());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetAlerts() throws Exception {

		List<AnnouncementResponseView> alertList = Arrays.asList(getAnnouncementResponse());
		Mockito.when(announcementService.getAlerts(Mockito.anyString(), Mockito.anyString())).thenReturn(alertList);

		String expected = "{\"status\": \"Success\",\"statusDescription\": \"Success Completed\",\"data\": [{\"ancmntId\": 50252,\"ancmntDescription\": \"Test Descp\",\"createDate\":null,\"shortDescription\": \"Short Descption\",\"fileFlag\": true}]}";

		MvcResult result = mockMvc.perform(get("/notification/alerts?SM_USER_ID=1944500&ACCT_ID=W123")).andReturn();

		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);

	}

	public AnnouncementResponseView getAnnouncementResponse() throws ParseException {
		AnnouncementResponseView resp = new AnnouncementResponseView();
		resp.setAncmntDescription("Test Descp");
		resp.setAncmntId(50252);
		resp.setFileFlag(true);
		resp.setShortDescription("Short Descption");

		return resp;
	}
}
