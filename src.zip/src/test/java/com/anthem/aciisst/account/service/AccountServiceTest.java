package com.anthem.aciisst.account.service;

import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.anthem.aciisst.account.web.view.response.AccountResponseView;
import com.anthem.aciisst.persistence.dto.User;

import io.undertow.security.idm.Account;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AccountServiceTest.class, properties = { "spring.cloud.config.enabled:false" })
public class AccountServiceTest {

	@InjectMocks
	private AccountService accountService;
	/*
	@Mock
	AccountRepository repository;

	@Mock
	UserRepository userRepository;

	@Mock
	UserAccountSelectionRepository userAccountSelectionRepository;

	@Mock
	UserService userService;

	@Mock
	UserAccountAccessRepository userAccountAccessRepository;*/

	@Before
	public void setup() {
		/*Account a = new Account();
		a.setAccountId("W0020833");
		a.setAccountName("A");
		a.setAcctEfctvDt(new Date(78886867676L));
		a.setAcctTrmntnDt(new Date(7888686799999L));
		a.setSecurityLvlCode("Y");

		User user = new User();
		user.setUserId(1234);
		user.setLognUserId("1234");

		AccountResponseView accountResponse = new AccountResponseView();
		accountResponse.setAccountId("W0020833");
		accountResponse.setAccountName("ABC MEDICAREX");

		UserAcctSlctn slctn = new UserAcctSlctn();
		UserAcctSlctnPK slctnId = new UserAcctSlctnPK("W0020833", 1234);
		slctn.setId(slctnId);
		slctn.setAccount(a);

		UserAccountAccessList userAccountAccess = new UserAccountAccessList();
		userAccountAccess.setAccount(a);
		userAccountAccess.setPhiInd("Y");

		List<Account> accountList = Arrays.asList(a);// getAllAccounts getAllAccountForUser
		List<UserAcctSlctn> recentList = Arrays.asList(slctn);
		List<UserAccountAccessList> userAccountAccessList = Arrays.asList(userAccountAccess);
		Mockito.when(userAccountSelectionRepository.getRecentAccountForUser(Mockito.anyInt())).thenReturn(accountList);
		Mockito.when(repository.findUserAccounts(Mockito.anyString())).thenReturn(accountList);
		Mockito.when(userRepository.findByLognUserId(Mockito.anyString())).thenReturn(user);
		Mockito.when(userService.validateUser(Mockito.anyString())).thenReturn(true);
		Mockito.when(repository.getNotSplAccounts()).thenReturn(accountList);
		Mockito.when(userAccountAccessRepository.getInternalUserSpecialAccounts(Mockito.anyString()))
				.thenReturn(userAccountAccessList);
*/
	}

	@Test
	public void testGetUserAccounts() {
		/*

		List<AccountResponseView> accounts = accountService.getAccountofUser(getUser());
		assertEquals(0, accounts.size());*/

	}

	@Test
	public void testGetRecentlyAccesedAccountsSize() throws Exception {
		/*List<AccountResponseView> accounts = accountService.getRecentlyAccessedAccounts(getUser());
		assertEquals(1, accounts.size());*/
	}

	@Test
	public void testgetInternalUserSplAccountDrop() throws Exception {

		/*List<AccountResponseView> accounts = accountService.getInternalUserSplAccountDrop("1234");
		assertEquals(1, accounts.size());*/
	}

	@Test
	public void testUpdateRecentlyAccessedAccounts() throws Exception {
//		accountService.updateRecentlyAccessedAccounts("1234", "W0020833");
	}

	// @Test
	public void testGetRecentlyAccesedAccountsNullChcek() throws Exception {
		// Mockito.when(repository.getRecentlyAccessedAccounts(Mockito.anyString())).thenReturn(null);
		List<AccountResponseView> accounts = accountService.getRecentlyAccessedAccounts(getUser());
		assertNull(accounts);
	}

	public User getUser() {
		User user = new User();
		user.setUserId(1234);
		user.setLognUserId("1234");
		user.setUserCategoryCd("1");

		return user;
	}

	public List<Account> getMockAccount() {
		List<Account> ad = new ArrayList<>();
		/*Account ad1 = new Account();
		ad1.setAccountName("Abc");
		ad1.setAccountId("w123");
		Account ad2 = new Account();
		ad2.setAccountName("Abcdefg");
		ad2.setAccountId("w123456");

		ad.add(ad1);
		ad.add(ad2);*/

		return ad;

	}

}
