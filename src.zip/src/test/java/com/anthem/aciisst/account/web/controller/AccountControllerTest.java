package com.anthem.aciisst.account.web.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.skyscreamer.jsonassert.JSONAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.anthem.aciisst.account.service.AccountService;
import com.anthem.aciisst.account.web.view.response.AccountResponseView;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AccountController.class, properties = { "spring.cloud.config.enabled:false" })
public class AccountControllerTest {

	private static final Logger logger = LoggerFactory.getLogger(AccountControllerTest.class);

	@InjectMocks
	private AccountController accountController;

	@MockBean
	private AccountService accountService;

	private MockMvc mockMvc;

	@Before
	public void setup() {

		MockitoAnnotations.initMocks(this);

		mockMvc = MockMvcBuilders.standaloneSetup(accountController).build();

	}

	@Test
	public void testGetUserAccountsResp() throws Exception {
		List<AccountResponseView> accountList = Arrays.asList(new AccountResponseView("W00001", "Deloitte1", "R"));
		Mockito.when(accountService.getUserAccounts(Mockito.anyString())).thenReturn(accountList);

		String expected = "{\"data\":[{\"accountId\":\"W00001\",\"accountName\":\"Deloitte1\",\"key\":\"R\"}]}";

		MvcResult result = mockMvc.perform(get("/account/filter?SM_USER_ID=1234")).andReturn();

		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);

	}

	@Test
	public void testGetUserAccouts() throws Exception {
		mockMvc.perform(get("/account/filter?SM_USER_ID=1").accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());

	}

	/*
	 * @Test public void testGetRecentlyAccesedAccounts() throws Exception {
	 * List<AccountResponseView> accountList = Arrays.asList(new
	 * AccountResponseView("W00001", "Deloitte1", "R"));
	 * Mockito.when(accountService.getRecentlyAccessedAccounts(Mockito.anyString()))
	 * .thenReturn(accountList);
	 * 
	 * String expected =
	 * "{\"data\":[{\"accountId\":\"W00001\",\"accountName\":\"Deloitte1\"}]}";
	 * 
	 * MvcResult result =
	 * mockMvc.perform(get("/filter/account/recentlyAccessed?USER_ID=1")).andReturn(
	 * );
	 * 
	 * JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(),
	 * false);
	 * 
	 * }
	 * 
	 * @Test public void testGetRecentlyAccesedAccountsStatusCheck() throws
	 * Exception {
	 * mockMvc.perform(get("/filter/account/recentlyAccessed?USER_ID=1").accept(
	 * MediaType.APPLICATION_JSON)) .andExpect(status().isOk());
	 * 
	 * }
	 */

}
