package com.anthem.aciisst.user.web.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.skyscreamer.jsonassert.JSONAssert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.anthem.aciisst.user.service.UserService;
import com.anthem.aciisst.user.web.view.response.UserResponse;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = UserController.class, properties = { "spring.cloud.config.enabled:false" })
public class UserControllerTest {
	private static final Logger logger = LoggerFactory.getLogger(UserControllerTest.class);

	@InjectMocks
	UserController userController;

	@MockBean
	UserService userService;

	private MockMvc mockMvc;

	@Before
	public void setup() {

		MockitoAnnotations.initMocks(this);

		mockMvc = MockMvcBuilders.standaloneSetup(userController).build();

	}

	public void testGetUserAccounts() throws Exception {
		mockMvc.perform(get("/user/details?SM_USER_ID=1234").accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}

	@Test
	public void testGetUserAccountsResp() throws Exception {
		UserResponse user = new UserResponse(1234, "frst name", "last name", "1");
		Mockito.when(userService.getUserDetails(Mockito.anyString())).thenReturn(user);

		String expected = "{\"data\":{\"userId\":1234,\"fname\":\"frst name\",\"lname\":\"last name\",\"userCategoryCd\":\"1\"}}";

		MvcResult result = mockMvc.perform(get("/user/details?SM_USER_ID=1234")).andReturn();

		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);

	}

}
