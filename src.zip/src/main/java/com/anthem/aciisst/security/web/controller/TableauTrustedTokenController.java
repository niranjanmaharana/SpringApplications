package com.anthem.aciisst.security.web.controller;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.common.web.view.ResponseView;
import com.anthem.aciisst.persistence.dao.AppPropertyDAO;
import com.anthem.aciisst.persistence.dto.AppPropertyDTO;


/**
 * @author AF72803
 *
 */
@CrossOrigin
@RestController
@RequestMapping("tableau")
public class TableauTrustedTokenController {

	@Autowired
	AppPropertyDAO appPropertyDAO;
	
	/**
	 * service will get User Details from the Logn UserId
	 * 
	 * @param userId
	 * @return
	 */
	@Value("${tableau.service.id}")
    private String tabid;
	
	@RequestMapping(method = RequestMethod.GET, value = "/trustedtoken")
	public ResponseView<String> getTrustedToken(@RequestParam("ENV") String environment, HttpServletRequest httpRequest) {
		ResponseView<String> responseView = new ResponseView<>();
		String token ;
		
		//Constants --> these needs to be externalized
		String tabUrl = null;
			
		AppPropertyDTO tableauUrlPrpty = null;
		try {
			tableauUrlPrpty = appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.TABLEAU_URL_PRPTY_NM);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if (!ObjectUtils.isEmpty(tableauUrlPrpty)) {
			tabUrl = tableauUrlPrpty.getAciisstPrptyValTxt();
		}
		
		try {
			
			token = getTrustedTicket(tabUrl,tabid,"", httpRequest);  
			responseView.setData(token);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId( ACIISSTConstants.NA);
			logDetail.setUserId( environment);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
		}

		return responseView;
	}
	
    private String getTrustedTicket(String wgserver, String user, String remoteAddr, HttpServletRequest httpRequest) 
    		throws Exception{
    	LogDetail logDetail = new LogDetail();
		logDetail.setAccountId( ACIISSTConstants.NA);
		logDetail.setUserId( user);
		logDetail.setUri(httpRequest.getRequestURI());
		logDetail.setSystem(ACIISSTConstants.SYSTEM);
		LoggingUtil.logInfo(this.getClass(),logDetail);

        try {
            // Encode the parameters
            StringBuilder data = new StringBuilder();
            data.append(URLEncoder.encode("username", ACIISSTConstants.UTF8));
            data.append("=");
            data.append(URLEncoder.encode(user, ACIISSTConstants.UTF8));
            data.append("&");
            data.append(URLEncoder.encode("client_ip", ACIISSTConstants.UTF8));
            data.append("=");
            data.append(URLEncoder.encode(remoteAddr, ACIISSTConstants.UTF8));

            URL url = new URL(wgserver + ACIISSTConstants.TRUSTED);
            // Send the request
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            try(OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());){
            	out.write(data.toString());
            	out.flush();            	
            }

            // Read the response
            StringBuilder rsp = new StringBuilder();
           try(BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));){
        	   String line;
        	   while ( (line = in.readLine()) != null) {
        		   rsp.append(line);
        	   }
           }
            LogDetail logDetail1 = new LogDetail();
    		logDetail1.setAccountId( ACIISSTConstants.NA);
    		logDetail1.setUserId( user);
    		logDetail1.setUri( "TrustedTicket : " + rsp.toString());
    		logDetail1.setSystem(ACIISSTConstants.SYSTEM);
    		LoggingUtil.logInfo(this.getClass(),logDetail1);

    		if (rsp.toString().equals("-1")) {
            	throw new Exception("Exception while getting TrustedTicket");
            }
            else
            	return rsp.toString();

        } catch (Exception e) {
        	 LogDetail logDetail1 = new LogDetail();
     		logDetail1.setAccountId( ACIISSTConstants.NA);
     		logDetail1.setUserId( user);
     		logDetail1.setUri( "getTrustedTicket() ");
     		logDetail1.setSystem(ACIISSTConstants.SYSTEM);
            LoggingUtil.logError(this.getClass(), logDetail1, e);
        	throw e;
        }       
    }

    private String getTrustedTicketWithSite(String wgserver, String user, String remoteAddr, String siteid, HttpServletRequest httpRequest) 
    		throws Exception{
    	LogDetail logDetail1 = new LogDetail();
 		logDetail1.setAccountId( ACIISSTConstants.NA);
 		logDetail1.setUserId( user);
 		logDetail1.setUri(httpRequest.getRequestURI() + " user -  " + user + " wgserver : " + wgserver + " siteid : " + siteid);
 		logDetail1.setSystem(ACIISSTConstants.SYSTEM);
		LoggingUtil.logInfo(this.getClass(),logDetail1 );
		
        try {
            // Encode the parameters
            StringBuilder data = new StringBuilder();
            data.append(URLEncoder.encode("username", ACIISSTConstants.UTF8));
            data.append("=");
            data.append(URLEncoder.encode(user, ACIISSTConstants.UTF8));
            data.append("&");
            data.append(URLEncoder.encode("client_ip", ACIISSTConstants.UTF8));
            data.append("=");
            data.append(URLEncoder.encode(remoteAddr, ACIISSTConstants.UTF8));
            data.append("&");
            data.append(URLEncoder.encode("target_site", ACIISSTConstants.UTF8));
            data.append("=");
            data.append(URLEncoder.encode(siteid, ACIISSTConstants.UTF8));

            // Send the request
            URL url = new URL(wgserver + ACIISSTConstants.TRUSTED);
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
           try(OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());){
        	   out.write(data.toString());
        	   out.flush();
           }

            // Read the response
            StringBuilder rsp = new StringBuilder();
           try( BufferedReader  in = new BufferedReader(new InputStreamReader(conn.getInputStream()));){
        	   String line;
        	   while ( (line = in.readLine()) != null) {
        		   rsp.append(line);
        	   }
           }

    		if (rsp.toString().equals("-1")) {
    			throw new Exception("Exception while getting TrustedTicket");
            	 
            }
            else
            	return rsp.toString();

        } catch (Exception e) {
        	LogDetail logDetail = new LogDetail();
			logDetail.setAccountId( ACIISSTConstants.NA);
			logDetail.setUserId(  ACIISSTConstants.SYSTEM);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
        	throw e;
        }
    }

}
