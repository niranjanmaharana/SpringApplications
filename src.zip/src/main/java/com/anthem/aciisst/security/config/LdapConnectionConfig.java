package com.anthem.aciisst.security.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class LdapConnectionConfig {
	@Value("${ldap.url}")
    private String ldapUrl;

	@Value("${ldap.search.base}")
    private String ldapBase;

	@Value("${ldap.search.filter}")
    private String ldapFilter;

	@Value("${ldap.manager.dn}")
    private String managerDn;

	@Value("${ldap.manager.password}")
    private String managerPassword;
	
	@Value("${ldap.timeout}")
	String ldapTimeout;
	
	@Value("${ldap.minPoolSize}")
	Integer ldapMinPoolSize;
	
	@Value("${ldap.maxPoolSize}")
	Integer ldapMaxPoolSize;
	
	@Value("${ldap.poolExp}")
	Integer ldapPoolExp;

	public String getLdapUrl() {
		return ldapUrl;
	}

	public void setLdapUrl(String ldapUrl) {
		this.ldapUrl = ldapUrl;
	}

	public String getLdapBase() {
		return ldapBase;
	}

	public void setLdapBase(String ldapBase) {
		this.ldapBase = ldapBase;
	}

	public String getLdapFilter() {
		return ldapFilter;
	}

	public void setLdapFilter(String ldapFilter) {
		this.ldapFilter = ldapFilter;
	}

	public String getManagerDn() {
		return managerDn;
	}

	public void setManagerDn(String managerDn) {
		this.managerDn = managerDn;
	}

	public String getManagerPassword() {
		return managerPassword;
	}

	public void setManagerPassword(String managerPassword) {
		this.managerPassword = managerPassword;
	}

	public String getLdapTimeout() {
		return ldapTimeout;
	}

	public void setLdapTimeout(String ldapTimeout) {
		this.ldapTimeout = ldapTimeout;
	}

	public Integer getLdapMinPoolSize() {
		return ldapMinPoolSize;
	}

	public void setLdapMinPoolSize(Integer ldapMinPoolSize) {
		this.ldapMinPoolSize = ldapMinPoolSize;
	}

	public Integer getLdapMaxPoolSize() {
		return ldapMaxPoolSize;
	}

	public void setLdapMaxPoolSize(Integer ldapMaxPoolSize) {
		this.ldapMaxPoolSize = ldapMaxPoolSize;
	}

	public Integer getLdapPoolExp() {
		return ldapPoolExp;
	}

	public void setLdapPoolExp(Integer ldapPoolExp) {
		this.ldapPoolExp = ldapPoolExp;
	}

}
