package com.anthem.aciisst.security.config;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.anthem.aciisst.security.handler.AppLogoutSuccessHandler;
import com.anthem.aciisst.security.handler.AuthTokenFilter;
import com.anthem.aciisst.security.handler.UnauthorizedHandler;
import com.anthem.aciisst.security.handler.UserInfoMapper;


@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	AppLogoutSuccessHandler appLogoutSuccessHandler;

	@Autowired
	private UnauthorizedHandler unauthorizedHandler;

	@Autowired
	UserInfoMapper userInfoMapper;
	
	@Autowired
	private DefaultSpringSecurityContextSource context;

	@Value("${ldap.search.filter}")
    private String ldapFilter;
	
	@Value("${ldap.search.base}")
    private String ldapBase;
	
	@Value("#{'${allowedOrigins}'.split(',')}")
	private List<String> allowedOrigins;
	
	@Value("#{'${allowedHeaders}'.split(',')}")
	private List<String> allowedHeaders;
	
	@Bean
	public AuthTokenFilter authTokenFilter(){
		return new AuthTokenFilter();
	}

	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {
			httpSecurity
			.cors()
				.and()
			.csrf()
				.disable()
			.exceptionHandling()
				.authenticationEntryPoint(unauthorizedHandler)
				.and()
			.sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and()
			.headers()
				.frameOptions().sameOrigin()
				.and()
			.authorizeRequests()
				.antMatchers(
					"/user/login/**",
					"/health/**",
					"/env/**"
					).permitAll()
				.anyRequest()
					.authenticated();

		httpSecurity
			.addFilterBefore(authTokenFilter(), UsernamePasswordAuthenticationFilter.class);

	}

	@Autowired
	@Override
	public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {

		authenticationManagerBuilder
			.ldapAuthentication()
				//.userSearchBase(ldapBase)
				.userSearchFilter(ldapFilter)
				.userDetailsContextMapper(userInfoMapper)
				.contextSource(context);
	}

	@Bean
	CorsConfigurationSource corsConfigurationSource() {

		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		CorsConfiguration configuration = new CorsConfiguration();
		//configuration.setAllowCredentials(true);
    	configuration.setAllowedMethods(Arrays.asList("POST", "OPTIONS", "GET", "DELETE", "PUT"));
    	configuration.setAllowedHeaders(allowedHeaders);
    	configuration.setAllowedOrigins(allowedOrigins);
		source.registerCorsConfiguration("/**", configuration);

		return source;
	}
	
	@Bean
	@Autowired
	public DefaultSpringSecurityContextSource createContextSource(LdapConnectionConfig config) {
		DefaultSpringSecurityContextSource contextSource = new DefaultSpringSecurityContextSource(config.getLdapUrl());
		
		contextSource.setUserDn(config.getManagerDn());
		contextSource.setPassword(config.getManagerPassword());
		
		return contextSource;
	}
}
