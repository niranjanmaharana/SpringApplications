package com.anthem.aciisst.security.web.controller;

import java.security.Principal;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedHashSet;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.account.service.UserSegmentService;
import com.anthem.aciisst.account.web.view.response.BaseAccountStructureDTO;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.common.web.view.ResponseView;
import com.anthem.aciisst.security.dto.AppUser;
import com.anthem.aciisst.security.util.TokenUtil;
import com.anthem.aciisst.security.web.request.AuthRequest;
import com.anthem.aciisst.security.web.response.AuthResponse;
import com.anthem.aciisst.security.web.response.InvalidUserResponse;
import com.anthem.aciisst.user.dto.UserDTO;
import com.anthem.aciisst.user.service.UserService;


@RestController
@RequestMapping("user")
public class AuthController {

	@Autowired
	private TokenUtil tokenUtil;

	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserSegmentService userSegmentService;
	
	private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody AuthRequest request) {
		
		boolean isValidUser = false;
		try{
				isValidUser = userService.validateActiveUser(request.getUsername());
		}catch(Exception e){
			return ResponseEntity.ok(new InvalidUserResponse(System.currentTimeMillis(), "500", "Internal Server Error", "Please try after sometime", "/login"));

		}
		
		if(!isValidUser){
			return ResponseEntity.ok(new InvalidUserResponse(System.currentTimeMillis(), "401", "Unauthorized", "Access Denied", "/login"));
		}

		Authentication authentication = authenticationManager.authenticate(
			new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
		);

		String token = tokenUtil.generateToken((AppUser) authentication.getPrincipal());
		
		LoggingUtil.logInfo(this.getClass(), new LogDetail(request.getUsername(), ACIISSTConstants.NA, "/login"));

		return ResponseEntity.ok(new AuthResponse(token));
	}

	@PostMapping("/logout")
	public ResponseView<String> logout(@RequestBody BaseAccountStructureDTO request, HttpServletRequest httpRequest, Principal principal) {
		ResponseView<String> responseView = new ResponseView<>();
		AppUser user = (AppUser) ((Authentication)principal).getPrincipal();
		int userIdInt = user.getUserIdInt();
		String sessionId = request.getSessionKey();

		try {
			userSegmentService.deleteFromUserSegment(sessionId, userIdInt);
			
			responseView.setData(user.getFirstName() + " successfully logged out.");
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (SQLException e) {
			LoggingUtil.logError(this.getClass(), new LogDetail(principal.getName(), ACIISSTConstants.NA, httpRequest.getRequestURI()), e);
			
			responseView.setData("User logged out. Error deleting user segment records.");
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
		}

		return responseView;
	}
	
	@PostMapping("/token")
	public ResponseEntity<AuthResponse> token() {

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String token = tokenUtil.generateToken((AppUser) authentication.getPrincipal());

		return ResponseEntity.ok(new AuthResponse(token));
	}
	
	@PostMapping("/auth")
	public ResponseEntity<?> authorizeuser(HttpServletRequest request) throws SQLException {
		
		boolean isValidUser = false;
		String userName, firstName="", lastName="", domain=ACIISSTConstants.EMPTY_BLANK_STRING;
		// this would work for internal users, we get below info in req header. But for the external user it will pass through the parameters
		
		// internal user path
		userName   = request.getHeader(ACIISSTConstants.SM_USER);
		if (userName != null) {
			if (userName.contains(ACIISSTConstants.WORKNET_USER_PREFIX)) {
				userName = userName.replace(ACIISSTConstants.WORKNET_USER_PREFIX, "");
			}
			firstName = request.getHeader(ACIISSTConstants.SM_FIRST_NAME);
			lastName  = request.getHeader(ACIISSTConstants.SM_LAST_NAME);
		}
		LogDetail logDetail = new LogDetail();
		logDetail.setAccountId("auth call");
		logDetail.setUserId(userName);
		logDetail.setUri(request.getRequestURI());
		logDetail.setSystem(ACIISSTConstants.SYSTEM);
		LoggingUtil.logInfo(this.getClass(),logDetail);
		logger.debug("User id: {} FirstName: {} lastName: {}", userName, firstName, lastName);
		
		try{
			isValidUser = userService.validateActiveUser(userName);
		}catch(Exception e){
			return ResponseEntity.ok(new InvalidUserResponse(System.currentTimeMillis(), "500", "Internal Server Error", "Please try after sometime", "/login"));

		}
		
		if(!isValidUser){
			return ResponseEntity.ok(new InvalidUserResponse(System.currentTimeMillis(), "401", "Unauthorized", "Access Denied", "/auth"));
		}
/*
		Authentication authentication = authenticationManager.authenticate(
			new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
		);
*/
		
		String token = tokenUtil.generateToken(getUserDetails(userName));

		return ResponseEntity.ok(new AuthResponse(token));
	}

	
	public AppUser getUserDetails(String userId) throws SQLException {

		UserDTO user = userService.getUserInfo(userId);
		try {
			
			AppUser appUser = new AppUser();
			appUser.setUsername(userId.toUpperCase());
			if(user != null){
				appUser.setUserIdInt(user.getUserIdInt());
				appUser.setUserCategory(user.getUserCategory());
				appUser.setFirstName(parseAttribute(user.getFirstName()));
				appUser.setLastName(parseAttribute(user.getLastName()));
				appUser.setEmail(parseAttribute(user.getEmailAddress()));
				
				Collection<GrantedAuthority> userRoles = new LinkedHashSet<>();
				userRoles.add(new SimpleGrantedAuthority(user.getUserCategory()));
					for(String role: user.getUserRoles()){
						userRoles.add(new SimpleGrantedAuthority(role));
					}
				appUser.setAuthorities(userRoles);
			}
			appUser.setPhone(ACIISSTConstants.EMPTY_BLANK_STRING);

			return appUser;
		}
		catch (Exception e) {
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId( ACIISSTConstants.NA);
			logDetail.setUserId(userId);
			logDetail.setUri("auth getUserDetails");
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}

		return null;
	}
	
	private String parseAttribute(String s) {

		return (s != null) ? s : "*";
	}
}
