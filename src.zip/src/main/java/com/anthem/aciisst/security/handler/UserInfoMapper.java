package com.anthem.aciisst.security.handler;

import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.ldap.userdetails.LdapUserDetailsMapper;
import org.springframework.stereotype.Component;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.security.dto.AppUser;
import com.anthem.aciisst.user.dto.UserDTO;
import com.anthem.aciisst.user.service.UserService;


@Component
public class UserInfoMapper extends LdapUserDetailsMapper {
	
	@Autowired
	UserService userService;
	
	@Override
	public AppUser mapUserFromContext(DirContextOperations ctx, String userId, Collection<? extends GrantedAuthority> authorities) {

		UserDetails ldapUser = super.mapUserFromContext(ctx, userId, authorities);

		UserDTO user = null;
		try {
			user = userService.getUserInfo(userId);
		} catch (SQLException e) {
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId( ACIISSTConstants.NA);
			logDetail.setUserId(userId);
			logDetail.setUri("mapUserFromContext");
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}

		AppUser appUser = new AppUser();
		appUser.setUsername(ldapUser.getUsername().toUpperCase());
		appUser.setJti(UUID.randomUUID().toString());
		if(user != null){
			appUser.setUserIdInt(user.getUserIdInt());
			appUser.setUserCategory(user.getUserCategory());
			appUser.setFirstName(parseAttribute(user.getFirstName()));
			appUser.setLastName(parseAttribute(user.getLastName()));
			appUser.setEmail(parseAttribute(user.getEmailAddress()));
			
			Collection<GrantedAuthority> userRoles = new LinkedHashSet<>();
			userRoles.add(new SimpleGrantedAuthority(user.getUserCategory()));
				for(String role: user.getUserRoles()){
					userRoles.add(new SimpleGrantedAuthority(role));
				}
			appUser.setAuthorities(userRoles);
		}
		appUser.setPhone(parseAttribute(ctx.getStringAttribute("telephoneNumber")));

		return appUser;

	}

	private String parseAttribute(String s) {

		return (s != null) ? s : "*";
	}
}
