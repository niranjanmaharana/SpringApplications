package com.anthem.aciisst.security.util;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.anthem.aciisst.security.dto.AppUser;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Clock;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.DefaultClock;


@Component
public class TokenUtil {

	@Value("${jwt.secret}")
	private String secret;

	@Value("${jwt.expiration}")
	private Long expiration;

	private Clock clock = DefaultClock.INSTANCE;

	public String getUsernameFromToken(String token) {
		return getClaimFromToken(token, Claims::getSubject);
	}

	public Date getIssuedAtDateFromToken(String token) {
		return getClaimFromToken(token, Claims::getIssuedAt);
	}

	public Date getExpirationDateFromToken(String token) {
		return getClaimFromToken(token, Claims::getExpiration);
	}

	public String getAudienceFromToken(String token) {
		return getClaimFromToken(token, Claims::getAudience);
	}

	public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {

		final Claims claims = getAllClaimsFromToken(token);
		return claimsResolver.apply(claims);
	}

	private Claims getAllClaimsFromToken(String token) {

		return Jwts.parser()
				.setSigningKey(secret)
				.parseClaimsJws(token)
				.getBody();
	}

	private Boolean isTokenExpired(String token) {

		final Date expirationDate = getExpirationDateFromToken(token);
		return expirationDate.before(clock.now());
	}

	public String generateToken(UserDetails userDetails) {

		Map<String, Object> claims = new HashMap<>();
		AppUser user = (AppUser) userDetails;

		claims.put("firstName", user.getFirstName());
		claims.put("lastName", user.getLastName());
		claims.put("email", user.getEmail());
		claims.put("phone", user.getPhone());
		claims.put("userIdInt", user.getUserIdInt());
		claims.put("userCategoryCd", user.getUserCategory());
		claims.put("jti", user.getJti());
		claims.put("authorities", user.getAuthorities().stream().map(s -> s.toString()).collect(Collectors.toList()));

		return doGenerateToken(claims, user.getUsername());
	}

	private String doGenerateToken(Map<String, Object> claims, String subject) {

		final Date createdDate = clock.now();
		final Date expirationDate = calculateExpirationDate(createdDate);

		return Jwts.builder()
				.setClaims(claims)
				.setSubject(subject)
				.setIssuedAt(createdDate)
				.setExpiration(expirationDate)
				.signWith(SignatureAlgorithm.HS512, secret)
				.compact();
	}

	private Date calculateExpirationDate(Date createdDate) {
		return new Date(createdDate.getTime() + expiration * 1000);
	}

	public Boolean validateToken(String token, UserDetails userDetails) {

		final String username = getUsernameFromToken(token);

		return (
			username.equals(userDetails.getUsername())
				&& !isTokenExpired(token)
		);
	}

	public UserDetails getUserDetailsFromToken(String token) {

		final Claims claims = getAllClaimsFromToken(token);

		AppUser user = new AppUser();
		user.setUsername(claims.getSubject());
		user.setFirstName(claims.get("firstName").toString());
		user.setLastName(claims.get("lastName").toString());
		user.setEmail(claims.get("email").toString());
		user.setPhone(claims.get("phone").toString());
		user.setUserIdInt(Integer.parseInt(claims.get("userIdInt").toString()));
		user.setUserCategory(claims.get("userCategoryCd").toString());
		user.setJti(claims.get("jti").toString());
		@SuppressWarnings("unchecked")
		List<String> privs = (List<String>) claims.get("authorities");

		Collection<GrantedAuthority> authorities = new HashSet<>();
		for (String priv : privs) {
			authorities.add(new SimpleGrantedAuthority(priv));
		}

		user.setAuthorities(authorities);

		return user;
	}
}
