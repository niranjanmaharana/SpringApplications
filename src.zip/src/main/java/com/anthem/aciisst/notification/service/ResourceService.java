package com.anthem.aciisst.notification.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.notification.web.view.response.ResourceResponseView;
import com.anthem.aciisst.persistence.dao.AciisstRsrcMtrlDAO;
import com.anthem.aciisst.persistence.dao.FileTypeCodeDAO;
import com.anthem.aciisst.persistence.dao.UserDAO;
import com.anthem.aciisst.persistence.dto.AciisstFileCntntTypeDTO;
import com.anthem.aciisst.persistence.dto.AciisstRsrcMtrlDTO;
import com.anthem.aciisst.persistence.dto.User;



/**
 * @author AF95039 
 * AdditionalResourceService Service class to handle business logic
 *         for Additional Resources
 */
@Service
public class ResourceService {
	
	private static final Logger logger = LoggerFactory.getLogger(ResourceService.class);
	
	@Autowired
	UserDAO userDao;
	
	@Autowired
	AciisstRsrcMtrlDAO aciisstRsrcMtrlDAO;
	
	@Autowired
	FileTypeCodeDAO fileTypeCodeDAO;
	
	
	/**
	 * Fetch the Resources from the database
	 * @param userId
	 * @return
	 * @throws SQLException
	 */
	public List<ResourceResponseView> getResources(String userId) throws SQLException{
		User user = userDao.findByLognUserId(userId);
		String ctgrycd=user.getUserCategoryCd();
		List<ResourceResponseView> responseList = new ArrayList<>();	
		prepareResourceResponse((aciisstRsrcMtrlDAO.getAllUserResources(ctgrycd)),responseList);
		logger.debug("Additional Resource List size - {}", responseList.size());
		
		return responseList;
	}


	/**
	 * Prepare the Response for the Resource Requests
	 * @param resrcList
	 * @param responseList
	 */
	private void prepareResourceResponse(List<AciisstRsrcMtrlDTO> resrcList, List<ResourceResponseView> responseList) {
		ResourceResponseView addRsrcView;
		for(AciisstRsrcMtrlDTO rsrcMtrl:resrcList){
			addRsrcView= new ResourceResponseView();
			addRsrcView.setRscId(rsrcMtrl.getRscId());
			addRsrcView.setRscMtrlNm(rsrcMtrl.getRscMtrlNm());
			addRsrcView.setRscMtrlTxt(rsrcMtrl.getRscMtrlTxt());
			addRsrcView.setCreateDate(rsrcMtrl.getRscEfctvDt());
			addRsrcView.setRscCtgryCD(rsrcMtrl.getRscCtgryCd());
			addRsrcView.setRscShrtNm(rsrcMtrl.getRscCtgryShrtNm());
			addRsrcView.setFileName(rsrcMtrl.getFileNm());
			addRsrcView.setFileDcmnt(rsrcMtrl.getFileDcmnt());
			responseList.add(addRsrcView);
		}
		
	}


	/**
	 * fetch the resource from the database based on the resourceID 
	 * @param rsrcId
	 * @return
	 * @throws NumberFormatException
	 * @throws SQLException
	 */
	public ResourceResponseView getNotificationdocument(String rsrcId)throws NumberFormatException, SQLException {
		ResourceResponseView rsrcView=new ResourceResponseView();
		AciisstRsrcMtrlDTO aciisstRsrcMtrlDTO=aciisstRsrcMtrlDAO.getResource(Integer.parseInt(rsrcId));
		if(aciisstRsrcMtrlDTO!=null){
			AciisstFileCntntTypeDTO aciisstFileCntntType=fileTypeCodeDAO.findFileTypeCode(aciisstRsrcMtrlDTO.getFileCntntTypeCd());
			String contentTypeCode = ObjectUtils.isEmpty(aciisstFileCntntType)?ACIISSTConstants.EMPTY_BLANK_STRING: aciisstFileCntntType.getFileCntntTypeCd();
			rsrcView.setRscId(aciisstRsrcMtrlDTO.getRscId());
			rsrcView.setFileName(aciisstRsrcMtrlDTO.getFileNm()+ACIISSTConstants.EXTN_SEPERATOR+contentTypeCode.trim().toLowerCase());
			rsrcView.setContentType(ObjectUtils.isEmpty(aciisstFileCntntType)?ACIISSTConstants.EMPTY_BLANK_STRING: aciisstFileCntntType.getFileCntntTypeDesc());
			rsrcView.setFileDcmnt(aciisstRsrcMtrlDTO.getFileDcmnt());
		}
		return rsrcView;
		
	}

}
