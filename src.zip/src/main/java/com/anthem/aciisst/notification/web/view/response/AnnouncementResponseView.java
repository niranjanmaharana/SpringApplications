package com.anthem.aciisst.notification.web.view.response;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties
public class AnnouncementResponseView {

	private Integer ancmntId;
	private String ancmntDescription;
	private Date createDate;
	private String shortDescription;
	private Boolean fileFlag;
	private String receipt;
	@JsonIgnore
	private String contentType;
	@JsonIgnore
	private String fileName;
	@JsonIgnore
	private byte[] fileDcmnt;

	public Integer getAncmntId() {
		return ancmntId;
	}

	public void setAncmntId(Integer ancmntId) {
		this.ancmntId = ancmntId;
	}

	public String getAncmntDescription() {
		return ancmntDescription;
	}

	public void setAncmntDescription(String ancmntDescription) {
		this.ancmntDescription = ancmntDescription;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public Boolean getFileFlag() {
		return fileFlag;
	}

	public void setFileFlag(Boolean fileFlag) {
		this.fileFlag = fileFlag;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getFileDcmnt() {
		return fileDcmnt;
	}

	public void setFileDcmnt(byte[] fileDcmnt) {
		this.fileDcmnt = fileDcmnt;
	}

}
