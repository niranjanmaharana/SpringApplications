package com.anthem.aciisst.notification.service;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.notification.web.view.response.AnnouncementResponseView;
import com.anthem.aciisst.persistence.dao.AnnouncementDAO;
import com.anthem.aciisst.persistence.dao.FileTypeCodeDAO;
import com.anthem.aciisst.persistence.dao.UserDAO;
import com.anthem.aciisst.persistence.dto.AciisstAncmntDTO;
import com.anthem.aciisst.persistence.dto.AciisstFileCntntTypeDTO;
import com.anthem.aciisst.persistence.dto.AciisstUserAncmntReadDTO;
import com.anthem.aciisst.persistence.dto.User;

/**
 * @author AF48929 AnnouncementService Service class to handle business logic
 *         for announcements and alerts.
 *
 */
@Service
public class AnnouncementService {

	private static final Logger logger = LoggerFactory.getLogger(AnnouncementService.class);

	@Autowired
	AnnouncementDAO announcementRepository;

	@Autowired
	UserDAO userRepository;

	
	@Autowired
	FileTypeCodeDAO fileTypeCodeDAO;

	/**
	 * Gets Announcement from the DB
	 * 
	 * @param userId
	 * @param accountId
	 * @return Announcement List
	 * @throws SQLException 
	 */
	public List<AnnouncementResponseView> getAnnouncement(String userId, String accountId) throws SQLException {
		User user = userRepository.findByLognUserId(userId);
		String ctgrycd = user.getUserCategoryCd();
		int ciiUserId = user.getUserId();

		List<AnnouncementResponseView> responseList = new ArrayList<>();
		List<AciisstAncmntDTO> announcementList = new ArrayList<>();
		String alertInd = "N";
		if (StringUtils.isEmpty(accountId)) {
			prepareResponseDto(announcementRepository.getAllUserAnnouncement(ctgrycd, ciiUserId, alertInd),
					ACIISSTConstants.RECEIPT_UNREAD, responseList);
			prepareResponseDto(announcementRepository.getAllUserAnnouncementRead(ctgrycd, ciiUserId, alertInd),
					ACIISSTConstants.RECEIPT_READ, responseList);
			logger.debug("Announcement  List size - {}", announcementList.size());
		} else {
			prepareResponseDto(announcementRepository.getAllUserAndAccountSpecificAnnouncement(ctgrycd, ciiUserId, accountId, alertInd), 
					ACIISSTConstants.RECEIPT_UNREAD, responseList);
			prepareResponseDto(announcementRepository.getAllUserAndAccountSpecificAnnouncementRead(ctgrycd, ciiUserId, accountId, alertInd),
					ACIISSTConstants.RECEIPT_READ, responseList);

			logger.debug("Announcement List size - {}", announcementList.size());
		}
		return responseList;

	}

	public void prepareResponseDto(List<AciisstAncmntDTO> announcementList, String receipt,
			List<AnnouncementResponseView> responseList) {
		AnnouncementResponseView announcement;
		for (AciisstAncmntDTO ancmt : announcementList) {
			announcement = new AnnouncementResponseView();
			announcement.setAncmntDescription(ancmt.getAncmntDesc());
			announcement.setAncmntId(ancmt.getAncmntId());
			announcement.setCreateDate(ancmt.getAncmntEfctvDt());
			announcement.setFileFlag(ancmt.getFileDcmnt() == null ? false : true);
			announcement.setShortDescription(ancmt.getDcmntTtlShrtNm());
			announcement.setReceipt(receipt);
			responseList.add(announcement);
		}
	}

	/**
	 * Saves the read announcement for the user
	 * 
	 * @param smUserId
	 * @param announcementId
	 * @return
	 * @throws SQLException 
	 */

	public int saveReadAnnouncement(String smUserId, String announcementId) throws SQLException {
		User user = userRepository.findByLognUserId(smUserId);
		int userId = user.getUserId();
		AciisstUserAncmntReadDTO announcement = new AciisstUserAncmntReadDTO();
		Calendar calendar = Calendar.getInstance();
		Timestamp currentTimestamp = new Timestamp(calendar.getTime().getTime());
		announcement.setAncmntId(Integer.parseInt(announcementId));
		announcement.setAciisstUserId(userId);
		announcement.setCreatdDtm(currentTimestamp);
		announcement.setCreatdByUserId(userId);
		announcement.setUpdtdDtm(currentTimestamp);
		announcement.setUpdtdByUserId(userId);
		return announcementRepository.saveReadAnnouncement(announcement);
	}

	/**
	 * gets the Alerts for the user from DB
	 * 
	 * @param userId
	 * @param accountId
	 * @return Alert List
	 * @throws SQLException 
	 */

	public List<AnnouncementResponseView> getAlerts(String userId, String accountId) throws SQLException {
		User user = userRepository.findByLognUserId(userId);
		String ctgrycd = user.getUserCategoryCd();
		int ciiUserId = user.getUserId();
		List<AnnouncementResponseView> responseList = new ArrayList<>();
		List<AciisstAncmntDTO> announcementList = new ArrayList<>();
		String alertInd = "Y";
		if (StringUtils.isEmpty(accountId)) {
			prepareResponseDto(announcementRepository.getAllUserAnnouncement(ctgrycd, ciiUserId, alertInd),
					ACIISSTConstants.RECEIPT_UNREAD, responseList);
			prepareResponseDto(announcementRepository.getAllUserAnnouncementRead(ctgrycd, ciiUserId, alertInd),
					ACIISSTConstants.RECEIPT_READ, responseList);
			logger.debug("Announcement  List size - {}", announcementList.size());
		} else {
			prepareResponseDto(announcementRepository.getAllUserAndAccountSpecificAnnouncement(ctgrycd, ciiUserId, accountId, alertInd), 
					ACIISSTConstants.RECEIPT_UNREAD, responseList);
			prepareResponseDto(announcementRepository.getAllUserAndAccountSpecificAnnouncementRead(ctgrycd, ciiUserId, accountId, alertInd),
					ACIISSTConstants.RECEIPT_READ, responseList);

			logger.debug("Announcement List size - {} ", announcementList.size());
		}

		return responseList;

	}

	/**
	 * get documents for the announcementId
	 * 
	 * @param announcementId
	 * @return
	 * @throws SQLException 
	 * @throws NumberFormatException 
	 */
	public AnnouncementResponseView getNotificationdocument(String announcementId) throws NumberFormatException, SQLException {
		AnnouncementResponseView announcementResp = new AnnouncementResponseView();
		AciisstAncmntDTO announcement = announcementRepository.getAnnouncement(Integer.parseInt(announcementId));
		if(announcement!=null) {
			AciisstFileCntntTypeDTO aciisstFileCntntType=fileTypeCodeDAO.findFileTypeCode(announcement.getFileCntntTypeCd());
			String contentTypeCode = ObjectUtils.isEmpty(aciisstFileCntntType)?ACIISSTConstants.EMPTY_BLANK_STRING: aciisstFileCntntType.getFileCntntTypeCd();
			announcementResp.setAncmntId(announcement.getAncmntId());
			announcementResp.setContentType(ObjectUtils.isEmpty(aciisstFileCntntType)?ACIISSTConstants.EMPTY_BLANK_STRING: aciisstFileCntntType.getFileCntntTypeDesc());
			announcementResp.setFileName(announcement.getFileName()+ACIISSTConstants.EXTN_SEPERATOR+contentTypeCode.trim().toLowerCase());
			announcementResp.setFileDcmnt(announcement.getFileDcmnt());
		}

		return announcementResp;
	}

}
