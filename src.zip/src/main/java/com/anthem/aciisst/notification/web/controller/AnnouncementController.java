package com.anthem.aciisst.notification.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.common.web.view.ResponseView;
import com.anthem.aciisst.notification.service.AnnouncementService;
import com.anthem.aciisst.notification.web.view.response.AnnouncementResponseView;

/**
 * @author AF72803
 *
 */
/**
 * @author AF72803
 *
 */

@CrossOrigin
@RestController
@RequestMapping("notification")
public class AnnouncementController {

	@Autowired
	AnnouncementService announcementService;


	/**
	 * Gets all the Announcements for the user
	 * 
	 * @return BaseResponse
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/announcement")
	public ResponseView<List<AnnouncementResponseView>> getAllAnnouncement(@RequestParam("SM_USER_ID") String userId,
			@RequestParam(value = "ACCT_ID", required = false) String accountId, HttpServletRequest httpRequest) {
		ResponseView<List<AnnouncementResponseView>> responseView = new ResponseView<>();
		try {
			List<AnnouncementResponseView> announcements = announcementService.getAnnouncement(userId, accountId);
			responseView.setData(announcements);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(accountId);
			logDetail.setUserId( userId);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}

		return responseView;
	}

	/**
	 * Gets the Alerts for users based on the userId and accountID
	 * 
	 * @param userId
	 * @param accountId
	 * @return BaseResponse
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/alerts")
	public ResponseView<List<AnnouncementResponseView>> getAlerts(@RequestParam("SM_USER_ID") String userId,
			@RequestParam(value = "ACCT_ID", required = false) String accountId, HttpServletRequest httpRequest) {
		ResponseView<List<AnnouncementResponseView>> responseView = new ResponseView<>();
		try {

			List<AnnouncementResponseView> alerts = announcementService.getAlerts(userId, accountId);
			responseView.setData(alerts);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(accountId);
			logDetail.setUserId( userId);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}

		return responseView;
	}

	/**
	 * This service
	 * 
	 * @param announcementId
	 * @param smUserId
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/updateReadAnnouncement")
	public ResponseView<List<AnnouncementResponseView>> saveReadAnnouncement(
			@RequestParam("ANCMNT_ID") String announcementId, @RequestParam("SM_USER_ID") String smUserId, HttpServletRequest httpRequest) {
		ResponseView<List<AnnouncementResponseView>> responseView = new ResponseView<>();
		try {
			int result=announcementService.saveReadAnnouncement(smUserId, announcementId);
			if(result>0) {
				responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
				responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);				
			}else {
				responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
				responseView.setStatusDescription("Nothing Inserted");	
			}
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(ACIISSTConstants.NA);
			logDetail.setUserId(smUserId);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}
		return responseView;

	}

	/**
	 * Downloads the attachments for the announcement
	 * 
	 * @param announcementId
	 * @param response
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/downloadAttachment")
	public void getNotificationDocument(@RequestParam("ANCMNT_ID") String announcementId,
			HttpServletResponse response, HttpServletRequest httpRequest) {

		try {
			AnnouncementResponseView announcement = announcementService.getNotificationdocument(announcementId);
			response.setHeader("Content-Type", announcement.getContentType());
			response.setHeader("Content-Disposition", "attachment; filename=\"" + announcement.getFileName() + "\"");
			if(announcement.getFileDcmnt()!=null) {
				FileCopyUtils.copy(announcement.getFileDcmnt(), response.getOutputStream());
			}

		} catch (Exception e) {
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(ACIISSTConstants.NA);
			logDetail.setUserId(ACIISSTConstants.NA);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}

	}
}
