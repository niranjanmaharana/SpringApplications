package com.anthem.aciisst.notification.web.view.response;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties
public class ResourceResponseView {
	private Integer rscId;
	private String rscMtrlNm;
	private String rscMtrlTxt;
	private Date createDate;
	private String rscCtgryCD;
	private String rscShrtNm;	
	@JsonIgnore
	private String fileName;
	@JsonIgnore
	private byte[] fileDcmnt;
	@JsonIgnore
	private String contentType;
	
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getRscCtgryCD() {
		return rscCtgryCD;
	}
	public void setRscCtgryCD(String rscCtgryCD) {
		this.rscCtgryCD = rscCtgryCD;
	}
	public String getRscShrtNm() {
		return rscShrtNm;
	}
	public void setRscShrtNm(String rscShrtNm) {
		this.rscShrtNm = rscShrtNm;
	}
	
	public Integer getRscId() {
		return rscId;
	}
	public void setRscId(Integer rscId) {
		this.rscId = rscId;
	}
	public String getRscMtrlNm() {
		return rscMtrlNm;
	}
	public void setRscMtrlNm(String rscMtrlNm) {
		this.rscMtrlNm = rscMtrlNm;
	}
	public String getRscMtrlTxt() {
		return rscMtrlTxt;
	}
	public void setRscMtrlTxt(String rscMtrlTxt) {
		this.rscMtrlTxt = rscMtrlTxt;
	}
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public byte[] getFileDcmnt() {
		return fileDcmnt;
	}
	public void setFileDcmnt(byte[] fileDcmnt) {
		this.fileDcmnt = fileDcmnt;
	}
	
}
