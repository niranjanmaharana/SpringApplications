package com.anthem.aciisst.notification.web.controller;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.common.web.view.ResponseView;
import com.anthem.aciisst.notification.service.ResourceService;
import com.anthem.aciisst.notification.web.view.response.ResourceResponseView;

/**
 * @author AF95039
 *
 */
@CrossOrigin
@RestController
@RequestMapping("additionalResource")
public class ResourceController {
	
	@Autowired
	ResourceService resourceService;

	/**
	 * Gets the Additional Resources for users 
	 * @param accountId
	 * @param httpRequest
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/resources")
	public ResponseView<List<ResourceResponseView>> getAllAdditionalResources( Principal principal,
			HttpServletRequest httpRequest){
		
		ResponseView<List<ResourceResponseView>> responseView = new ResponseView<>();
		String userId = principal.getName();
		try {
			List<ResourceResponseView> resourceView = resourceService.getResources(userId);
			responseView.setData(resourceView);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			LogDetail logDetail = new LogDetail(userId,ACIISSTConstants.NA,httpRequest.getRequestURI());
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}

		return responseView;
	}
	/**
	 * To fetch the attachment based on the ResourceID
	 * @param rsrcId
	 * @param response
	 * @param httpRequest
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/downloadAttachment")
	public void getNotificationDocument(@RequestParam("RSRC_ID") String rsrcId,
			HttpServletResponse response, HttpServletRequest httpRequest) {
		try {
			ResourceResponseView announcement = resourceService.getNotificationdocument(rsrcId);
			response.setHeader("Content-Type", announcement.getContentType());
			response.setHeader("Content-Disposition", "attachment; filename=\"" + announcement.getFileName() + "\"");
			if(announcement.getFileDcmnt()!=null){
				FileCopyUtils.copy(announcement.getFileDcmnt(), response.getOutputStream());
			}	

		} catch (Exception e) {
			LogDetail logDetail = new LogDetail(ACIISSTConstants.NA,ACIISSTConstants.NA,httpRequest.getRequestURI());
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}

	}

}
