package com.anthem.aciisst.filter.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.account.web.view.response.KeyValueResponse;
import com.anthem.aciisst.account.web.view.response.TimePeriodFilterRequest;
import com.anthem.aciisst.account.web.view.response.TimePeriodFilterResponse;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.common.web.view.ResponseView;
import com.anthem.aciisst.filter.web.service.TimePeriodService;

/**
 * @author AF72803
 *
 */
@CrossOrigin
@RestController
@RequestMapping("timePeriod")
public class TimePeriodController {
	
	@Autowired
	TimePeriodService timePeriodService;
	
	/**
	 * 
	 * @param timePeriodFilterRequest
	 * @param httpRequest
	 * @return
	 * return start and end date response 
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/filter/timePeriodDisplayDate")
	public ResponseView<TimePeriodFilterResponse> getTimePeriodDates(
			@RequestBody TimePeriodFilterRequest timePeriodFilterRequest, HttpServletRequest httpRequest) {
		ResponseView<TimePeriodFilterResponse> responseView = new ResponseView<>();
		try {
			
			responseView.setData(timePeriodService.getTimePeriodDispayDate(timePeriodFilterRequest));
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(timePeriodFilterRequest.getAccountId());
			logDetail.setUserId( timePeriodFilterRequest.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);

		}

		return responseView;
	}
	
	
	
	/**
	 * @param timePeriodFilterRequest
	 * @param httpRequest
	 * @return
	 * method to return the time period type
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/filter/timePeriodType")
	public ResponseView<List<KeyValueResponse>> getTimePeriodType(
			@RequestBody TimePeriodFilterRequest timePeriodFilterRequest, HttpServletRequest httpRequest) {
		ResponseView<List<KeyValueResponse>> responseView = new ResponseView<>();
		try {
			responseView.setData(timePeriodService.getTimePeriodType());
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(timePeriodFilterRequest.getAccountId());
			logDetail.setUserId( timePeriodFilterRequest.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);

		}	

		return responseView;
	}

	
	/**
	 * @param timwPeriodFilterRequest
	 * @param httpRequest
	 * @return
	 * this method returns yearMonth values
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/filter/timePeriodMonth")
	public ResponseView<List<KeyValueResponse>> getTimePeriodMonth(
			@RequestBody TimePeriodFilterRequest timwPeriodFilterRequest, HttpServletRequest httpRequest) {
		ResponseView<List<KeyValueResponse>> responseView = new ResponseView<>();
		try {
			
			responseView.setData(timePeriodService.getMonthValue(timwPeriodFilterRequest));
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(timwPeriodFilterRequest.getAccountId());
			logDetail.setUserId( timwPeriodFilterRequest.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);

		}

		return responseView;
	}
	
	
	/**
	 * @param timwPeriodFilterRequest
	 * @param httpRequest
	 * @return
	 * method returns paid and incurred details
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/filter/paidAndIncurred")
	public ResponseView<List<KeyValueResponse>> getPaidAndIncured(
			@RequestBody TimePeriodFilterRequest timwPeriodFilterRequest, HttpServletRequest httpRequest) {
		ResponseView<List<KeyValueResponse>> responseView = new ResponseView<>();
		try {
			
			responseView.setData(timePeriodService.getPaidAndIncurred(timwPeriodFilterRequest));
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(timwPeriodFilterRequest.getAccountId());
			logDetail.setUserId( timwPeriodFilterRequest.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);

		}

		return responseView;
	}
	
	/**
	 * @param timwPeriodFilterRequest
	 * @param httpRequest
	 * @return
	 * returns HCC threshold values
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/filter/hccThreshold")
	public ResponseView<List<KeyValueResponse>> getHccThreshold(
			@RequestBody TimePeriodFilterRequest timwPeriodFilterRequest, HttpServletRequest httpRequest) {
		ResponseView<List<KeyValueResponse>> responseView = new ResponseView<>();
		try {
			
			responseView.setData(timePeriodService.getHccThreshold(timwPeriodFilterRequest));
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(timwPeriodFilterRequest.getAccountId());
			logDetail.setUserId( timwPeriodFilterRequest.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
			

		}

		return responseView;
	}


}
