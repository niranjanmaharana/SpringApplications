package com.anthem.aciisst.filter.web.view.request;

import com.anthem.aciisst.account.web.view.response.BaseAccountStructureDTO;

public class ComparitiveIdentifierRequestView  extends BaseAccountStructureDTO{
	
	private String currentPeriodStart;
	private String currentPeriodEnd;
	private String priorPeriod1Start;
	private String priorPeriod1End;
	private String priorPeriod2Start;
	private String priorPeriod2End;
	public String getCurrentPeriodStart() {
		return currentPeriodStart;
	}
	public void setCurrentPeriodStart(String currentPeriodStart) {
		this.currentPeriodStart = currentPeriodStart;
	}
	public String getCurrentPeriodEnd() {
		return currentPeriodEnd;
	}
	public void setCurrentPeriodEnd(String currentPeriodEnd) {
		this.currentPeriodEnd = currentPeriodEnd;
	}
	public String getPriorPeriod1Start() {
		return priorPeriod1Start;
	}
	public void setPriorPeriod1Start(String priorPeriod1Start) {
		this.priorPeriod1Start = priorPeriod1Start;
	}
	public String getPriorPeriod1End() {
		return priorPeriod1End;
	}
	public void setPriorPeriod1End(String priorPeriod1End) {
		this.priorPeriod1End = priorPeriod1End;
	}
	public String getPriorPeriod2Start() {
		return priorPeriod2Start;
	}
	public void setPriorPeriod2Start(String priorPeriod2Start) {
		this.priorPeriod2Start = priorPeriod2Start;
	}
	public String getPriorPeriod2End() {
		return priorPeriod2End;
	}
	public void setPriorPeriod2End(String priorPeriod2End) {
		this.priorPeriod2End = priorPeriod2End;
	}
	
	

}
