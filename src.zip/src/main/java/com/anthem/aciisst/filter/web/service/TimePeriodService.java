package com.anthem.aciisst.filter.web.service;

import java.sql.SQLException;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.anthem.aciisst.account.web.view.response.KeyValueResponse;
import com.anthem.aciisst.account.web.view.response.TimePeriodFilterRequest;
import com.anthem.aciisst.account.web.view.response.TimePeriodFilterResponse;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.AcisstUtil;
import com.anthem.aciisst.common.util.StringUtil;
import com.anthem.aciisst.persistence.dao.AccountDAO;
import com.anthem.aciisst.persistence.dao.AccountPrflAddtnlDataDAO;
import com.anthem.aciisst.persistence.dao.AciisstDataAvailabiltyHistoryDAO;
import com.anthem.aciisst.persistence.dao.AppPropertyDAO;
import com.anthem.aciisst.persistence.dto.AccountDTO;
import com.anthem.aciisst.persistence.dto.AccountProfileAdditionalDataDTO;
import com.anthem.aciisst.persistence.dto.AppPropertyDTO;

@Service
public class TimePeriodService {

	private static final Logger logger = LoggerFactory.getLogger(TimePeriodService.class);

	@Autowired
	AccountPrflAddtnlDataDAO accountPrflAddtnlDataDAO;

	@Autowired
	AciisstDataAvailabiltyHistoryDAO dataAvaliHistDao;
	
	@Autowired
	AccountDAO accountDao;
	
	@Autowired
	AppPropertyDAO appPropertyDAO;

	/**
	 * @return time period types from the DB
	 * @throws SQLException 
	 */
	public List<KeyValueResponse> getTimePeriodType() throws SQLException {
		List<KeyValueResponse> responseList = new ArrayList<>();
		AppPropertyDTO timePeriodTypeFilters = appPropertyDAO
				.getFilterValueFromAppProperty(ACIISSTConstants.TIMEPERIOD_TYPE_FILTER);
		if (!ObjectUtils.isEmpty(timePeriodTypeFilters)) {
			// Prepare Key value response from String in format
			// All|All;1-17|1-17;18-26|18-26
			responseList = StringUtil
					.setKeyValuesForFilters(Arrays.asList(timePeriodTypeFilters.getAciisstPrptyValTxt().split(";")));
		}
		logger.debug("Time period Type size : {}", responseList.size());
		return responseList;
	}

	/**
	 * @param timePeriodFilterRequest
	 * @return method to get start date
	 * @throws SQLException 
	 */
	public String getStartDate(TimePeriodFilterRequest timePeriodFilterRequest) throws SQLException {
		AccountProfileAdditionalDataDTO startDateInt = accountPrflAddtnlDataDAO
				.getElegibilityCyMonthEnd(timePeriodFilterRequest.getAccountId());
		String startDate;
		if (startDateInt != null) {
			startDate = String.valueOf(startDateInt.getElgbltyCyMnthEndNbr());
		} else {
			Calendar currentDate = Calendar.getInstance();
			currentDate.add(Calendar.MONTH, -64);//-64 coz we want to take prior completed month
			startDate = "" + currentDate.get(Calendar.YEAR)
					+ String.format("%02d", (currentDate.get(Calendar.MONTH) + 1));

		}
		logger.info("Time period  getStartDate() Start Date : {} ", startDate);

		return startDate;
	}

	/**
	 * @param timePeriodFilterRequest
	 * @return method to get End date
	 * @throws SQLException 
	 */
	public Calendar getEndDate(TimePeriodFilterRequest timePeriodFilterRequest) throws SQLException {

		Calendar timePeriodEndDate = Calendar.getInstance();
		String endDate = null;
		if (!StringUtils.isEmpty(timePeriodFilterRequest.getCurrentPeriodEnd())) {
			endDate = timePeriodFilterRequest.getCurrentPeriodEnd();

			String crEndmm = endDate.length() > 2 ? endDate.substring(endDate.length() - 2) : endDate;
			String crEndyyyy = endDate.length() > 4 ? endDate.substring(0, endDate.length() - 2) : endDate;
			int crEndMonthinMM = Integer.parseInt(crEndmm);
			int crEndYear = Integer.parseInt(crEndyyyy);
	

			
			timePeriodEndDate.set(Calendar.MONTH, crEndMonthinMM);
			timePeriodEndDate.set(Calendar.YEAR, crEndYear);
			timePeriodEndDate.add(Calendar.MONTH, -1);
			if (!"Y".equalsIgnoreCase(timePeriodFilterRequest.getKpiInd())){
				return timePeriodEndDate;
			}			
			
		} else {
			Date dataThrougDate = dataAvaliHistDao.getDataAvailabilityHistory();
			if (dataThrougDate != null) {
				timePeriodEndDate.setTimeInMillis(dataThrougDate.getTime());
			}else {
				timePeriodEndDate.add(Calendar.MONTH, -1);//get prior completed month
			}
		}
		 
		int x = getRunOutMonths(timePeriodFilterRequest);
		timePeriodEndDate.add(Calendar.MONTH, -x);
		return timePeriodEndDate;
	}

	public int getRunOutMonths(TimePeriodFilterRequest timePeriodFilterRequest) {
		int defaultRunOutMonths = 0;
		if (ACIISSTConstants.ACCOUNT_3061_IND_N.equalsIgnoreCase(timePeriodFilterRequest.getAccount_3061_ind())) {
			if (ACIISSTConstants.INCURRED.equalsIgnoreCase(timePeriodFilterRequest.getPaidOrIncured())) {
				defaultRunOutMonths = 3;// Default for non-3061 account is 3 months
				if ("Y".equalsIgnoreCase(timePeriodFilterRequest.getKpiInd())){
					int runoutMonthInt = 0;
					String runOutMonthsStr = timePeriodFilterRequest.getRunOutMonths();
					if(!StringUtils.isEmpty(runOutMonthsStr)){
						runoutMonthInt = Integer.parseInt(runOutMonthsStr);
					}
					if (runoutMonthInt < 0) {
						defaultRunOutMonths = runoutMonthInt;
					}
				}
				logger.info("Acct3061=0 and PaidOrIncured= Incurred defaultRunOutMonths={}",defaultRunOutMonths);
			}

		} else if (ACIISSTConstants.ACCOUNT_3061_IND_Y.equalsIgnoreCase(timePeriodFilterRequest.getAccount_3061_ind())) {
			// Default for 3061 account is 2 months
			defaultRunOutMonths = 2;
			logger.info("Acct3061=1 and PaidOrIncured= Incurred defaultRunOutMonths={}",defaultRunOutMonths);
		}
		return defaultRunOutMonths;
	}

	/**
	 * @param timePeriodFilterRequest
	 * @return method to preparing the response based on timeperiod type
	 * @throws SQLException 
	 */
	public TimePeriodFilterResponse getTimePeriodDispayDate(TimePeriodFilterRequest timePeriodFilterRequest) throws SQLException,NumberFormatException {

		// start date -account ElegibilityCyMonthEnd date or 63 months from current
		// month
		String startDate = getStartDate(timePeriodFilterRequest);

		String mm = startDate.length() > 2 ? startDate.substring(startDate.length() - 2) : startDate;
		String yyyy = startDate.length() > 4 ? startDate.substring(0, startDate.length() - 2) : startDate;
		int startMonthinMM = Integer.parseInt(mm);
		int startYear = Integer.parseInt(yyyy);

		// End date - AciisstDataAvailabiltyHistory DataThruDt or current month
		Calendar timePeriodEndDate  = getEndDate(timePeriodFilterRequest);
		String endDate= timePeriodEndDate.get(Calendar.YEAR) + String.format("%02d", (timePeriodEndDate.get(Calendar.MONTH) + 1));
		logger.info("End date After sub runout months :{}",endDate);

//		String crEndmm = endDate.length() > 2 ? endDate.substring(endDate.length() - 2) : endDate;
//		String crEndyyyy = endDate.length() > 4 ? endDate.substring(0, endDate.length() - 2) : endDate;
		int crEndMonthinMM = Integer.parseInt(String.format("%02d", (timePeriodEndDate.get(Calendar.MONTH) + 1)));
		int crEndYear = timePeriodEndDate.get(Calendar.YEAR) ;

		Calendar startPeriod = new GregorianCalendar(startYear, startMonthinMM, 01);
		int timePeriodDif = AcisstUtil.getDiffMonth(startDate, endDate);

		int planMonth;
		boolean planMonthGreater = false;

		

		Calendar timePeriodStartDate = Calendar.getInstance();

		timePeriodStartDate.set(Calendar.DAY_OF_MONTH, 1);
		timePeriodStartDate.set(Calendar.YEAR, crEndYear);
		timePeriodStartDate.add(Calendar.MONTH, -1);
		TimePeriodFilterResponse responseList = new TimePeriodFilterResponse();
		if (timePeriodFilterRequest.getTimeperiodType() != null) {

			if (timePeriodFilterRequest.getTimeperiodType().equalsIgnoreCase(ACIISSTConstants.ROLLING3TYPE)) {
				timePeriodStartDate.set(Calendar.MONTH, crEndMonthinMM - 1);
				timePeriodStartDate.add(Calendar.MONTH, -2);
				timePeriodDif = timePeriodDif - 3;
			} else if (timePeriodFilterRequest.getTimeperiodType().equalsIgnoreCase(ACIISSTConstants.CYTD)) {
				timePeriodDif = timePeriodDif - crEndMonthinMM;
				timePeriodStartDate.set(Calendar.MONTH, Calendar.JANUARY);
			} else if (timePeriodFilterRequest.getTimeperiodType().equalsIgnoreCase(ACIISSTConstants.PYTD)) {
				AccountDTO account = accountDao.findAccount(timePeriodFilterRequest.getAccountId());
				if (account.getAcctPlanMnthNbr() != null && (account.getAcctPlanMnthNbr().intValue() <= 12
						&& account.getAcctPlanMnthNbr().intValue() >= 1)) {
					planMonth = account.getAcctPlanMnthNbr();
				} else {
					planMonth = 1;
				}
				if ((timePeriodEndDate.get(Calendar.MONTH) + 1) < planMonth) {
					timePeriodDif = timePeriodDif - ((13 - planMonth) + (timePeriodEndDate.get(Calendar.MONTH) + 1));
					timePeriodStartDate.add(Calendar.YEAR, -1);
					planMonthGreater = true;
				} else {
					timePeriodDif = timePeriodDif - ((timePeriodEndDate.get(Calendar.MONTH) + 1) - planMonth);
				}
				timePeriodStartDate.set(Calendar.MONTH, planMonth - 1);

			} else {
				timePeriodStartDate.set(Calendar.MONTH, crEndMonthinMM - 1);
				timePeriodStartDate.set(Calendar.YEAR, crEndYear);
				timePeriodStartDate.add(Calendar.MONTH, -11);
				timePeriodDif = timePeriodDif - 12;
			}
			//if Num of Time period is null or empty String changing it to default 3 
			int numOfTimePeriod= StringUtils.isEmpty(timePeriodFilterRequest.getNumberoftimeperiod())?3:Integer.parseInt(timePeriodFilterRequest.getNumberoftimeperiod());
			responseList = prepareTimePeriodDateResponse(timePeriodStartDate, timePeriodEndDate,
					timePeriodFilterRequest.getTimeperiodType(), timePeriodDif, startPeriod, planMonthGreater,numOfTimePeriod);
		}
		return responseList;

	}

	/**
	 * @param startMonth
	 * @param lastCompleteMonth
	 * @param periodType
	 * @param timePeriodDif
	 * @param startPeriod
	 * @param planMonthGreater
	 * @return prepare time period date response
	 */
	private TimePeriodFilterResponse prepareTimePeriodDateResponse(Calendar timePeriodStartDate,
			Calendar timePeriodEndDate, String periodType, int timePeriodDif, Calendar startPeriod,
			boolean planMonthGreater,int uiNumOfTimePeriod) {
		TimePeriodFilterResponse response = new TimePeriodFilterResponse();
		int numberoftimeperiod = 1;
		SimpleDateFormat format = new SimpleDateFormat("yyyyMM");
		if (timePeriodDif <= 0) {
			timePeriodStartDate.set(Calendar.MONTH, startPeriod.get(Calendar.MONTH));
			timePeriodStartDate.set(Calendar.YEAR, startPeriod.get(Calendar.YEAR));
			timePeriodStartDate.add(Calendar.MONTH, -1);
			response.setCurrentperiodend(format.format(timePeriodEndDate.getTime()));
			response.setCurrentperiodstart(format.format(timePeriodStartDate.getTime()));
			timePeriodDif = -1;
			response.setNumberoftimeperiod(numberoftimeperiod);
		} else {
			response.setCurrentperiodend(format.format(timePeriodEndDate.getTime()));
			response.setCurrentperiodstart(format.format(timePeriodStartDate.getTime()));
			response.setNumberoftimeperiod(numberoftimeperiod);
		}
		if (periodType.equalsIgnoreCase(ACIISSTConstants.CYTD)) {
			if(uiNumOfTimePeriod>=2) {
				
				if (timePeriodDif < 12 && timePeriodDif > 0) {
					timePeriodStartDate.set(Calendar.MONTH, startPeriod.get(Calendar.MONTH));
					timePeriodStartDate.set(Calendar.YEAR, startPeriod.get(Calendar.YEAR));
					timePeriodStartDate.add(Calendar.MONTH, -1);
					timePeriodEndDate.add(Calendar.MONTH, -(timePeriodEndDate.get(Calendar.MONTH) + 1));
					response.setPriorperiod1end(format.format(timePeriodEndDate.getTime()));
					response.setPriorperiod1start(format.format(timePeriodStartDate.getTime()));
					timePeriodDif = -1;
					numberoftimeperiod++;
					response.setNumberoftimeperiod(numberoftimeperiod);
					
				} else if (timePeriodDif >= 12) {
					timePeriodStartDate.add(Calendar.MONTH, -12);
					timePeriodEndDate.add(Calendar.MONTH, -(timePeriodEndDate.get(Calendar.MONTH) + 1));
					response.setPriorperiod1end(format.format(timePeriodEndDate.getTime()));
					response.setPriorperiod1start(format.format(timePeriodStartDate.getTime()));
					timePeriodDif = timePeriodDif - 12;
					numberoftimeperiod++;
					response.setNumberoftimeperiod(numberoftimeperiod);
				}
			}
			if(uiNumOfTimePeriod==3) {
			if (timePeriodDif < 12 && timePeriodDif > 0) {
				timePeriodStartDate.set(Calendar.MONTH, startPeriod.get(Calendar.MONTH));
				timePeriodStartDate.set(Calendar.YEAR, startPeriod.get(Calendar.YEAR));
				timePeriodEndDate.add(Calendar.MONTH, -(timePeriodEndDate.get(Calendar.MONTH) + 1));
				timePeriodStartDate.add(Calendar.MONTH, -1);
				response.setPriorperiod2end(format.format(timePeriodEndDate.getTime()));
				response.setPriorperiod2start(format.format(timePeriodStartDate.getTime()));
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			} else if (timePeriodDif >= 12) {
				timePeriodStartDate.add(Calendar.MONTH, -12);
				timePeriodEndDate.add(Calendar.MONTH, -12);
				response.setPriorperiod2end(format.format(timePeriodEndDate.getTime()));
				response.setPriorperiod2start(format.format(timePeriodStartDate.getTime()));
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);

			}
			}

		} else if (periodType.equalsIgnoreCase(ACIISSTConstants.PYTD)) {

			setPYTDresponse(timePeriodStartDate, timePeriodEndDate, timePeriodDif, startPeriod, planMonthGreater,
					response, numberoftimeperiod,uiNumOfTimePeriod);

		} else if (periodType.equalsIgnoreCase(ACIISSTConstants.ROLLING3TYPE)) {
			if(uiNumOfTimePeriod>=2) {
			if (timePeriodDif < 3 && timePeriodDif > 0) {
				timePeriodStartDate.set(Calendar.MONTH, startPeriod.get(Calendar.MONTH));
				timePeriodStartDate.set(Calendar.YEAR, startPeriod.get(Calendar.YEAR));
				timePeriodStartDate.add(Calendar.MONTH, -1);
				timePeriodEndDate.add(Calendar.MONTH, -3);
				response.setPriorperiod1end(format.format(timePeriodEndDate.getTime()));
				response.setPriorperiod1start(format.format(timePeriodStartDate.getTime()));
				timePeriodDif = -1;
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);

			} else if (timePeriodDif >= 3) {

				timePeriodStartDate.add(Calendar.MONTH, -3);
				timePeriodEndDate.add(Calendar.MONTH, -3);
				response.setPriorperiod1end(format.format(timePeriodEndDate.getTime()));
				response.setPriorperiod1start(format.format(timePeriodStartDate.getTime()));
				timePeriodDif = timePeriodDif - 3;
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			}
			}
			if(uiNumOfTimePeriod==3) {
			if (timePeriodDif < 3 && timePeriodDif > 0) {
				timePeriodStartDate.set(Calendar.MONTH, startPeriod.get(Calendar.MONTH));
				timePeriodStartDate.set(Calendar.YEAR, startPeriod.get(Calendar.YEAR));
				timePeriodStartDate.add(Calendar.MONTH, -1);
				timePeriodEndDate.add(Calendar.MONTH, -3);
				response.setPriorperiod2end(format.format(timePeriodEndDate.getTime()));
				response.setPriorperiod2start(format.format(timePeriodStartDate.getTime()));
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			} else if (timePeriodDif >= 3) {

				timePeriodStartDate.add(Calendar.MONTH, -3);
				timePeriodEndDate.add(Calendar.MONTH, -3);
				response.setPriorperiod2end(format.format(timePeriodEndDate.getTime()));
				response.setPriorperiod2start(format.format(timePeriodStartDate.getTime()));
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			}
			}
		} else {
			if(uiNumOfTimePeriod>=2) {
			if (timePeriodDif < 12 && timePeriodDif > 0) {
				timePeriodStartDate.set(Calendar.MONTH, startPeriod.get(Calendar.MONTH));
				timePeriodStartDate.set(Calendar.YEAR, startPeriod.get(Calendar.YEAR));
				timePeriodStartDate.add(Calendar.MONTH, -1);
				timePeriodEndDate.add(Calendar.MONTH, -12);
				response.setPriorperiod1end(format.format(timePeriodEndDate.getTime()));
				response.setPriorperiod1start(format.format(timePeriodStartDate.getTime()));
				timePeriodDif = -1;
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			} else if (timePeriodDif >= 12) {

				timePeriodStartDate.add(Calendar.MONTH, -12);
				timePeriodEndDate.add(Calendar.MONTH, -12);
				response.setPriorperiod1end(format.format(timePeriodEndDate.getTime()));
				response.setPriorperiod1start(format.format(timePeriodStartDate.getTime()));
				timePeriodDif = timePeriodDif - 12;
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			}
			}
			if(uiNumOfTimePeriod==3) {
			if (timePeriodDif < 12 && timePeriodDif > 0) {
				timePeriodStartDate.set(Calendar.MONTH, startPeriod.get(Calendar.MONTH));
				timePeriodStartDate.set(Calendar.YEAR, startPeriod.get(Calendar.YEAR));
				timePeriodStartDate.add(Calendar.MONTH, -1);
				timePeriodEndDate.add(Calendar.MONTH, -12);
				response.setPriorperiod2end(format.format(timePeriodEndDate.getTime()));
				response.setPriorperiod2start(format.format(timePeriodStartDate.getTime()));
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			} else if (timePeriodDif >= 12) {
				timePeriodStartDate.add(Calendar.MONTH, -12);
				timePeriodEndDate.add(Calendar.MONTH, -12);
				response.setPriorperiod2end(format.format(timePeriodEndDate.getTime()));
				response.setPriorperiod2start(format.format(timePeriodStartDate.getTime()));
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			}
			}

		}

		return response;
	}

	/**
	 * @param startMonth
	 * @param lastCompleteMonth
	 * @param timePeriodDif
	 * @param startPeriod
	 * @param planMonthGreater
	 * @param response
	 * @param numberoftimeperiod
	 *            preparing PYTD Response
	 */
	public void setPYTDresponse(Calendar startMonth, Calendar lastCompleteMonth, int timePeriodDif,
			Calendar startPeriod, boolean planMonthGreater, TimePeriodFilterResponse response, int numberoftimeperiod,int uiNumOfTimePeriod) {
		SimpleDateFormat format = new SimpleDateFormat("yyyyMM");
		if (planMonthGreater) {
			if(uiNumOfTimePeriod>=2) {
				
				if (timePeriodDif <= 12 && timePeriodDif > 0) {
					Calendar temp = Calendar.getInstance();
					temp.set(Calendar.MONTH, startMonth.get(Calendar.MONTH));
					temp.set(Calendar.YEAR, startMonth.get(Calendar.YEAR));
					temp.add(Calendar.MONTH, -1);
					lastCompleteMonth.set(Calendar.MONTH, temp.get(Calendar.MONTH));
					lastCompleteMonth.set(Calendar.YEAR, temp.get(Calendar.YEAR));
					startMonth.set(Calendar.MONTH, startPeriod.get(Calendar.MONTH));
					startMonth.set(Calendar.YEAR, startPeriod.get(Calendar.YEAR));
					startMonth.add(Calendar.MONTH, -1);
					response.setPriorperiod1end(format.format(lastCompleteMonth.getTime()));
					response.setPriorperiod1start(format.format(startMonth.getTime()));
					timePeriodDif = -1;
					numberoftimeperiod++;
					response.setNumberoftimeperiod(numberoftimeperiod);
					
				} else if (timePeriodDif > 12) {
					Calendar temp = Calendar.getInstance();
					temp.set(Calendar.MONTH, startMonth.get(Calendar.MONTH));
					temp.set(Calendar.YEAR, startMonth.get(Calendar.YEAR));
					temp.add(Calendar.MONTH, -1);
					lastCompleteMonth.set(Calendar.MONTH, temp.get(Calendar.MONTH));
					lastCompleteMonth.set(Calendar.YEAR, temp.get(Calendar.YEAR));
					startMonth.add(Calendar.MONTH, -12);
					response.setPriorperiod1end(format.format(lastCompleteMonth.getTime()));
					response.setPriorperiod1start(format.format(startMonth.getTime()));
					timePeriodDif = timePeriodDif - 12;
					numberoftimeperiod++;
					response.setNumberoftimeperiod(numberoftimeperiod);
				}
			}
			if(uiNumOfTimePeriod==3) {
			if (timePeriodDif <= 12 && timePeriodDif > 0) {

				lastCompleteMonth.add(Calendar.MONTH, -12);
				startMonth.set(Calendar.MONTH, startPeriod.get(Calendar.MONTH));
				startMonth.set(Calendar.YEAR, startPeriod.get(Calendar.YEAR));
				startMonth.add(Calendar.MONTH, -1);
				response.setPriorperiod2end(format.format(lastCompleteMonth.getTime()));
				response.setPriorperiod2start(format.format(startMonth.getTime()));
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			} else if (timePeriodDif >= 12) {
				startMonth.add(Calendar.MONTH, -12);
				lastCompleteMonth.add(Calendar.MONTH, -12);
				response.setPriorperiod2end(format.format(lastCompleteMonth.getTime()));
				response.setPriorperiod2start(format.format(startMonth.getTime()));
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			}
			}
		} else {
			if(uiNumOfTimePeriod>=2) {
			if (timePeriodDif <= 12 && timePeriodDif >= 0) {
				Calendar temp = Calendar.getInstance();
				temp.set(Calendar.MONTH, startMonth.get(Calendar.MONTH));
				temp.set(Calendar.YEAR, startMonth.get(Calendar.YEAR));
				lastCompleteMonth.set(Calendar.MONTH, temp.get(Calendar.MONTH));
				lastCompleteMonth.set(Calendar.YEAR, temp.get(Calendar.YEAR));
				lastCompleteMonth.add(Calendar.MONTH, -1);
				response.setPriorperiod1end(format.format(lastCompleteMonth.getTime()));
				startMonth.set(Calendar.MONTH, startPeriod.get(Calendar.MONTH));
				startMonth.set(Calendar.YEAR, startPeriod.get(Calendar.YEAR));
				startMonth.add(Calendar.MONTH, -1);
				response.setPriorperiod1start(format.format(startMonth.getTime()));
				timePeriodDif = -1;
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);

			} else if (timePeriodDif > 12) {
				Calendar temp = Calendar.getInstance();
				temp.set(Calendar.MONTH, startMonth.get(Calendar.MONTH));
				temp.set(Calendar.YEAR, startMonth.get(Calendar.YEAR));
				lastCompleteMonth.set(Calendar.MONTH, temp.get(Calendar.MONTH));
				lastCompleteMonth.set(Calendar.YEAR, temp.get(Calendar.YEAR));
				lastCompleteMonth.add(Calendar.MONTH, -1);
				response.setPriorperiod1end(format.format(lastCompleteMonth.getTime()));
				startMonth.add(Calendar.MONTH, -12);
				response.setPriorperiod1start(format.format(startMonth.getTime()));

				timePeriodDif = timePeriodDif - 12;
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			}
			}
			if(uiNumOfTimePeriod==3) {
			if (timePeriodDif <= 12 && timePeriodDif > 0) {

				lastCompleteMonth.add(Calendar.MONTH, -12);
				startMonth.set(Calendar.MONTH, startPeriod.get(Calendar.MONTH));
				startMonth.set(Calendar.YEAR, startPeriod.get(Calendar.YEAR));
				startMonth.add(Calendar.MONTH, -1);
				response.setPriorperiod2end(format.format(lastCompleteMonth.getTime()));
				response.setPriorperiod2start(format.format(startMonth.getTime()));
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			} else if (timePeriodDif > 12) {
				startMonth.add(Calendar.MONTH, -12);
				lastCompleteMonth.add(Calendar.MONTH, -12);
				response.setPriorperiod2end(format.format(lastCompleteMonth.getTime()));
				response.setPriorperiod2start(format.format(startMonth.getTime()));
				numberoftimeperiod++;
				response.setNumberoftimeperiod(numberoftimeperiod);
			}
			}
		}

	}

	/**
	 * @param timePeriodFilterRequest
	 * @return Monthvalue details list
	 * @throws SQLException 
	 */
	public List<KeyValueResponse> getMonthValue(TimePeriodFilterRequest timePeriodFilterRequest) throws SQLException {
		String currStart = getStartDate(timePeriodFilterRequest);

		String endDate = getLastCompleteMonthLoaded();
		
		List<KeyValueResponse> responseList = new ArrayList<>();
		int currTimePeriod = AcisstUtil.getDiffMonth(currStart, endDate);
		String month = currStart.length() > 2 ? currStart.substring(currStart.length() - 2) : currStart;
		String yearstr = currStart.length() > 4 ? currStart.substring(0, currStart.length() - 2) : currStart;
		int tempMon = Integer.parseInt(month);
		int tempYer = Integer.parseInt(yearstr);
		while (currTimePeriod != 0) {
			KeyValueResponse response = new KeyValueResponse();
			if (tempMon > 12) {
				tempMon = 01;
				tempYer++;

			}

			response.setKey(tempYer + String.format("%02d", tempMon));
			response.setValue(new DateFormatSymbols().getShortMonths()[tempMon - 1] + " " + tempYer);
			responseList.add(response);
			tempMon++;
			currTimePeriod--;

		}
		return responseList;
	}

	/**
	 * @return paid and incurred details
	 * @throws SQLException 
	 */
	public List<KeyValueResponse> getPaidAndIncurred(TimePeriodFilterRequest timePeriodFilterRequest) throws SQLException {

		List<KeyValueResponse> responseList = new ArrayList<>();
				
		AppPropertyDTO paidAndIncurredFilter = appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.PAID_INCURRED_FILTER);
		if (!ObjectUtils.isEmpty(paidAndIncurredFilter)) {
			responseList = StringUtil.setKeyValuesForFilters(Arrays.asList(paidAndIncurredFilter.getAciisstPrptyValTxt().split(";")));
		}
		
		//if Acct3061Indicator()==1 default is Incurred 
		if(timePeriodFilterRequest!=null && ACIISSTConstants.ACCOUNT_3061_IND_Y.equalsIgnoreCase(timePeriodFilterRequest.getAccount_3061_ind())) {
			Iterator<KeyValueResponse> respIterator=responseList.iterator();
			while(respIterator.hasNext()) {
				KeyValueResponse kvResp = respIterator.next();
				if(!ACIISSTConstants.INCURRED.equalsIgnoreCase(kvResp.getKey())) {
					responseList.remove(kvResp);
				}
			}
		}

		return responseList;
	}

	/**
	 * @return Hcc Threshold response list
	 * @throws SQLException 
	 */
	public List<KeyValueResponse> getHccThreshold(TimePeriodFilterRequest timwPeriodFilterRequest) throws SQLException {
		List<KeyValueResponse> responseList = new ArrayList<>();	
		String hccAcctThresholdDefault = null;
		AppPropertyDTO hccThresholdFilters = appPropertyDAO
				.getFilterValueFromAppProperty(ACIISSTConstants.HCC_THRESHOLD_FILTER);		
		if(!ObjectUtils.isEmpty(hccThresholdFilters)) {			
			AccountDTO account = accountDao.findAccount(timwPeriodFilterRequest.getAccountId());
			if (account != null){
				hccAcctThresholdDefault = account.getDfltHccThrshldAmt()==null? null : account.getDfltHccThrshldAmt().trim();				
			} 
			try {
				Integer.parseInt(hccAcctThresholdDefault);
			} catch (NumberFormatException e) {
				AppPropertyDTO defaultHccThresholdFilter = appPropertyDAO
          				.getFilterValueFromAppProperty(ACIISSTConstants.DEFAULT_HCC_THRESHOLD_VALUE);                
                 if (!ObjectUtils.isEmpty(defaultHccThresholdFilter)){	
                	 hccAcctThresholdDefault = defaultHccThresholdFilter.getAciisstPrptyValTxt();
                 }
			}
			responseList = setKeyValuesForFilters(Arrays.asList(hccThresholdFilters.getAciisstPrptyValTxt().split(";")), hccAcctThresholdDefault);				
		}
		return responseList;
	}
	
    public List<KeyValueResponse> setKeyValuesForFilters(List<String> dataList, String defaultAcctHccThrshldValue) {
        List<KeyValueResponse> data = new ArrayList<>();

        if (!CollectionUtils.isEmpty(dataList)) {
               KeyValueResponse defaultHccThrshld = null;
               ListIterator<String> itr = dataList.listIterator();
               while (itr.hasNext()) {
                     KeyValueResponse value = new KeyValueResponse();
                     String filter = itr.next();
                     String[] filterValues = filter.split("\\|");
                     if (!ObjectUtils.isEmpty(filterValues) && filterValues.length == 2) {
                            if(defaultAcctHccThrshldValue != null && defaultAcctHccThrshldValue.trim().equalsIgnoreCase(filterValues[0])){
                                   defaultHccThrshld = new KeyValueResponse();
                                   defaultHccThrshld.setKey(filterValues[0]);
                                   defaultHccThrshld.setValue(filterValues[1]);
                                   data.add(0, defaultHccThrshld);
                                   continue;
                            }
                            value.setKey(filterValues[0]);
                            value.setValue(filterValues[1]);
                     }
                     data.add(value);
               }               
        }
        return data;

 }

	
	public String getLastCompleteMonthLoaded() throws SQLException{
		String endDate = "";
		Date dataThrougDate = dataAvaliHistDao.getDataAvailabilityHistory();
		Calendar calendar = Calendar.getInstance();
		if (dataThrougDate != null) {
			calendar.setTimeInMillis(dataThrougDate.getTime());
		}else {
			calendar.add(Calendar.MONTH, -1);//get prior completed month
		}
		endDate = calendar.get(Calendar.YEAR) + String.format("%02d", (calendar.get(Calendar.MONTH) + 1));
		
		return endDate;
	}
	
	public String getDateAsMONyyyy(String endDate){
		String lastCompleteMonthLoaded= "";
		if(endDate != null){
			String month = endDate.length() > 2 ? endDate.substring(endDate.length() - 2) : endDate;
			String yearstr = endDate.length() > 4 ? endDate.substring(0, endDate.length() - 2) : endDate;
			int tempMon = Integer.parseInt(month);
			lastCompleteMonthLoaded = new DateFormatSymbols().getShortMonths()[tempMon - 1] + " " + yearstr;
		}
		
		return lastCompleteMonthLoaded;
	}

}
