package com.anthem.aciisst.filter.web.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.anthem.aciisst.account.web.view.response.ComparitiveIdentifierRequest;
import com.anthem.aciisst.account.web.view.response.KeyValueResponse;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.StringUtil;
import com.anthem.aciisst.filter.web.view.request.BenchmarkRequest;
import com.anthem.aciisst.filter.web.view.response.BenchmarkResponse;
import com.anthem.aciisst.filter.web.view.response.ComparitiveIdentifierResponseView;
import com.anthem.aciisst.persistence.dao.AccountDAO;
import com.anthem.aciisst.persistence.dao.AppPropertyDAO;
import com.anthem.aciisst.persistence.dao.ClinicalBenchmarkDAO;
import com.anthem.aciisst.persistence.dao.MembershipBenchmarkDAO;
import com.anthem.aciisst.persistence.dao.MembershipDashboardRepositoryDAO;
import com.anthem.aciisst.persistence.dto.AccountDTO;
import com.anthem.aciisst.persistence.dto.AppPropertyDTO;

@Service
public class ComparativeIdentifierFilterService {
	

	@Autowired
	MembershipDashboardRepositoryDAO membershipDashbordDAO;

	@Autowired
	MembershipBenchmarkDAO membershipBenchmarkDAO;
	
	@Autowired
	ClinicalBenchmarkDAO clinicalBenchmarkDAO;
	
	@Autowired
	AccountDAO accountDAO;
	
	@Autowired
	AppPropertyDAO appPropertyDAO;
	

	/**
	 * @param comparitiveIdentifierRequest
	 * @return
	 * method to get all comparitive Identifier
	 * @throws SQLException 
	 */
	public ComparitiveIdentifierResponseView getComparitiveIdentifierFilters(
			ComparitiveIdentifierRequest comparitiveIdentifierRequest) throws SQLException {
		ComparitiveIdentifierResponseView resp = null;
		if (comparitiveIdentifierRequest != null && comparitiveIdentifierRequest.getSessionKey() != null
				&& comparitiveIdentifierRequest.getUserId() != null) {
			resp = new ComparitiveIdentifierResponseView();

			List<AppPropertyDTO> propertyList = appPropertyDAO.getMWValueFromAppProperty("MW");
			
			for(AppPropertyDTO prpty : propertyList) {
				if(ACIISSTConstants.COVERAGE_FILTER.equalsIgnoreCase(prpty.getAciisstPrptyNm())) {
					resp.setCoverage(StringUtil.setKeyValuesForFilters(Arrays.asList(prpty.getAciisstPrptyValTxt().split(";"))));
				}else if(ACIISSTConstants.HCC_FILTER.equalsIgnoreCase(prpty.getAciisstPrptyNm())) {
					resp.setHcc(StringUtil.setKeyValuesForFilters(Arrays.asList(prpty.getAciisstPrptyValTxt().split(";"))));
				}else if(ACIISSTConstants.GENDER_FILTER.equalsIgnoreCase(prpty.getAciisstPrptyNm())) {
					resp.setGender(StringUtil.setKeyValuesForFilters(Arrays.asList(prpty.getAciisstPrptyValTxt().split(";"))));
				}else if(ACIISSTConstants.AGE_BAND_FILTER.equalsIgnoreCase(prpty.getAciisstPrptyNm())) {
					resp.setAgeBand(StringUtil.setKeyValuesForFilters(Arrays.asList(prpty.getAciisstPrptyValTxt().split(";"))));
				}else if(ACIISSTConstants.ENGAGEMENT_FILTER.equalsIgnoreCase(prpty.getAciisstPrptyNm())) {
					resp.setEngagement(StringUtil.setKeyValuesForFilters(Arrays.asList(prpty.getAciisstPrptyValTxt().split(";"))));
				}else if(ACIISSTConstants.RELATIONSHIP_FILTER.equalsIgnoreCase(prpty.getAciisstPrptyNm())) {
					resp.setRelationship(StringUtil.setKeyValuesForFilters(Arrays.asList(prpty.getAciisstPrptyValTxt().split(";"))));
				}else if(ACIISSTConstants.HEALTHSTATUS_FILTER.equalsIgnoreCase(prpty.getAciisstPrptyNm())) {
					resp.setHealthStatus(StringUtil.setKeyValuesForFilters(Arrays.asList(prpty.getAciisstPrptyValTxt().split(";"))));
				}
			}
			
			List<KeyValueResponse> state = membershipDashbordDAO.getDistinctState(comparitiveIdentifierRequest.getAccountId());
			resp.setState(state);
			List<KeyValueResponse>  msa = membershipDashbordDAO.getDistinctMSA(comparitiveIdentifierRequest.getAccountId());
			resp.setMsa(msa);
		}
		return resp;
	}

	/**
	 * @param comparitiveIdentifierRequest
	 * @param resp
	 * checking small group in account and setting the benchmark data 
	 * @throws SQLException 
	 */
	public List<BenchmarkResponse> getBenchMark(BenchmarkRequest req) throws SQLException {	
		List<BenchmarkResponse> benchmarkList = null;
		List<BenchmarkResponse>  listResp= new ArrayList<>();
		AccountDTO account = accountDAO.findAccount(req.getAccountId());
		AppPropertyDTO defaultValue = null;
		BenchmarkResponse value = null;
		BenchmarkResponse benchmark1DefaultValue = new BenchmarkResponse();
		BenchmarkResponse benchmark2DefaultValue = new BenchmarkResponse();
		
		if("membership".equalsIgnoreCase(req.getModuleName())) {
			benchmarkList = membershipBenchmarkDAO.getMembershipBenchmark();
			
			defaultValue = appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.MBRSHP_BENCHMARK1);
			if(defaultValue!=null) {
				benchmark1DefaultValue = StringUtil.prepareBenchmark(defaultValue.getAciisstPrptyValTxt());
			}
			
			defaultValue = appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.MBRSHP_SMALL_ACCT_BENCHMARK);
			if(defaultValue!=null) {
				benchmark2DefaultValue = StringUtil.prepareBenchmark(defaultValue.getAciisstPrptyValTxt());
			}
		}else if("clinical".equalsIgnoreCase(req.getModuleName())) {
			benchmarkList = clinicalBenchmarkDAO.getClinicalBenchmark();
			
			defaultValue = appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.CLINICAL_BENCHMARK1);
			if(defaultValue!=null) {
				benchmark1DefaultValue = StringUtil.prepareBenchmark(defaultValue.getAciisstPrptyValTxt());
			}
			
			defaultValue = appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.CLINICAL_SMALL_ACCT_BENCHMARK);
			if(defaultValue!=null) {
				benchmark2DefaultValue = StringUtil.prepareBenchmark(defaultValue.getAciisstPrptyValTxt());
			}
		}
	
		if (!CollectionUtils.isEmpty(benchmarkList)) {
			
			if (account != null && "SMALL".equalsIgnoreCase(account.getAcctSizeClsfctnCd())) {
				listResp.add(benchmark2DefaultValue);
			}else{
				listResp.add(benchmark1DefaultValue);
			}

			ListIterator<BenchmarkResponse> itr = benchmarkList.listIterator();
		
			while (itr.hasNext()) {
				String key = null;
				value = new BenchmarkResponse();
				BenchmarkResponse obj = itr.next();
				if (obj != null) {
					key = obj.getCode();
					if(key.equalsIgnoreCase(benchmark1DefaultValue.getCode()) || key.equalsIgnoreCase(benchmark2DefaultValue.getCode())){
						continue;
					}
					value.setCode(obj.getCode());
					value.setDescription(obj.getDescription());
					listResp.add(value);
				}
			}

		}
		return listResp;
	}

	/**
	 * @param dataList
	 * @return preparing response
	 */
	public List<KeyValueResponse> setFilterData(List<String> dataList) {

		List<KeyValueResponse> data = new ArrayList<>();
		if (!CollectionUtils.isEmpty(dataList)) {
			ListIterator<String> itr = dataList.listIterator();
			while (itr.hasNext()) {
				KeyValueResponse value = new KeyValueResponse();
				String filter = itr.next();
				value.setValue(filter);
				value.setKey(filter);
				data.add(value);
			}

		}
		return data;

	}

	/**
	 * @param dataList
	 * @return
	 * method to prepare KeyValueResponse and returning the list with ALL KeyValueResponse
	 */
	public List<KeyValueResponse> setData(List<Object[]> dataList) {
		KeyValueResponse value = null;
		List<KeyValueResponse> data = new ArrayList<>();
		if (!CollectionUtils.isEmpty(dataList)) {
			ListIterator<Object[]> itr = dataList.listIterator();

			while (itr.hasNext()) {
				value = new KeyValueResponse();
				Object filter = itr.next();
				if(filter != null){
					value.setKey(filter.toString());
					value.setValue(filter.toString());
					data.add(value);
				}
			}

		}
		return data;

	}
	
	/**
	 * @param dataList
	 * @return
	 * method to prepare KeyValueResponse and returning the list without ALL KeyValueResponse
	 */
	public List<BenchmarkResponse> setDataWithouAll(List<Object[]> dataList) {
		BenchmarkResponse value = null;
		List<BenchmarkResponse> data = new ArrayList<>();
		if (!CollectionUtils.isEmpty(dataList)) {
			ListIterator<Object[]> itr = dataList.listIterator();
			
			while (itr.hasNext()) {
				value = new BenchmarkResponse();
				Object[] filterObj = itr.next();
				if(filterObj!=null && filterObj.length!=0){
					value.setCode((String) filterObj[0]);
					value.setDescription((String) filterObj[1]);
					data.add(value);
				}
			}

		}
		return data;

	}

}
