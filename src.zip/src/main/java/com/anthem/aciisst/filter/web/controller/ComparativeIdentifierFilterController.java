
package com.anthem.aciisst.filter.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.account.web.view.response.ComparitiveIdentifierRequest;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.common.web.view.ResponseView;
import com.anthem.aciisst.filter.web.service.ComparativeIdentifierFilterService;
import com.anthem.aciisst.filter.web.view.request.BenchmarkRequest;
import com.anthem.aciisst.filter.web.view.response.BenchmarkResponse;
import com.anthem.aciisst.filter.web.view.response.ComparitiveIdentifierResponseView;

@CrossOrigin
@RestController
@RequestMapping("filter")
public class ComparativeIdentifierFilterController {
	
	@Autowired
	ComparativeIdentifierFilterService comparativeIdentifierFilterService;
	
	/**
	 * @param comparitiveIdentifierRequestView
	 * @param httpRequest
	 * @return all the Comparitive filter data
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/comparitiveIdentifiers")
	public ResponseView<ComparitiveIdentifierResponseView> getComparitiveIdentifierFilters(
			@RequestBody ComparitiveIdentifierRequest comparitiveIdentifierRequestView, HttpServletRequest httpRequest) {
		ResponseView<ComparitiveIdentifierResponseView> responseView = new ResponseView<>();
		try {
			ComparitiveIdentifierResponseView filterList = comparativeIdentifierFilterService
					.getComparitiveIdentifierFilters(comparitiveIdentifierRequestView);
			responseView.setData(filterList);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(comparitiveIdentifierRequestView.getAccountId());
			logDetail.setUserId( comparitiveIdentifierRequestView.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);

		}
		return responseView;
	}
	
	
	@RequestMapping(method = RequestMethod.POST, value = "/benchmark")
	public ResponseView<List<BenchmarkResponse>> getBenchmark(@RequestBody BenchmarkRequest request, HttpServletRequest httpRequest) {
		ResponseView<List<BenchmarkResponse>> responseView = new ResponseView<>();
		try {
			List<BenchmarkResponse> responseList = comparativeIdentifierFilterService.getBenchMark(request);
			responseView.setData(responseList);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(ACIISSTConstants.NA);
			logDetail.setUserId( ACIISSTConstants.NA);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);

		}
		return responseView;
	}
	


}
