package com.anthem.aciisst.filter.web.view.request;

import com.anthem.aciisst.account.web.view.response.BaseAccountStructureDTO;

public class BenchmarkRequest  extends BaseAccountStructureDTO{
	
	private String moduleName;

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}


}
