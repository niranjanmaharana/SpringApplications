package com.anthem.aciisst.filter.web.view.response;

import java.util.List;

import com.anthem.aciisst.account.web.view.response.KeyValueResponse;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class ComparitiveIdentifierResponseView {
	@JsonInclude(Include.NON_NULL)
	private List<KeyValueResponse> hcc;
	@JsonInclude(Include.NON_NULL)
	private List<KeyValueResponse> coverage;
	@JsonInclude(Include.NON_NULL)
	private List<KeyValueResponse> ageBand;
	@JsonInclude(Include.NON_NULL)
	private List<KeyValueResponse> gender;
	@JsonInclude(Include.NON_NULL)
	private List<KeyValueResponse> relationship;
	@JsonInclude(Include.NON_NULL)
	private List<KeyValueResponse> healthStatus;
	@JsonInclude(Include.NON_NULL)
	private List<KeyValueResponse> engagement;
	@JsonInclude(Include.NON_NULL)
	private List<KeyValueResponse> msa;
	@JsonInclude(Include.NON_NULL)
	private List<KeyValueResponse> state;
	@JsonInclude(Include.NON_NULL)
	private List<KeyValueResponse> membershipBenchmark;
	
	
	
	public List<KeyValueResponse> getCoverage() {
		return coverage;
	}
	public void setCoverage(List<KeyValueResponse> coverage) {
		this.coverage = coverage;
	}
	public List<KeyValueResponse> getHcc() {
		return hcc;
	}
	public void setHcc(List<KeyValueResponse> hcc) {
		this.hcc = hcc;
	}
	public List<KeyValueResponse> getAgeBand() {
		return ageBand;
	}
	public void setAgeBand(List<KeyValueResponse> ageBand) {
		this.ageBand = ageBand;
	}
	public List<KeyValueResponse> getGender() {
		return gender;
	}
	public void setGender(List<KeyValueResponse> gender) {
		this.gender=gender;
		
	}
	public List<KeyValueResponse> getRelationship() {
		return relationship;
	}
	public void setRelationship(List<KeyValueResponse> relationship) {
		this.relationship = relationship;
	}
	public List<KeyValueResponse> getHealthStatus() {
		return healthStatus;
	}
	public void setHealthStatus(List<KeyValueResponse> healthStatus) {
		this.healthStatus=healthStatus;
	}
	public List<KeyValueResponse> getEngagement() {
		return engagement;
	}
	public void setEngagement(List<KeyValueResponse> engagement) {
		this.engagement = engagement;
	}
	public List<KeyValueResponse> getMsa() {
		return msa;
	}
	public void setMsa(List<KeyValueResponse> msa) {
		this.msa = msa;
	}
	public List<KeyValueResponse> getState() {
		return state;
	}
	public void setState(List<KeyValueResponse> state) {
		this.state = state;
	}
	public List<KeyValueResponse> getMembershipBenchmark() {
		return membershipBenchmark;
	}
	public void setMembershipBenchmark(List<KeyValueResponse> membershipBenchmark) {
		this.membershipBenchmark = membershipBenchmark;
	}
	
	

}
