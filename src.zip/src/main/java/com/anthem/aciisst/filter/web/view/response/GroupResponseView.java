package com.anthem.aciisst.filter.web.view.response;

public class GroupResponseView {

	private String groupName;
	private String groupId;
	
	public GroupResponseView(String groupName, String groupId) {
		super();
		this.groupName = groupName;
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

}
