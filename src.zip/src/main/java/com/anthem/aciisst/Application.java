package com.anthem.aciisst;

import java.util.concurrent.Executor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.anthem.aciisst.common.constants.ACIISSTConstants;

/**
 * Docker MS Prototype!
 *
 */

@SpringBootApplication
@RefreshScope
@EnableAsync
public class Application extends SpringBootServletInitializer
{
	@Value("${export.threads}")
	private String threadpoolsize;
	
    public static void main( String[] args ) {
    	SpringApplication.run(Application.class, args);        
    }
    
    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
    	return builder.build();
    }
    
    @Bean(name = "threadPoolTaskExecutor")
    public Executor threadPoolTaskExecutor() {
    	ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    	int intThreadPoolSize = ACIISSTConstants.DEFAULT_EXPORT_THREAD_POOL_SIZE;
    	
    	if(!StringUtils.isEmpty(threadpoolsize)){
    		intThreadPoolSize = Integer.parseInt(threadpoolsize);
    	}
    	
    	executor.setCorePoolSize(intThreadPoolSize);
    	
    	return executor;
    }
}
