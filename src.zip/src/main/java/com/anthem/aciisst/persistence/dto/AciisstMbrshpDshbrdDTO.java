package com.anthem.aciisst.persistence.dto;

import java.math.BigDecimal;


public class AciisstMbrshpDshbrdDTO  {

	private String acctId;

	private String acctNm;

	private int aciisstSgmntnDimKey;
	
	private long mcid;

	private int sbscrbrMbrMnthCnt;
	
	private int mbrMnthCnt;

	private int ageInYrsNbr;

	private String cntrctTier2TypeDesc;

	private String cntrctTier3TypeDesc;

	private String cntrctTier4OpaDesc;

	private String cntrctTier4OpbDesc;

	private String cntrctTier5TypeDesc;

	private int elgbltyCyMnthEndNbr;

	private String mbrGndrNm;

	private String mbrMdclRxCvrgId;
	
	private String cbsaNm;
	
	private String riskStgValTxt;
	
	private String ageBandDesc;

	private String mbrRltnshpDesc;

	private String stCd;
	
	private BigDecimal dcgWgtdRetrospctvRiskNbr;
	

	public String getAcctId() {
		return acctId;
	}


	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}


	public String getAcctNm() {
		return acctNm;
	}


	public void setAcctNm(String acctNm) {
		this.acctNm = acctNm;
	}


	public int getAciisstSgmntnDimKey() {
		return aciisstSgmntnDimKey;
	}


	public void setAciisstSgmntnDimKey(int aciisstSgmntnDimKey) {
		this.aciisstSgmntnDimKey = aciisstSgmntnDimKey;
	}


	public long getMcid() {
		return mcid;
	}


	public void setMcid(long mcid) {
		this.mcid = mcid;
	}


	public int getSbscrbrMbrMnthCnt() {
		return sbscrbrMbrMnthCnt;
	}


	public void setSbscrbrMbrMnthCnt(int sbscrbrMbrMnthCnt) {
		this.sbscrbrMbrMnthCnt = sbscrbrMbrMnthCnt;
	}


	public int getMbrMnthCnt() {
		return mbrMnthCnt;
	}


	public void setMbrMnthCnt(int mbrMnthCnt) {
		this.mbrMnthCnt = mbrMnthCnt;
	}


	public int getAgeInYrsNbr() {
		return ageInYrsNbr;
	}


	public void setAgeInYrsNbr(int ageInYrsNbr) {
		this.ageInYrsNbr = ageInYrsNbr;
	}


	public String getCntrctTier2TypeDesc() {
		return cntrctTier2TypeDesc;
	}


	public void setCntrctTier2TypeDesc(String cntrctTier2TypeDesc) {
		this.cntrctTier2TypeDesc = cntrctTier2TypeDesc;
	}


	public String getCntrctTier3TypeDesc() {
		return cntrctTier3TypeDesc;
	}


	public void setCntrctTier3TypeDesc(String cntrctTier3TypeDesc) {
		this.cntrctTier3TypeDesc = cntrctTier3TypeDesc;
	}


	public String getCntrctTier4OpaDesc() {
		return cntrctTier4OpaDesc;
	}


	public void setCntrctTier4OpaDesc(String cntrctTier4OpaDesc) {
		this.cntrctTier4OpaDesc = cntrctTier4OpaDesc;
	}


	public String getCntrctTier4OpbDesc() {
		return cntrctTier4OpbDesc;
	}


	public void setCntrctTier4OpbDesc(String cntrctTier4OpbDesc) {
		this.cntrctTier4OpbDesc = cntrctTier4OpbDesc;
	}


	public String getCntrctTier5TypeDesc() {
		return cntrctTier5TypeDesc;
	}


	public void setCntrctTier5TypeDesc(String cntrctTier5TypeDesc) {
		this.cntrctTier5TypeDesc = cntrctTier5TypeDesc;
	}


	public int getElgbltyCyMnthEndNbr() {
		return elgbltyCyMnthEndNbr;
	}


	public void setElgbltyCyMnthEndNbr(int elgbltyCyMnthEndNbr) {
		this.elgbltyCyMnthEndNbr = elgbltyCyMnthEndNbr;
	}


	public String getMbrGndrNm() {
		return mbrGndrNm;
	}


	public void setMbrGndrNm(String mbrGndrNm) {
		this.mbrGndrNm = mbrGndrNm;
	}


	public String getMbrMdclRxCvrgId() {
		return mbrMdclRxCvrgId;
	}


	public void setMbrMdclRxCvrgId(String mbrMdclRxCvrgId) {
		this.mbrMdclRxCvrgId = mbrMdclRxCvrgId;
	}


	public String getCbsaNm() {
		return cbsaNm;
	}


	public void setCbsaNm(String cbsaNm) {
		this.cbsaNm = cbsaNm;
	}


	public String getRiskStgValTxt() {
		return riskStgValTxt;
	}


	public void setRiskStgValTxt(String riskStgValTxt) {
		this.riskStgValTxt = riskStgValTxt;
	}


	public String getAgeBandDesc() {
		return ageBandDesc;
	}


	public void setAgeBandDesc(String ageBandDesc) {
		this.ageBandDesc = ageBandDesc;
	}


	public String getMbrRltnshpDesc() {
		return mbrRltnshpDesc;
	}


	public void setMbrRltnshpDesc(String mbrRltnshpDesc) {
		this.mbrRltnshpDesc = mbrRltnshpDesc;
	}


	public String getStCd() {
		return stCd;
	}


	public void setStCd(String stCd) {
		this.stCd = stCd;
	}


	public BigDecimal getDcgWgtdRetrospctvRiskNbr() {
		return dcgWgtdRetrospctvRiskNbr;
	}


	public void setDcgWgtdRetrospctvRiskNbr(BigDecimal dcgWgtdRetrospctvRiskNbr) {
		this.dcgWgtdRetrospctvRiskNbr = dcgWgtdRetrospctvRiskNbr;
	}


	public AciisstMbrshpDshbrdDTO() {
		//Default Constructor
	}
}