package com.anthem.aciisst.persistence.dto;

public class AciisstRoleDTO  {

	private int roleId;

	private String roleDesc;

	private String roleNm;

	private String userCtgry;

	public int getRoleId() {
		return this.roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getRoleDesc() {
		return this.roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

	public String getRoleNm() {
		return this.roleNm;
	}

	public void setRoleNm(String roleNm) {
		this.roleNm = roleNm;
	}

	public String getUserCtgry() {
		return this.userCtgry;
	}

	public void setUserCtgry(String userCtgry) {
		this.userCtgry = userCtgry;
	}

}