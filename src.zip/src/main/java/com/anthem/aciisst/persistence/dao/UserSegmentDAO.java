package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

@Repository
public class UserSegmentDAO extends AbstractDAO {

	public void deleteUserSegment(String sesnId, int aciisstUserId) throws SQLException {
		
		String query="delete FROM ACIISST_USER_SGMNTN WHERE SESN_ID = ? and ACIISST_USER_ID = ?";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(query);) {
				ps.setString(1, sesnId);
				ps.setInt(2, aciisstUserId);
				ps.executeUpdate();
			
			}
		}
		
	}
}
