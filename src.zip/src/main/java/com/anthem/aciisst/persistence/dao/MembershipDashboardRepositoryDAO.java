package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.account.web.view.response.KeyValueResponse;
import com.anthem.aciisst.account.web.view.response.KpiDTO;

@Repository
public class MembershipDashboardRepositoryDAO extends AbstractDAO {
	
	public List<KeyValueResponse> getDistinctState(String acctId) throws SQLException{
		String selectQuery="select Distinct(d.ST_CD) from  ACIISST_MBRSHP_DSHBRD d  where d.ACCT_ID = ? and LAST_3_DIGT_ACCT_ID = CAST(SUBSTR(?,6,3) AS INTEGER) with UR";
		List<KeyValueResponse>  resultList= new ArrayList<>();

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setString(1, acctId);
				ps.setString(2, acctId);
				try (ResultSet rs = ps.executeQuery();) {
						if(rs!=null) {
							while(rs.next()) {
								
								KeyValueResponse resp= new KeyValueResponse();
								resp.setKey(rs.getString("ST_CD"));
								resp.setValue(rs.getString("ST_CD"));
								resultList.add(resp);
							}
					}
				}
			}
		}

		return resultList;
	}
	
	public List<KeyValueResponse> getDistinctMSA( String acctId) throws SQLException{
		String selectQuery="select Distinct(d.CBSA_NM) from  ACIISST_MBRSHP_DSHBRD d  where d.ACCT_ID = ? and LAST_3_DIGT_ACCT_ID = CAST(SUBSTR(?,6,3) AS INTEGER) with UR";
		List<KeyValueResponse>  resultList= new ArrayList<>();
		
		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setString(1, acctId);
				ps.setString(2, acctId);
				try (ResultSet rs = ps.executeQuery();) {
						if(rs!=null) {
							while(rs.next()) {
							KeyValueResponse resp= new KeyValueResponse();
							resp.setKey(rs.getString("CBSA_NM"));
							resp.setValue(rs.getString("CBSA_NM"));
							resultList.add(resp);
							}
					}
				}
			}
		}
		
		return resultList;
	}
	
	
	public List<List<String>> getClinicalKpi(KpiDTO reqData) throws SQLException {
		List<List<String>> mbrDshbrd = new ArrayList<>();
		
		String selectQuery = queryBuilder(reqData);

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				
				int i = 1;
				if (reqData.getCurrentPeriodStart() != null && reqData.getCurrentPeriodEnd() != null) {
					prepareParameter(ps, reqData.getCurrentPeriodStart(), reqData.getCurrentPeriodEnd(),
							reqData.getAciisstUserId(), reqData.getAccountId(), reqData.getSessionKey(), i);
					i = i + 6;
				}
				if (reqData.getPriorPeriod1End() != null && reqData.getPriorPeriod1Start() != null) {
					prepareParameter(ps, reqData.getPriorPeriod1Start(), reqData.getPriorPeriod1End(),
							reqData.getAciisstUserId(), reqData.getAccountId(), reqData.getSessionKey(), i);
					i = i + 6;
				}
				if (reqData.getPriorPeriod2End() != null && reqData.getPriorPeriod2Start() != null) {
					prepareParameter(ps, reqData.getPriorPeriod2Start(), reqData.getPriorPeriod2End(),
							reqData.getAciisstUserId(), reqData.getAccountId(), reqData.getSessionKey(), i);
				}
				
    			try(ResultSet rs = ps.executeQuery(); ){
    				mbrDshbrd = prepareResult(rs,mbrDshbrd);  
    			}
			}
		}
		
		return mbrDshbrd;
	}
	
	
	public PreparedStatement prepareParameter(PreparedStatement ps, String startDate, String endDate, int userId, String accountId,
			String sessionId, int i) throws SQLException {
		if (startDate != null && endDate != null) {
				ps.setInt(i, userId);
				i++;
				ps.setString(i, accountId);
				i++;
				ps.setString(i, accountId);
				i++;
				ps.setString(i, sessionId);
				i++;
				ps.setString(i, startDate);
				i++;
				ps.setString(i, endDate);
		}
		return ps;
	}
	
	
	public StringBuilder prepareQueryString(StringBuilder stringBuilder) {
		stringBuilder.append("SELECT  DSH.ELGBLTY_CY_MNTH_END_NBR, SUM(DSH.DCG_WGTD_RETROSPCTV_RISK_NBR), SUM(DSH.TOTL_RISKSCORE_MBR_MNTHS_CNT) MNTHS  \n"
				+ "FROM ACIISST_MBRSHP_DSHBRD DSH  \n"
				+ "	INNER JOIN ACIISST_USER_SGMNTN USR  \n"
				+ "		ON DSH.ACIISST_SGMNTN_DIM_KEY = USR.ACIISST_SGMNTN_DIM_KEY AND DSH.ACCT_ID = USR.ACCT_ID  \n"
				+ " WHERE USR.ACIISST_USER_ID = ?  \n" + "       AND DSH.ACCT_ID = ?  \n"
				+ " AND DSH.LAST_3_DIGT_ACCT_ID = CAST(SUBSTR(?,6,3) AS INTEGER) \n"
				+ "       AND USR.SESN_ID = ?  \n"
				+ " 	   AND DSH.ELGBLTY_CY_MNTH_END_NBR >= ? AND DSH.ELGBLTY_CY_MNTH_END_NBR <= ?  \n"
				+ "GROUP BY DSH.ELGBLTY_CY_MNTH_END_NBR \n");
		
		return stringBuilder;
	}

	public String queryBuilder(KpiDTO reqData) {
		StringBuilder stringBuilder = new StringBuilder();

		if (reqData.getCurrentPeriodStart() != null && reqData.getCurrentPeriodEnd() != null) {
			prepareQueryString(stringBuilder);
		}

		if (reqData.getPriorPeriod1End() != null && reqData.getPriorPeriod1Start() != null) {
			stringBuilder=stringBuilder.length()>0?stringBuilder.append(" UNION ALL "):stringBuilder.append("");
			prepareQueryString(stringBuilder);			
		}

		if (reqData.getPriorPeriod2End() != null && reqData.getPriorPeriod2Start() != null) {
			stringBuilder=stringBuilder.length()>0?stringBuilder.append(" UNION ALL "):stringBuilder.append("");
			prepareQueryString(stringBuilder);
			
		}
		stringBuilder.append(" WITH UR ");

		return stringBuilder.toString();
	}
	
	public List<List<String>> prepareResult(ResultSet rs, List<List<String>> mbrDshbrd) throws SQLException {
		if(rs!=null) {			
			while(rs.next()) {
				List<String> innerRow = new ArrayList<>();
				innerRow.add(rs.getString(1));
				innerRow.add(rs.getString(2));
				innerRow.add(rs.getString(3));					
				
				mbrDshbrd.add(innerRow);					
			}
		}
		
		return mbrDshbrd;
		
	}
	

}
