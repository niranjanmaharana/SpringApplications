package com.anthem.aciisst.persistence.dto;


import java.sql.Timestamp;
import java.util.Date;

public class User  {
	private int userId;
	private Date aciisstUserEfctvDt;
	private Date aciisstUserTrmntnDt;
	private int creatdByUserId;
	private Timestamp creatdDtm;
	private String emailId;
	private String firstNm;
	private String lastNm;
	private String lglAgrmntInd;
	private String lognUserId;
	private String notesDescTxt;
	private String scrtyLvlCd;
	private int updtdByUserId;
	private Timestamp updtdDtm;
	private String userTypeCd;
	private String viewPhiInd;
	private String userCategoryCd;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public Date getAciisstUserEfctvDt() {
		return aciisstUserEfctvDt;
	}
	public void setAciisstUserEfctvDt(Date aciisstUserEfctvDt) {
		this.aciisstUserEfctvDt = aciisstUserEfctvDt;
	}
	public Date getAciisstUserTrmntnDt() {
		return aciisstUserTrmntnDt;
	}
	public void setAciisstUserTrmntnDt(Date aciisstUserTrmntnDt) {
		this.aciisstUserTrmntnDt = aciisstUserTrmntnDt;
	}
	public int getCreatdByUserId() {
		return creatdByUserId;
	}
	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}
	public Timestamp getCreatdDtm() {
		return creatdDtm;
	}
	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getFirstNm() {
		return firstNm;
	}
	public void setFirstNm(String firstNm) {
		this.firstNm = firstNm;
	}
	public String getLastNm() {
		return lastNm;
	}
	public void setLastNm(String lastNm) {
		this.lastNm = lastNm;
	}
	public String getLglAgrmntInd() {
		return lglAgrmntInd;
	}
	public void setLglAgrmntInd(String lglAgrmntInd) {
		this.lglAgrmntInd = lglAgrmntInd;
	}
	public String getLognUserId() {
		return lognUserId;
	}
	public void setLognUserId(String lognUserId) {
		this.lognUserId = lognUserId;
	}
	public String getNotesDescTxt() {
		return notesDescTxt;
	}
	public void setNotesDescTxt(String notesDescTxt) {
		this.notesDescTxt = notesDescTxt;
	}
	public String getScrtyLvlCd() {
		return scrtyLvlCd;
	}
	public void setScrtyLvlCd(String scrtyLvlCd) {
		this.scrtyLvlCd = scrtyLvlCd;
	}
	public int getUpdtdByUserId() {
		return updtdByUserId;
	}
	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}
	public Timestamp getUpdtdDtm() {
		return updtdDtm;
	}
	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}
	public String getUserTypeCd() {
		return userTypeCd;
	}
	public void setUserTypeCd(String userTypeCd) {
		this.userTypeCd = userTypeCd;
	}
	public String getViewPhiInd() {
		return viewPhiInd;
	}
	public void setViewPhiInd(String viewPhiInd) {
		this.viewPhiInd = viewPhiInd;
	}
	public String getUserCategoryCd() {
		return userCategoryCd;
	}
	public void setUserCategoryCd(String userCategoryCd) {
		this.userCategoryCd = userCategoryCd;
	}

}