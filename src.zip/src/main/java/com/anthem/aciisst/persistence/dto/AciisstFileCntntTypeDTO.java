package com.anthem.aciisst.persistence.dto;

public class AciisstFileCntntTypeDTO  {

	private String fileCntntTypeCd;

	private String fileCntntTypeDesc;


	public String getFileCntntTypeCd() {
		return this.fileCntntTypeCd;
	}

	public void setFileCntntTypeCd(String fileCntntTypeCd) {
		this.fileCntntTypeCd = fileCntntTypeCd;
	}

	public String getFileCntntTypeDesc() {
		return this.fileCntntTypeDesc;
	}

	public void setFileCntntTypeDesc(String fileCntntTypeDesc) {
		this.fileCntntTypeDesc = fileCntntTypeDesc;
	}

}