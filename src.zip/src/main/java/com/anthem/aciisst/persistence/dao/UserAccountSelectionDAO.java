package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.persistence.dto.UserAcctSlctnDTO;

@Repository
public class UserAccountSelectionDAO extends AbstractDAO {
	
	public int saveRecentlyAccessed(String acctId,int userId) throws SQLException {
		String insertQuery="INSERT INTO ACIISST_USER_ACCT_SLCTN (ACCT_ID ,ACIISST_USER_ID ,SLCTN_DTM , CREATD_DTM ,UPDTD_DTM, CREATD_BY_USER_ID, UPDTD_BY_USER_ID) values(?,?,?,?,?,?,?)";
		int result = -1;
		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(insertQuery);) {
				Calendar calendar = Calendar.getInstance();
				Timestamp currentTimestamp = new Timestamp(calendar.getTime().getTime());

				ps.setString(1, acctId);
				ps.setInt(2, userId);
				ps.setTimestamp(3, currentTimestamp);
				ps.setTimestamp(4, currentTimestamp);
				ps.setTimestamp(5, currentTimestamp);
				ps.setInt(6, userId);
				ps.setInt(7, userId);
				
				result = ps.executeUpdate();
			}
		}
		
		return result;
	}
	
	public int updateRecentlyAccessed(String acctId,int userId) throws SQLException {
		String updateQuery="UPDATE ACIISST_USER_ACCT_SLCTN SET SLCTN_DTM=?, UPDTD_DTM=?, UPDTD_BY_USER_ID=? WHERE ACIISST_USER_ID=? and ACCT_ID =?";
		int result = -1;
		
		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(updateQuery);) {
				Calendar calendar = Calendar.getInstance();
				Timestamp currentTimestamp = new Timestamp(calendar.getTime().getTime());

				ps.setTimestamp(1, currentTimestamp);
				ps.setTimestamp(2, currentTimestamp);
				ps.setInt(3, userId);
				ps.setInt(4, userId);
				ps.setString(5, acctId);

				result = ps.executeUpdate();	
			}
		}

		return result;
	}
	
	
	public UserAcctSlctnDTO getRecentlyAccessed(String acctId,int userId) throws SQLException {
		String selectQuery="Select * from ACIISST_USER_ACCT_SLCTN where ACIISST_USER_ID=? and ACCT_ID=? with UR";
		UserAcctSlctnDTO userAcSl=null;

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setInt(1, userId);
				ps.setString(2, acctId);
				try(ResultSet rs= ps.executeQuery()){
					if(rs!=null) {
						while(rs.next()) {
							 userAcSl= new UserAcctSlctnDTO();
							userAcSl.setAcctId(rs.getString("ACCT_ID"));
							userAcSl.setAciisstUserId(rs.getInt("ACIISST_USER_ID"));
							userAcSl.setSlctnDtm(rs.getTimestamp("SLCTN_DTM"));
							userAcSl.setCreatdByUserId(rs.getInt("CREATD_BY_USER_ID"));
						}
					}
				}
			}
		}

		return userAcSl;
	}

}
