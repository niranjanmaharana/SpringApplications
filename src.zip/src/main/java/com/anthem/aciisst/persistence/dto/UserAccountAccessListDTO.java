package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;
import java.util.Date;


public class UserAccountAccessListDTO {

	private String acctId;

	private int aciisstUserId;

	private java.util.Date userAcctAcsListEfctvDt;
	
	private int creatdByUserId;

	private Timestamp creatdDtm;

	private String grpScrtyFlag;

	private String phiInd;

	private int updtdByUserId;

	private Timestamp updtdDtm;

	private Date userAcctAcsListTrmntnDt;

	

	public String getAcctId() {
		return acctId;
	}

	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}

	public int getAciisstUserId() {
		return aciisstUserId;
	}

	public void setAciisstUserId(int aciisstUserId) {
		this.aciisstUserId = aciisstUserId;
	}

	public java.util.Date getUserAcctAcsListEfctvDt() {
		return userAcctAcsListEfctvDt;
	}

	public void setUserAcctAcsListEfctvDt(java.util.Date userAcctAcsListEfctvDt) {
		this.userAcctAcsListEfctvDt = userAcctAcsListEfctvDt;
	}

	public int getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getGrpScrtyFlag() {
		return this.grpScrtyFlag;
	}

	public void setGrpScrtyFlag(String grpScrtyFlag) {
		this.grpScrtyFlag = grpScrtyFlag;
	}

	public String getPhiInd() {
		return this.phiInd;
	}

	public void setPhiInd(String phiInd) {
		this.phiInd = phiInd;
	}

	public int getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	
	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Timestamp getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

	public Date getUserAcctAcsListTrmntnDt() {
		return this.userAcctAcsListTrmntnDt;
	}

	public void setUserAcctAcsListTrmntnDt(Date userAcctAcsListTrmntnDt) {
		this.userAcctAcsListTrmntnDt = userAcctAcsListTrmntnDt;
	}

}