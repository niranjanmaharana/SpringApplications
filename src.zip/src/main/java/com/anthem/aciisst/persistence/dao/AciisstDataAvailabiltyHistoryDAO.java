package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.stereotype.Repository;

@Repository
public class AciisstDataAvailabiltyHistoryDAO extends AbstractDAO {
	
	public Date getDataAvailabilityHistory() throws SQLException {
		Date date=null;
		String selectQuery = "select max(DATA_THRU_DT) as DATA_THRU_DT  from ACIISST_DATA_AVLBLTY_HIST where upper( ACTV_IND)='Y' and upper( SUBJ_AREA_TXT)='CLAIMS' with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				try (ResultSet rs = ps.executeQuery();) {
					if (rs != null) {
						while(rs.next()) {						
							date=rs.getDate("DATA_THRU_DT");
						}
					}
				}
			}
		}

		return date;
		
	}
	
}
