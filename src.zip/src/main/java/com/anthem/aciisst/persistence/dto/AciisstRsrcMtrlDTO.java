package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;
import java.util.Date;

 
public class AciisstRsrcMtrlDTO {

	private int rscId;
	
	private Date rscEfctvDt;

	private Date rscTrmntnDt;

	private String actInd;
	
	private String allAcctInd;
	
	private String fileCntntTypeCd;

	private int ctgryOdrNbr;

	private int rscMtrlOdrNbr;

	private Timestamp creatdDtm;

	private Timestamp updtdDtm;

	private int creatdByUserId;

	private int updtdByUserId;

	private String fileNm;

	private String rscMtrlNm;

	private String contact;

	private String rscMtrlTxt;

	private byte[] fileDcmnt;
	
	private String userCtgryCd;

	private String rscCtgryCd;
	
	private String rscCtgryShrtNm;


	public int getRscId() {
		return rscId;
	}

	public Date getRscEfctvDt() {
		return rscEfctvDt;
	}

	public Date getRscTrmntnDt() {
		return rscTrmntnDt;
	}

	public String getActInd() {
		return actInd;
	}

	public String getAllAcctInd() {
		return allAcctInd;
	}

	public String getFileCntntTypeCd() {
		return fileCntntTypeCd;
	}

	public int getCtgryOdrNbr() {
		return ctgryOdrNbr;
	}

	public int getRscMtrlOdrNbr() {
		return rscMtrlOdrNbr;
	}

	public Timestamp getCreatdDtm() {
		return creatdDtm;
	}

	public Timestamp getUpdtdDtm() {
		return updtdDtm;
	}

	public int getCreatdByUserId() {
		return creatdByUserId;
	}

	public int getUpdtdByUserId() {
		return updtdByUserId;
	}

	public String getFileNm() {
		return fileNm;
	}

	public String getRscMtrlNm() {
		return rscMtrlNm;
	}

	public String getContact() {
		return contact;
	}

	public String getRscMtrlTxt() {
		return rscMtrlTxt;
	}

	public byte[] getFileDcmnt() {
		return fileDcmnt;
	}

	public void setRscId(int rscId) {
		this.rscId = rscId;
	}

	public void setRscEfctvDt(Date rscEfctvDt) {
		this.rscEfctvDt = rscEfctvDt;
	}

	public void setRscTrmntnDt(Date rscTrmntnDt) {
		this.rscTrmntnDt = rscTrmntnDt;
	}

	public void setActInd(String actInd) {
		this.actInd = actInd;
	}

	public void setAllAcctInd(String allAcctInd) {
		this.allAcctInd = allAcctInd;
	}

	public void setFileCntntTypeCd(String fileCntntTypeCd) {
		this.fileCntntTypeCd = fileCntntTypeCd;
	}

	public void setCtgryOdrNbr(int ctgryOdrNbr) {
		this.ctgryOdrNbr = ctgryOdrNbr;
	}

	public void setRscMtrlOdrNbr(int rscMtrlOdrNbr) {
		this.rscMtrlOdrNbr = rscMtrlOdrNbr;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}

	public void setRscMtrlNm(String rscMtrlNm) {
		this.rscMtrlNm = rscMtrlNm;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public void setRscMtrlTxt(String rscMtrlTxt) {
		this.rscMtrlTxt = rscMtrlTxt;
	}

	public void setFileDcmnt(byte[] fileDcmnt) {
		this.fileDcmnt = fileDcmnt;
	}

	public String getUserCtgryCd() {
		return userCtgryCd;
	}

	public String getRscCtgryCd() {
		return rscCtgryCd;
	}

	public void setUserCtgryCd(String userCtgryCd) {
		this.userCtgryCd = userCtgryCd;
	}

	public void setRscCtgryCd(String rscCtgryCd) {
		this.rscCtgryCd = rscCtgryCd;
	}

	public String getRscCtgryShrtNm() {
		return rscCtgryShrtNm;
	}

	public void setRscCtgryShrtNm(String rscCtgryShrtNm) {
		this.rscCtgryShrtNm = rscCtgryShrtNm;
	}


}