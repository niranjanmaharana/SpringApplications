package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;


public class UserSegmentDTO  {

	private int creatdByUserId;

	private Timestamp creatdDtm;

	private int updtdByUserId;

	private Timestamp updtdDtm;
	
	private String acctId;

	private int aciisstUserId;

	private String sesnId;
	
	private int aciisstSgmntnDimKey;

	
	public int getAciisstSgmntnDimKey() {
		return this.aciisstSgmntnDimKey;
	}

	public void setAciisstSgmntnDimKey(int aciisstSgmntnDimKey) {
		this.aciisstSgmntnDimKey = aciisstSgmntnDimKey;
	}
	public String getAcctId() {
		return this.acctId;
	}
	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}
	public int getAciisstUserId() {
		return this.aciisstUserId;
	}
	public void setAciisstUserId(int aciisstUserId) {
		this.aciisstUserId = aciisstUserId;
	}
	public String getSesnId() {
		return this.sesnId;
	}
	public void setSesnId(String sesnId) {
		this.sesnId = sesnId;
	}

	public UserSegmentDTO() {
		//Default constructor
	}

	public int getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public int getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Timestamp getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

}