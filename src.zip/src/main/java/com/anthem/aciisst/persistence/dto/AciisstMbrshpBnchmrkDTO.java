package com.anthem.aciisst.persistence.dto;

public class AciisstMbrshpBnchmrkDTO{
	
	private String bnchmrkCtgryNm;

	private String bnchmrkSbctgryNm;

	public String getBnchmrkCtgryNm() {
		return this.bnchmrkCtgryNm;
	}

	public void setBnchmrkCtgryNm(String bnchmrkCtgryNm) {
		this.bnchmrkCtgryNm = bnchmrkCtgryNm;
	}

	public String getBnchmrkSbctgryNm() {
		return this.bnchmrkSbctgryNm;
	}

	public void setBnchmrkSbctgryNm(String bnchmrkSbctgryNm) {
		this.bnchmrkSbctgryNm = bnchmrkSbctgryNm;
	}


}