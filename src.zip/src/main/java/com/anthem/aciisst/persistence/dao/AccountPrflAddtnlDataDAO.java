package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.persistence.dto.AccountProfileAdditionalDataDTO;

@Repository
public class AccountPrflAddtnlDataDAO extends AbstractDAO {

	public AccountProfileAdditionalDataDTO getElegibilityCyMonthEnd(String accountId) throws SQLException {
		AccountProfileAdditionalDataDTO accProfileAddlData = null;
		String selectQuery = "Select * from ACIISST_ACCT_PRFL_ADDNL_DATA  where ACCT_ID =? with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				pstmt.setString(1, accountId);
				try (ResultSet rs = pstmt.executeQuery();) {
					while (rs.next()) {
						accProfileAddlData = new AccountProfileAdditionalDataDTO();
						accProfileAddlData.setAcctId(rs.getString("ACCT_ID"));
						accProfileAddlData.setElgbltyCyMnthEndNbr(rs.getInt("ELGBLTY_CY_MNTH_END_NBR"));
						accProfileAddlData.setCreatdByUserId(rs.getInt("CREATD_BY_USER_ID"));
					}
				}
			}
		}

		return accProfileAddlData;
	}

}
