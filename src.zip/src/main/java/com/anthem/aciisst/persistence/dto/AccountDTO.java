package com.anthem.aciisst.persistence.dto;

import java.sql.Date;
import java.sql.Timestamp;

public class AccountDTO{

	private String accountId;

	private String accountName;

	private String acctSizeClsfctnCd;

	private Date acctEfctvDt;

	private Date acctTrmntnDt;

	private String securityLvlCode;

	private String dsplyStts;

	private String dsplyDept;

	private String dsplyGrpRptg1Cd;

	private String dsplyGrpRptg2Cd;

	private String dsplyGrpRptg3Cd;

	private String dsplyRlup1Cd;

	private String dsplyRlup2Cd;

	private String dsplyRlup3Cd;

	private String dsplyRlup4Cd;

	private String dfltHccThrshldAmt;

	private Integer acctPlanMnthNbr;

	private String dfltPaidAmtTypeDesc;

	private String dfltTmPrdCd;

	private String grpRptg1LblCd;

	private String grpRptg2LblCd;

	private String grpRptg3LblCd;

	private String subgrpRptg1LblCd;

	private String subgrpRptg2LblCd;

	private String subgrpRptg3LblCd;

	private String subgrpRptg4LblCd;

	private String membershipTierValCnt;

	private String rptgBrndLogoCd;

	private String rptgDsplyDeptInd;

	private String rptgDsplyGrpRptg1Cd;

	private String rptgDsplyGrpRptg2Cd;

	private String rptgDsplyGrpRptg3Cd;

	private String rptgDsplyRlup1Cd;

	private String rptgDsplyRlup2Cd;

	private String rptgDsplyRlup3Cd;

	private String rptgDsplyRlup4Cd;

	private String rptgDsplySttsCd;

	private String rptgExcldBenchMarkInd;

	private int creatdByUserId;

	private Timestamp creatdDtm;

	private int updtdByUserId;

	private Timestamp updtdDtm;

	public String getSecurityLvlCode() {
		return securityLvlCode;
	}

	public void setSecurityLvlCode(String securityLvlCode) {
		this.securityLvlCode = securityLvlCode;
	}

	public String getAccountId() {
		return this.accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public Date getAcctEfctvDt() {
		return this.acctEfctvDt;
	}

	public void setAcctEfctvDt(Date acctEfctvDt) {
		this.acctEfctvDt = acctEfctvDt;
	}

	public String getAccountName() {
		return this.accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public Date getAcctTrmntnDt() {
		return this.acctTrmntnDt;
	}

	public void setAcctTrmntnDt(Date acctTrmntnDt) {
		this.acctTrmntnDt = acctTrmntnDt;
	}

	public int getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public int getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Timestamp getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

	public String getSubgrpRptg1LblCd() {
		return subgrpRptg1LblCd;
	}

	public void setSubgrpRptg1LblCd(String subgrpRptg1LblCd) {
		this.subgrpRptg1LblCd = subgrpRptg1LblCd;
	}

	public String getSubgrpRptg2LblCd() {
		return subgrpRptg2LblCd;
	}

	public void setSubgrpRptg2LblCd(String subgrpRptg2LblCd) {
		this.subgrpRptg2LblCd = subgrpRptg2LblCd;
	}

	public String getSubgrpRptg3LblCd() {
		return subgrpRptg3LblCd;
	}

	public void setSubgrpRptg3LblCd(String subgrpRptg3LblCd) {
		this.subgrpRptg3LblCd = subgrpRptg3LblCd;
	}

	public String getGrpRptg1LblCd() {
		return grpRptg1LblCd;
	}

	public void setGrpRptg1LblCd(String grpRptg1LblCd) {
		this.grpRptg1LblCd = grpRptg1LblCd;
	}

	public String getGrpRptg2LblCd() {
		return grpRptg2LblCd;
	}

	public void setGrpRptg2LblCd(String grpRptg2LblCd) {
		this.grpRptg2LblCd = grpRptg2LblCd;
	}

	public String getGrpRptg3LblCd() {
		return grpRptg3LblCd;
	}

	public void setGrpRptg3LblCd(String grpRptg3LblCd) {
		this.grpRptg3LblCd = grpRptg3LblCd;
	}

	public String getDfltPaidAmtTypeDesc() {
		return dfltPaidAmtTypeDesc;
	}

	public void setDfltPaidAmtTypeDesc(String dfltPaidAmtTypeDesc) {
		this.dfltPaidAmtTypeDesc = dfltPaidAmtTypeDesc;
	}

	public String getDsplyDept() {
		return dsplyDept;
	}

	public void setDsplyDept(String dsplyDept) {
		this.dsplyDept = dsplyDept;
	}

	public String getDsplyGrpRptg1Cd() {
		return dsplyGrpRptg1Cd;
	}

	public void setDsplyGrpRptg1Cd(String dsplyGrpRptg1Cd) {
		this.dsplyGrpRptg1Cd = dsplyGrpRptg1Cd;
	}

	public String getDsplyGrpRptg2Cd() {
		return dsplyGrpRptg2Cd;
	}

	public void setDsplyGrpRptg2Cd(String dsplyGrpRptg2Cd) {
		this.dsplyGrpRptg2Cd = dsplyGrpRptg2Cd;
	}

	public String getDsplyGrpRptg3Cd() {
		return dsplyGrpRptg3Cd;
	}

	public void setDsplyGrpRptg3Cd(String dsplyGrpRptg3Cd) {
		this.dsplyGrpRptg3Cd = dsplyGrpRptg3Cd;
	}

	public String getDsplyRlup1Cd() {
		return dsplyRlup1Cd;
	}

	public void setDsplyRlup1Cd(String dsplyRlup1Cd) {
		this.dsplyRlup1Cd = dsplyRlup1Cd;
	}

	public String getDsplyRlup2Cd() {
		return dsplyRlup2Cd;
	}

	public void setDsplyRlup2Cd(String dsplyRlup2Cd) {
		this.dsplyRlup2Cd = dsplyRlup2Cd;
	}

	public String getDsplyRlup3Cd() {
		return dsplyRlup3Cd;
	}

	public void setDsplyRlup3Cd(String dsplyRlup3Cd) {
		this.dsplyRlup3Cd = dsplyRlup3Cd;
	}

	public String getDsplyRlup4Cd() {
		return dsplyRlup4Cd;
	}

	public void setDsplyRlup4Cd(String dsplyRlup4Cd) {
		this.dsplyRlup4Cd = dsplyRlup4Cd;
	}

	public String getDsplyStts() {
		return dsplyStts;
	}

	public void setDsplyStts(String dsplyStts) {
		this.dsplyStts = dsplyStts;
	}

	public Integer getAcctPlanMnthNbr() {
		return acctPlanMnthNbr;
	}

	public void setAcctPlanMnthNbr(Integer acctPlanMnthNbr) {
		this.acctPlanMnthNbr = acctPlanMnthNbr;
	}

	public String getAcctSizeClsfctnCd() {
		return acctSizeClsfctnCd;
	}

	public void setAcctSizeClsfctnCd(String acctSizeClsfctnCd) {
		this.acctSizeClsfctnCd = acctSizeClsfctnCd;
	}

	public String getDfltHccThrshldAmt() {
		return dfltHccThrshldAmt;
	}

	public void setDfltHccThrshldAmt(String dfltHccThrshldAmt) {
		this.dfltHccThrshldAmt = dfltHccThrshldAmt;
	}

	public String getDfltTmPrdCd() {
		return dfltTmPrdCd;
	}

	public void setDfltTmPrdCd(String dfltTmPrdCd) {
		this.dfltTmPrdCd = dfltTmPrdCd;
	}

	public String getSubgrpRptg4LblCd() {
		return subgrpRptg4LblCd;
	}

	public void setSubgrpRptg4LblCd(String subgrpRptg4LblCd) {
		this.subgrpRptg4LblCd = subgrpRptg4LblCd;
	}

	public String getMembershipTierValCnt() {
		return membershipTierValCnt;
	}

	public void setMembershipTierValCnt(String membershipTierValCnt) {
		this.membershipTierValCnt = membershipTierValCnt;
	}

	public String getRptgBrndLogoCd() {
		return rptgBrndLogoCd;
	}

	public void setRptgBrndLogoCd(String rptgBrndLogoCd) {
		this.rptgBrndLogoCd = rptgBrndLogoCd;
	}

	public String getRptgDsplyDeptInd() {
		return rptgDsplyDeptInd;
	}

	public void setRptgDsplyDeptInd(String rptgDsplyDeptInd) {
		this.rptgDsplyDeptInd = rptgDsplyDeptInd;
	}

	public String getRptgDsplyGrpRptg1Cd() {
		return rptgDsplyGrpRptg1Cd;
	}

	public void setRptgDsplyGrpRptg1Cd(String rptgDsplyGrpRptg1Cd) {
		this.rptgDsplyGrpRptg1Cd = rptgDsplyGrpRptg1Cd;
	}

	public String getRptgDsplyGrpRptg2Cd() {
		return rptgDsplyGrpRptg2Cd;
	}

	public void setRptgDsplyGrpRptg2Cd(String rptgDsplyGrpRptg2Cd) {
		this.rptgDsplyGrpRptg2Cd = rptgDsplyGrpRptg2Cd;
	}

	public String getRptgDsplyGrpRptg3Cd() {
		return rptgDsplyGrpRptg3Cd;
	}

	public void setRptgDsplyGrpRptg3Cd(String rptgDsplyGrpRptg3Cd) {
		this.rptgDsplyGrpRptg3Cd = rptgDsplyGrpRptg3Cd;
	}

	public String getRptgDsplyRlup1Cd() {
		return rptgDsplyRlup1Cd;
	}

	public void setRptgDsplyRlup1Cd(String rptgDsplyRlup1Cd) {
		this.rptgDsplyRlup1Cd = rptgDsplyRlup1Cd;
	}

	public String getRptgDsplyRlup2Cd() {
		return rptgDsplyRlup2Cd;
	}

	public void setRptgDsplyRlup2Cd(String rptgDsplyRlup2Cd) {
		this.rptgDsplyRlup2Cd = rptgDsplyRlup2Cd;
	}

	public String getRptgDsplyRlup3Cd() {
		return rptgDsplyRlup3Cd;
	}

	public void setRptgDsplyRlup3Cd(String rptgDsplyRlup3Cd) {
		this.rptgDsplyRlup3Cd = rptgDsplyRlup3Cd;
	}

	public String getRptgDsplyRlup4Cd() {
		return rptgDsplyRlup4Cd;
	}

	public void setRptgDsplyRlup4Cd(String rptgDsplyRlup4Cd) {
		this.rptgDsplyRlup4Cd = rptgDsplyRlup4Cd;
	}

	public String getRptgDsplySttsCd() {
		return rptgDsplySttsCd;
	}

	public void setRptgDsplySttsCd(String rptgDsplySttsCd) {
		this.rptgDsplySttsCd = rptgDsplySttsCd;
	}

	public String getRptgExcldBenchMarkInd() {
		return rptgExcldBenchMarkInd;
	}

	public void setRptgExcldBenchMarkInd(String rptgExcldBenchMarkInd) {
		this.rptgExcldBenchMarkInd = rptgExcldBenchMarkInd;
	}

	

}