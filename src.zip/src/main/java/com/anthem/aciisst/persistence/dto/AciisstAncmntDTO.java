package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;
import java.util.Date;

 
public class AciisstAncmntDTO {

	private int ancmntId;

	private String allAcctInd;

	private String alrtInd;

	private String ancmntDesc;

	private Date ancmntEfctvDt;

	private Date ancmntTrmntnDt;

	private int creatdByUserId;

	private Timestamp creatdDtm;

	private String dcmntTtlShrtNm;

	private String fileCntntTypeCd;

	private byte[] fileDcmnt;

	private int updtdByUserId;

	private Timestamp updtdDtm;
	
	private String fileName;

	public int getAncmntId() {
		return this.ancmntId;
	}

	public void setAncmntId(int ancmntId) {
		this.ancmntId = ancmntId;
	}

	public String getAllAcctInd() {
		return this.allAcctInd;
	}

	public void setAllAcctInd(String allAcctInd) {
		this.allAcctInd = allAcctInd;
	}

	public String getAlrtInd() {
		return this.alrtInd;
	}

	public void setAlrtInd(String alrtInd) {
		this.alrtInd = alrtInd;
	}

	public String getAncmntDesc() {
		return this.ancmntDesc;
	}

	public void setAncmntDesc(String ancmntDesc) {
		this.ancmntDesc = ancmntDesc;
	}

	public Date getAncmntEfctvDt() {
		return this.ancmntEfctvDt;
	}

	public void setAncmntEfctvDt(Date ancmntEfctvDt) {
		this.ancmntEfctvDt = ancmntEfctvDt;
	}

	public Date getAncmntTrmntnDt() {
		return this.ancmntTrmntnDt;
	}

	public void setAncmntTrmntnDt(Date ancmntTrmntnDt) {
		this.ancmntTrmntnDt = ancmntTrmntnDt;
	}

	public int getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getDcmntTtlShrtNm() {
		return this.dcmntTtlShrtNm;
	}

	public void setDcmntTtlShrtNm(String dcmntTtlShrtNm) {
		this.dcmntTtlShrtNm = dcmntTtlShrtNm;
	}

	public String getFileCntntTypeCd() {
		return this.fileCntntTypeCd;
	}

	public void setFileCntntTypeCd(String fileCntntTypeCd) {
		this.fileCntntTypeCd = fileCntntTypeCd;
	}

	public byte[] getFileDcmnt() {
		return this.fileDcmnt;
	}

	public void setFileDcmnt(byte[] fileDcmnt) {
		this.fileDcmnt = fileDcmnt;
	}

	public int getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Timestamp getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}