package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.anthem.aciisst.persistence.dto.AppPropertyDTO;

@Repository
public class AppPropertyDAO extends AbstractDAO {

	public AppPropertyDTO getFilterValueFromAppProperty(String prptyName) throws SQLException {
		List<AppPropertyDTO> appPrprtyList=new ArrayList<>();
		String selectQuery = "select  ACIISST_PRPTY_ID,  ACIISST_PRPTY_CD ,  ACIISST_PRPTY_NM,  ACIISST_PRPTY_VAL_DESC ,  ACIISST_PRPTY_VAL_TXT from ACIISST_PRPTY  where  ACIISST_PRPTY_NM=? with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setString(1, prptyName);
				try (ResultSet rs = ps.executeQuery();) {
					prepareAppProperty(rs, appPrprtyList);
				}
			}
		}

		
		if(!CollectionUtils.isEmpty(appPrprtyList)) {
			return appPrprtyList.get(0);
			
		}
		return null;
		
	}
	
	public List<AppPropertyDTO> getMWValueFromAppProperty(String propertyCd) throws SQLException{
		List<AppPropertyDTO> appPrprtyList=new ArrayList<>();
		String selectQuery = "select  ACIISST_PRPTY_ID,  ACIISST_PRPTY_CD ,  ACIISST_PRPTY_NM,  ACIISST_PRPTY_VAL_DESC ,  ACIISST_PRPTY_VAL_TXT from ACIISST_PRPTY  where  ACIISST_PRPTY_CD=? with UR";
		
		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setString(1, propertyCd);
				try (ResultSet rs = ps.executeQuery();) {
					prepareAppProperty(rs, appPrprtyList);
				}
			}
		}
		
		return appPrprtyList;
	}
	
	public List<AppPropertyDTO> findAll() throws SQLException{
		List<AppPropertyDTO> appPrprtyList=new ArrayList<>();
		String selectQuery = "select * from ACIISST_PRPTY  with UR";

			try (Connection connObj = dataSource.getConnection();) {
				try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
					try (ResultSet rs = ps.executeQuery();) {
						prepareAppProperty(rs, appPrprtyList);
					}
				}
			}

		return appPrprtyList;
	}
	
	public void prepareAppProperty(ResultSet rs,List<AppPropertyDTO> appPrprtyList) throws SQLException {		
		if(rs!=null) {			

			while(rs.next()) {		
				AppPropertyDTO appPrprty= new AppPropertyDTO();
				appPrprty.setAciisstPrptyCd(rs.getString("ACIISST_PRPTY_CD"));
				appPrprty.setAciisstPrptyId(rs.getInt("ACIISST_PRPTY_ID"));
				appPrprty.setAciisstPrptyNm(rs.getString("ACIISST_PRPTY_NM"));
				appPrprty.setAciisstPrptyValDesc(rs.getString("ACIISST_PRPTY_VAL_DESC"));
				appPrprty.setAciisstPrptyValTxt(rs.getString("ACIISST_PRPTY_VAL_TXT"));
				appPrprtyList.add(appPrprty);
			}

		}		
	}
}
