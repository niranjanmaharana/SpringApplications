package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.persistence.dto.User;

@Repository
public class UserDAO extends AbstractDAO {

	public User findByLognUserId(String userId) throws SQLException  {
		User user = null;
		String selectQuery = "SELECT * FROM ACIISST_USER WHERE UPPER(LOGN_USER_ID)=UPPER(?) with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setString(1, userId);
				try(ResultSet rs= ps.executeQuery()){
					user = prepareResult(rs, user);
				}
			}
		}

		return user;
	}

	public User findActiveUserByLognUserId(String userId) throws SQLException {
		User user = null;
		String selectQuery = " select * from ACIISST_USER  where upper(LOGN_USER_ID)=upper(?) and CURRENT_DATE>=ACIISST_USER_EFCTV_DT and ACIISST_USER_TRMNTN_DT>CURRENT_DATE with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setString(1, userId);
				try(ResultSet rs= ps.executeQuery()){
					user = prepareResult(rs, user);
				}
			}
		}

		return user;
	}

	public User prepareResult(ResultSet rs, User user) throws SQLException {
		if (rs != null) {
			user = new User();
			
			while (rs.next()) {
				user.setUserId(rs.getInt("ACIISST_USER_ID"));
				user.setEmailId(rs.getString("EMAIL_ID"));
				user.setFirstNm(rs.getString("FIRST_NM"));
				user.setLastNm(rs.getString("LAST_NM"));
				user.setLglAgrmntInd(rs.getString("LGL_AGRMNT_IND"));
				user.setLognUserId(rs.getString("LOGN_USER_ID"));
				user.setNotesDescTxt(rs.getString("NOTES_DESC_TXT"));
				user.setScrtyLvlCd(rs.getString("SCRTY_LVL_CD"));
				user.setUpdtdByUserId(rs.getInt("UPDTD_BY_USER_ID"));
				user.setUpdtdDtm(rs.getTimestamp("UPDTD_DTM"));
				user.setUserTypeCd(rs.getString("USER_TYPE_CD"));
				user.setViewPhiInd(rs.getString("VIEW_PHI_IND"));
				user.setUserCategoryCd(rs.getString("USER_CTGRY_CD"));

			}
		}
		return user;
	}
}
