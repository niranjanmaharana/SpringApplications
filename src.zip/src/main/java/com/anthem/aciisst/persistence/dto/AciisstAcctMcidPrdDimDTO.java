package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;
import java.util.Date;



public class AciisstAcctMcidPrdDimDTO  {

	private String acctId;

	private int creatdByUserId;

	private Timestamp creatdDtm;

	private Date endDt;

	private int endYearMnthNbr;

	private String enggmntTypeDesc;

	private int enhncdId;

	private int expnddId;

	private int hcostClmCtgryAmt;

	private long mcid;

	private String riskStgValDesc;

	private Date strtDt;

	private int strtYearMnthNbr;

	private String tmPrdTypeCd;

	private int trdtnlId;

	private int updtdByUserId;

	private Timestamp updtdDtm;

	private int yearId;

	public AciisstAcctMcidPrdDimDTO() {
		//default constructor
	}

	public String getAcctId() {
		return this.acctId;
	}

	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}

	public int getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Date getEndDt() {
		return this.endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

	public int getEndYearMnthNbr() {
		return this.endYearMnthNbr;
	}

	public void setEndYearMnthNbr(int endYearMnthNbr) {
		this.endYearMnthNbr = endYearMnthNbr;
	}

	public String getEnggmntTypeDesc() {
		return this.enggmntTypeDesc;
	}

	public void setEnggmntTypeDesc(String enggmntTypeDesc) {
		this.enggmntTypeDesc = enggmntTypeDesc;
	}

	public int getEnhncdId() {
		return this.enhncdId;
	}

	public void setEnhncdId(int enhncdId) {
		this.enhncdId = enhncdId;
	}

	public int getExpnddId() {
		return this.expnddId;
	}

	public void setExpnddId(int expnddId) {
		this.expnddId = expnddId;
	}

	public int getHcostClmCtgryAmt() {
		return this.hcostClmCtgryAmt;
	}

	public void setHcostClmCtgryAmt(int hcostClmCtgryAmt) {
		this.hcostClmCtgryAmt = hcostClmCtgryAmt;
	}

	public long getMcid() {
		return this.mcid;
	}

	public void setMcid(long mcid) {
		this.mcid = mcid;
	}

	public String getRiskStgValDesc() {
		return this.riskStgValDesc;
	}

	public void setRiskStgValDesc(String riskStgValDesc) {
		this.riskStgValDesc = riskStgValDesc;
	}

	public Date getStrtDt() {
		return this.strtDt;
	}

	public void setStrtDt(Date strtDt) {
		this.strtDt = strtDt;
	}

	public int getStrtYearMnthNbr() {
		return this.strtYearMnthNbr;
	}

	public void setStrtYearMnthNbr(int strtYearMnthNbr) {
		this.strtYearMnthNbr = strtYearMnthNbr;
	}

	public String getTmPrdTypeCd() {
		return this.tmPrdTypeCd;
	}

	public void setTmPrdTypeCd(String tmPrdTypeCd) {
		this.tmPrdTypeCd = tmPrdTypeCd;
	}

	public int getTrdtnlId() {
		return this.trdtnlId;
	}

	public void setTrdtnlId(int trdtnlId) {
		this.trdtnlId = trdtnlId;
	}

	public int getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Timestamp getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

	public int getYearId() {
		return this.yearId;
	}

	public void setYearId(int yearId) {
		this.yearId = yearId;
	}

}