package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.persistence.dto.UserExportDTO;

@Repository
public class UserExportDAO extends AbstractDAO {
	
	public UserExportDTO findUserExport( String exportId,int userId) throws SQLException{
		UserExportDTO usrExp=null;
		String selectQuery="select * from ACIISST_USER_EXPRT  where EXPRT_ID = ? and ACIISST_USER_ID= ? with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setString(1, exportId);
				ps.setInt(2, userId);
				try(ResultSet rs=ps.executeQuery();){
					if(rs!=null) {
						while(rs.next()) {
							usrExp= new UserExportDTO();
							usrExp.setAciisstUserId(rs.getInt("ACIISST_USER_ID"));
							usrExp.setFileNm(rs.getString("FILE_NM"));
							usrExp.setFileTypeCd(rs.getString("FILE_TYPE_CD"));
							usrExp.setSbmtDtm(rs.getTimestamp("SBMT_DTM"));
							usrExp.setSttsCd(rs.getString("STTS_CD"));
							usrExp.setExprtId(rs.getString("EXPRT_ID"));	
						}
					}
					
				}
			}
		}
		
		return usrExp;
		
	}
	

	public List<UserExportDTO> findExportsByUserID( Integer userId) throws SQLException{
		List<UserExportDTO> resultList= new ArrayList<>();
		String selectQuery = "select * from ACIISST_USER_EXPRT  where ACIISST_USER_ID= ?  AND STTS_CD IN ('COMPLETED','PENDING','ERROR') with UR";
		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setInt(1, userId);
				try(ResultSet rs = ps.executeQuery();){
					if(rs!=null) {
						
						while(rs.next()) {
							UserExportDTO	userEx = new UserExportDTO();
							userEx.setAciisstUserId(rs.getInt("ACIISST_USER_ID"));
							userEx.setFileNm(rs.getString("FILE_NM"));
							userEx.setFileTypeCd(rs.getString("FILE_TYPE_CD"));
							userEx.setSbmtDtm(rs.getTimestamp("SBMT_DTM"));
							userEx.setSttsCd(rs.getString("STTS_CD"));
							userEx.setExprtId(rs.getString("EXPRT_ID"));					
							resultList.add(userEx);						
						}					
					}
				}
			}
		}

		return resultList;
	}
	
	public void saveUserExport(UserExportDTO usrExp) throws SQLException {
		String insertQuery="Insert into ACIISST_USER_EXPRT (EXPRT_ID,ACIISST_USER_ID,FILE_NM,FILE_TYPE_CD,STTS_CD, ENTTLMNT_ID,CREATD_DTM,CREATD_BY_USER_ID,"
				+ "SBMT_DTM,EXPRT_DTM,UPDTD_BY_USER_ID,UPDTD_DTM) values (?,?,?,?,?, ?,?,?,?,? ,?,?)";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(insertQuery);){
				int count=0;	
				ps.setString(++count, usrExp.getExprtId());
				ps.setInt(++count, usrExp.getAciisstUserId());
				ps.setString(++count, usrExp.getFileNm());
				ps.setString(++count, usrExp.getFileTypeCd());
				ps.setString(++count, usrExp.getSttsCd());
				ps.setString(++count, usrExp.getEnttlmntId());
				ps.setTimestamp(++count, usrExp.getCreatdDtm());
				ps.setInt(++count, usrExp.getCreatdByUserId());
				ps.setTimestamp(++count, usrExp.getSbmtDtm());
				ps.setTimestamp(++count, usrExp.getExprtDtm());
				ps.setInt(++count, usrExp.getUpdtdByUserId());
				ps.setTimestamp(++count, usrExp.getUpdtdDtm());
				ps.executeUpdate();					
			}
		}
	}
	
	
	public void updateUserExport(UserExportDTO usrExp) throws SQLException {
		String updateQuery="UPDATE ACIISST_USER_EXPRT SET STTS_CD=? ,ERR_TXT=? ,UPDTD_DTM=? WHERE EXPRT_ID=? and ACIISST_USER_ID=? ";
		Calendar calendar = Calendar.getInstance();
		Timestamp currentTimestamp = new Timestamp(calendar.getTime().getTime());

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(updateQuery);){
				int count=0;	
				ps.setString(++count, usrExp.getSttsCd());
				ps.setString(++count, usrExp.getErrTxt());					
				ps.setTimestamp(++count, currentTimestamp);
				ps.setString(++count, usrExp.getExprtId());
				ps.setInt(++count, usrExp.getAciisstUserId());
				
				ps.executeUpdate();	
			
			}
		}
	}
}
