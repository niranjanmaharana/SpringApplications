package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;


public class AppPropertyDTO  {
	private Integer aciisstPrptyId;

	private String aciisstPrptyNm;
	
	private String aciisstPrptyCd;

	private String aciisstPrptyValDesc;

	private String aciisstPrptyValTxt;

	private Integer creatdByUserId;

	private Timestamp creatdDtm;

	private Integer updtdByUserId;

	private Timestamp updtdDtm;

	public int getAciisstPrptyId() {
		return this.aciisstPrptyId;
	}

	public String getAciisstPrptyNm() {
		return aciisstPrptyNm;
	}

	public void setAciisstPrptyNm(String aciisstPrptyNm) {
		this.aciisstPrptyNm = aciisstPrptyNm;
	}

	public String getAciisstPrptyValDesc() {
		return aciisstPrptyValDesc;
	}

	public void setAciisstPrptyValDesc(String aciisstPrptyValDesc) {
		this.aciisstPrptyValDesc = aciisstPrptyValDesc;
	}

	public String getAciisstPrptyValTxt() {
		return aciisstPrptyValTxt;
	}

	public void setAciisstPrptyValTxt(String aciisstPrptyValTxt) {
		this.aciisstPrptyValTxt = aciisstPrptyValTxt;
	}

	public Integer getCreatdByUserId() {
		return creatdByUserId;
	}

	public void setCreatdByUserId(Integer creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Integer getUpdtdByUserId() {
		return updtdByUserId;
	}

	public void setUpdtdByUserId(Integer updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Timestamp getUpdtdDtm() {
		return updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

	public void setAciisstPrptyId(Integer aciisstPrptyId) {
		this.aciisstPrptyId = aciisstPrptyId;
	}

	public String getAciisstPrptyCd() {
		return aciisstPrptyCd;
	}

	public void setAciisstPrptyCd(String aciisstPrptyCd) {
		this.aciisstPrptyCd = aciisstPrptyCd;
	}

	
}