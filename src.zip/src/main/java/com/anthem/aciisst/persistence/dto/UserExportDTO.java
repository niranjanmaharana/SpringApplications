package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;


public class UserExportDTO{
	private String exprtId;

	private int aciisstUserId;
	
	private int creatdByUserId;
	private Timestamp creatdDtm;

	private String enttlmntId;

	private String errTxt;

	private Timestamp exprtDtm;

	private String fileNm;

	private String fileTypeCd;

	private Timestamp sbmtDtm;

	private String sttsCd;

	private int updtdByUserId;

	private Timestamp updtdDtm;
	
	public int getAciisstUserId() {
		return aciisstUserId;
	}

	public String getExprtId() {
		return this.exprtId;
	}
	public void setExprtId(String exprtId) {
		this.exprtId = exprtId;
	}
	
	public void setAciisstUserId(int aciisstUserId) {
		this.aciisstUserId = aciisstUserId;
	}

	

	public int getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getEnttlmntId() {
		return this.enttlmntId;
	}

	public void setEnttlmntId(String enttlmntId) {
		this.enttlmntId = enttlmntId;
	}

	public String getErrTxt() {
		return this.errTxt;
	}

	public void setErrTxt(String errTxt) {
		this.errTxt = errTxt;
	}

	public Timestamp getExprtDtm() {
		return this.exprtDtm;
	}

	public void setExprtDtm(Timestamp exprtDtm) {
		this.exprtDtm = exprtDtm;
	}

	public String getFileNm() {
		return this.fileNm;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}

	public String getFileTypeCd() {
		return this.fileTypeCd;
	}

	public void setFileTypeCd(String fileTypeCd) {
		this.fileTypeCd = fileTypeCd;
	}

	public Timestamp getSbmtDtm() {
		return this.sbmtDtm;
	}

	public void setSbmtDtm(Timestamp sbmtDtm) {
		this.sbmtDtm = sbmtDtm;
	}

	public String getSttsCd() {
		return this.sttsCd;
	}

	public void setSttsCd(String sttsCd) {
		this.sttsCd = sttsCd;
	}

	public int getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Timestamp getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

}