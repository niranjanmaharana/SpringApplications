package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;

public class AciisstUserAncmntReadDTO {

	private int ancmntId;

	private int aciisstUserId;

	private int creatdByUserId;

	private Timestamp creatdDtm;

	private int updtdByUserId;

	private Timestamp updtdDtm;

	

	public int getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public int getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public int getAncmntId() {
		return ancmntId;
	}

	public void setAncmntId(int ancmntId) {
		this.ancmntId = ancmntId;
	}

	public int getAciisstUserId() {
		return aciisstUserId;
	}

	public void setAciisstUserId(int aciisstUserId) {
		this.aciisstUserId = aciisstUserId;
	}

	public Timestamp getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}


}