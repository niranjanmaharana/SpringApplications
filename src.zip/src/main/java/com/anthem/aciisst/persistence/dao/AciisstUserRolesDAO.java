package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.persistence.dto.AciisstRoleDTO;

@Repository
public class AciisstUserRolesDAO extends AbstractDAO {

	public List<AciisstRoleDTO> getUserRoles(int userId) throws SQLException {
		List<AciisstRoleDTO> roles = new ArrayList<>();
		String selectQuery = "select roles.ROLE_ID, roles.ROLE_NM from ACIISST_ROLE roles join ACIISST_USER_ROLE role on ACIISST_USER_ID = ? "
				+ "and roles.role_id = role.role_id where current_date >= role.user_role_efctv_dt "
				+ "and  coalesce(role.USER_ROLE_TRMNTN_DT,'8888-12-31') > current_date with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setInt(1, userId);
				try (ResultSet rs = ps.executeQuery();) {
					roles = prepareResult(rs, roles);
				}
			}
		}

		return roles;
	}

	public List<AciisstRoleDTO> prepareResult(ResultSet rs, List<AciisstRoleDTO> rolesList) throws SQLException {
		if (rs != null) {
			rolesList = new ArrayList<>();

			while (rs.next()) {
				AciisstRoleDTO role = new AciisstRoleDTO();
				role.setRoleId(rs.getInt("ROLE_ID"));
				role.setRoleNm(rs.getString("ROLE_NM"));
				rolesList.add(role);
			}

		}

		return rolesList;

	}
}
