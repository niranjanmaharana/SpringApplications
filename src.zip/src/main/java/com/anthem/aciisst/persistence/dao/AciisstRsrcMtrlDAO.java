package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.persistence.dto.AciisstRsrcMtrlDTO;

@Repository
public class AciisstRsrcMtrlDAO extends AbstractDAO {
	
	/**
	 * Query to fetch the records based on the user category
	 * @param ctgrycd
	 * @return
	 * @throws SQLException
	 */
	public List<AciisstRsrcMtrlDTO> getAllUserResources(String ctgrycd) throws SQLException{
		List<AciisstRsrcMtrlDTO> rsrcList= new ArrayList<>();
		String selectQuery = "select ctg.RSRC_SHRT_NM ,rsrc.* from ACIISST_RSRC_MTRL rsrc "
				+ " inner join ACIISST_CMMN.ACIISST_RSRC_CTGRY ctg on(rsrc.RSRC_CTGRY_CD = ctg.RSRC_CTGRY_CD) "
				+ " where rsrc.USER_CTGRY_CD in (?,'3')"
				+ " and CURRENT DATE between rsrc.RSRC_MTRL_EFCTV_DT and coalesce(rsrc.RSRC_MTRL_TRMNTN_DT, TO_DATE('8888-12-31','YYYY-MM-DD')) "
				+ "order by rsrc.RSRC_MTRL_EFCTV_DT desc with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				int i=0;
				pstmt.setString(++i, ctgrycd);
				
				try (ResultSet resultSet = pstmt.executeQuery();) {
					prepareResult(resultSet,rsrcList);
				}
			}
		} 
		return rsrcList;
	}

	/**
	 * 
	 * @param resultSet
	 * @param rsrcList
	 * @throws SQLException
	 */
	private void prepareResult(ResultSet resultSet, List<AciisstRsrcMtrlDTO> rsrcList) throws SQLException {
		if(resultSet!=null){
			while(resultSet.next()){
				AciisstRsrcMtrlDTO aciisstRsrcMtrlDTO= new AciisstRsrcMtrlDTO();
				aciisstRsrcMtrlDTO.setRscId(resultSet.getInt("RSRC_MTRL_ID"));
				aciisstRsrcMtrlDTO.setRscMtrlNm(resultSet.getString("RSRC_MTRL_NM"));
				aciisstRsrcMtrlDTO.setRscMtrlTxt(resultSet.getString("RSRC_MTRL_TXT"));
				aciisstRsrcMtrlDTO.setRscEfctvDt(resultSet.getDate("RSRC_MTRL_EFCTV_DT"));
				aciisstRsrcMtrlDTO.setFileCntntTypeCd(resultSet.getString("FILE_CNTNT_TYPE_CD"));
				aciisstRsrcMtrlDTO.setFileDcmnt(resultSet.getBytes("FILE_DCMNT"));
				aciisstRsrcMtrlDTO.setFileNm(resultSet.getString("FILE_NM"));
				aciisstRsrcMtrlDTO.setRscCtgryCd(resultSet.getString("RSRC_CTGRY_CD"));
				aciisstRsrcMtrlDTO.setRscCtgryShrtNm(resultSet.getString("RSRC_SHRT_NM"));
				rsrcList.add(aciisstRsrcMtrlDTO);			
			}
		}
		
	}

	/**
	 * Query to fetch resource based on the resource ID
	 * @param rsrcId
	 * @return
	 * @throws SQLException
	 */
	public AciisstRsrcMtrlDTO getResource(int rsrcId) throws SQLException {
		AciisstRsrcMtrlDTO aciisstRsrcMtrlDTO= new AciisstRsrcMtrlDTO();
		String selectQuery ="select rsrc.* from ACIISST_RSRC_MTRL rsrc where rsrc.RSRC_MTRL_ID =? with UR ";
		
		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				pstmt.setInt(1, rsrcId);	
				try (ResultSet resultSet = pstmt.executeQuery();) {
					if(resultSet!=null){
						while(resultSet.next()){							
							aciisstRsrcMtrlDTO.setRscId(resultSet.getInt("RSRC_MTRL_ID"));
							aciisstRsrcMtrlDTO.setRscMtrlNm(resultSet.getString("RSRC_MTRL_NM"));
							aciisstRsrcMtrlDTO.setRscMtrlTxt(resultSet.getString("RSRC_MTRL_TXT"));
							aciisstRsrcMtrlDTO.setRscEfctvDt(resultSet.getDate("RSRC_MTRL_EFCTV_DT"));
							aciisstRsrcMtrlDTO.setFileCntntTypeCd(resultSet.getString("FILE_CNTNT_TYPE_CD"));
							aciisstRsrcMtrlDTO.setFileDcmnt(resultSet.getBytes("FILE_DCMNT"));
							aciisstRsrcMtrlDTO.setFileNm(resultSet.getString("FILE_NM"));
							aciisstRsrcMtrlDTO.setRscCtgryCd(resultSet.getString("RSRC_CTGRY_CD"));
						}
					}	
				}
			}
		}
		return aciisstRsrcMtrlDTO; 
	}

}
	
