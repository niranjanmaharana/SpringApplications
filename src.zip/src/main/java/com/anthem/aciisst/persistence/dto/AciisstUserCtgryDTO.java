package com.anthem.aciisst.persistence.dto;

public class AciisstUserCtgryDTO  {

	private String userCtgryCd;

	private String userCtgryDesc;

	public String getUserCtgryCd() {
		return this.userCtgryCd;
	}

	public void setUserCtgryCd(String userCtgryCd) {
		this.userCtgryCd = userCtgryCd;
	}

	public String getUserCtgryDesc() {
		return this.userCtgryDesc;
	}

	public void setUserCtgryDesc(String userCtgryDesc) {
		this.userCtgryDesc = userCtgryDesc;
	}
}