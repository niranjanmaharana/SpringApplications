package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;


public class AccountProfileAdditionalDataDTO {

	private String acctId;

	private int creatdByUserId;

	private Timestamp creatdDtm;

	private int elgbltyCyMnthEndNbr;

	private int updtdByUserId;

	private Timestamp updtdDtm;

	public AccountProfileAdditionalDataDTO() {
		//Default constructor
	}

	public String getAcctId() {
		return this.acctId;
	}

	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}

	public int getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public int getElgbltyCyMnthEndNbr() {
		return this.elgbltyCyMnthEndNbr;
	}

	public void setElgbltyCyMnthEndNbr(int elgbltyCyMnthEndNbr) {
		this.elgbltyCyMnthEndNbr = elgbltyCyMnthEndNbr;
	}

	public int getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Timestamp getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

}