package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.persistence.dto.AciisstUserCtgryDTO;

@Repository
public class AciisstUserCategoryDAO extends AbstractDAO {

	public AciisstUserCtgryDTO getUserCategory(String userCode) throws SQLException {
		AciisstUserCtgryDTO category = null;
		String selectQuery = "select USER_CTGRY_CD, USER_CTGRY_DESC from ACIISST_USER_CTGRY  where USER_CTGRY_CD=? with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setString(1, userCode);
				try (ResultSet rs = ps.executeQuery();) {
					category =prepareResult(rs, category);
				}
			}
		}
		
		return category;
	}

	public AciisstUserCtgryDTO prepareResult(ResultSet rs, AciisstUserCtgryDTO category) throws SQLException {
		if (rs != null) {
			category = new AciisstUserCtgryDTO();

			while (rs.next()) {
				category.setUserCtgryCd(rs.getString("USER_CTGRY_CD"));
				category.setUserCtgryDesc(rs.getString("USER_CTGRY_DESC"));
			}
		}

		return category;

	}
}
