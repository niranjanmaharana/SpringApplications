package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.persistence.dto.UserAccountAccessListDTO;

@Repository
public class UserAccountAccessDAO extends AbstractDAO {

	public UserAccountAccessListDTO findOneActive(String accountId,  int userId) throws SQLException {
		UserAccountAccessListDTO userAsc=null;
		String selectQuery = "select  userAcct.* from ACIISST_USER_ACCT_ACS_LIST  userAcct where  userAcct.ACCT_ID=? "
				+ "and  userAcct.ACIISST_USER_ID=? and current_date>= userAcct.USER_ACCT_ACS_LIST_EFCTV_DT "
				+ "and  userAcct.USER_ACCT_ACS_LIST_TRMNTN_DT>current_date  with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setString(1, accountId);
				ps.setInt(2, userId);
				try(ResultSet rs = ps.executeQuery();){
					while(rs.next()) {
						userAsc= new UserAccountAccessListDTO();
						userAsc.setGrpScrtyFlag(rs.getString("GRP_SCRTY_FLAG"));
						userAsc.setPhiInd(rs.getString("PHI_IND"));
						
					}					
				}
			}
		}
		
		return userAsc;
		
	}
	
	public UserAccountAccessListDTO prepareUserAcsResult(ResultSet rs) throws SQLException{
		UserAccountAccessListDTO userAsc=null;
		if(rs!=null) {
			while(rs.next()) {
				userAsc= new UserAccountAccessListDTO();
				userAsc.setGrpScrtyFlag(rs.getString("GRP_SCRTY_FLAG"));
				userAsc.setPhiInd(rs.getString("PHI_IND"));
			}
		}
			
	return userAsc;	
	}
}
