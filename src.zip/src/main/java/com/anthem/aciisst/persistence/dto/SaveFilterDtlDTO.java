package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;


public class SaveFilterDtlDTO {
	private int saveFltrId;
	private String filterParamName;
	private String filterCode;
	private String filterValue;
	private String actvFlagCd;
	private int creatdByUserId;
	private Timestamp creatdDtm;
	private int updtdByUserId;
	private Timestamp updtdDtm;
	
	private String name;
	private String description;
	private String typeCd;
	private String acctId;
	private String saveFltrActiveFlag;
	
	public int getSaveFltrId() {
		return saveFltrId;
	}
	public void setSaveFltrId(int saveFltrId) {
		this.saveFltrId = saveFltrId;
	}
	public String getFilterParamName() {
		return filterParamName;
	}
	public void setFilterParamName(String filterParamName) {
		this.filterParamName = filterParamName;
	}
	public String getFilterCode() {
		return filterCode;
	}
	public void setFilterCode(String filterCode) {
		this.filterCode = filterCode;
	}
	public String getFilterValue() {
		return filterValue;
	}
	public void setFilterValue(String filterValue) {
		this.filterValue = filterValue;
	}
	public String getActvFlagCd() {
		return actvFlagCd;
	}
	public void setActvFlagCd(String actvFlagCd) {
		this.actvFlagCd = actvFlagCd;
	}
	public int getCreatdByUserId() {
		return creatdByUserId;
	}
	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}
	public Timestamp getCreatdDtm() {
		return creatdDtm;
	}
	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}
	public int getUpdtdByUserId() {
		return updtdByUserId;
	}
	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}
	public Timestamp getUpdtdDtm() {
		return updtdDtm;
	}
	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTypeCd() {
		return typeCd;
	}
	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}
	public String getAcctId() {
		return acctId;
	}
	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}
	public String getSaveFltrActiveFlag() {
		return saveFltrActiveFlag;
	}
	public void setSaveFltrActiveFlag(String saveFltrActiveFlag) {
		this.saveFltrActiveFlag = saveFltrActiveFlag;
	}

}