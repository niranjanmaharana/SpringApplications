package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.filter.web.view.response.BenchmarkResponse;
@Repository
public class ClinicalBenchmarkDAO extends AbstractDAO {
	public List<BenchmarkResponse> getClinicalBenchmark() throws SQLException{
		List<BenchmarkResponse> resultList= new ArrayList<>();
		String selectQuery= "SELECT DISTINCT BNCHMRK_SBCTGRY_NM  AS CODE , BNCHMRK_SBCTGRY_NM AS DESCRIPTION FROM ACIISST_CLNCL_BNCHMRK  with UR";
		
		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				try (ResultSet rs = ps.executeQuery();) {
					while(rs.next()) {
						BenchmarkResponse br =  new BenchmarkResponse();
						br.setCode(rs.getString("CODE"));
						br.setDescription(rs.getString("DESCRIPTION"));
						resultList.add(br);			
					}
				}
			}
		}

		return resultList;
		
	}
}
