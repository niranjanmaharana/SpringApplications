package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;
import java.util.Date;

public class AciisstUserRoleDTO  {

	private int roleId;

	private int aciisstUserId;

	private Date userRoleEfctvDt;

	private int creatdByUserId;

	private Timestamp creatdDtm;

	private int updtdByUserId;

	private Timestamp updtdDtm;

	private Date userRoleTrmntnDt;

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public int getAciisstUserId() {
		return aciisstUserId;
	}

	public void setAciisstUserId(int aciisstUserId) {
		this.aciisstUserId = aciisstUserId;
	}

	public java.util.Date getUserRoleEfctvDt() {
		return userRoleEfctvDt;
	}

	public void setUserRoleEfctvDt(java.util.Date userRoleEfctvDt) {
		this.userRoleEfctvDt = userRoleEfctvDt;
	}

	public int getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public int getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Timestamp getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

	public Date getUserRoleTrmntnDt() {
		return this.userRoleTrmntnDt;
	}

	public void setUserRoleTrmntnDt(Date userRoleTrmntnDt) {
		this.userRoleTrmntnDt = userRoleTrmntnDt;
	}

}