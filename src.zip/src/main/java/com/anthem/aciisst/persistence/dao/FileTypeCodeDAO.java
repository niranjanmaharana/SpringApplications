package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.persistence.dto.AciisstFileCntntTypeDTO;

@Repository
public class FileTypeCodeDAO extends AbstractDAO {

	public AciisstFileCntntTypeDTO findFileTypeCode(String code) throws SQLException {
		AciisstFileCntntTypeDTO fileType=null;
		String selectQuery = "SELECT * FROM ACIISST_FILE_CNTNT_TYPE WHERE FILE_CNTNT_TYPE_CD=? with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setString(1, code);
				try (ResultSet rs = ps.executeQuery();) {
					if(rs!=null) {						
						while(rs.next()) {
							fileType= new AciisstFileCntntTypeDTO();
							fileType.setFileCntntTypeCd(rs.getString("FILE_CNTNT_TYPE_CD"));
							fileType.setFileCntntTypeDesc(rs.getString("FILE_CNTNT_TYPE_DESC"));
						}
					}
				}
			}
		}

		return fileType;
	}

}
