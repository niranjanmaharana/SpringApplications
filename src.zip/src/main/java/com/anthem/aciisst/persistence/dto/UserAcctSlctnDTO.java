package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;

public class UserAcctSlctnDTO {

	
	private String acctId;

	private int aciisstUserId;

	private int creatdByUserId;

	private Timestamp creatdDtm;

	private Timestamp slctnDtm;

	private int updtdByUserId;

	private Timestamp updtdDtm;

	
	public String getAcctId() {
		return acctId;
	}

	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}

	public int getAciisstUserId() {
		return aciisstUserId;
	}

	public void setAciisstUserId(int aciisstUserId) {
		this.aciisstUserId = aciisstUserId;
	}

	public int getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Timestamp getSlctnDtm() {
		return this.slctnDtm;
	}

	public void setSlctnDtm(Timestamp slctnDtm) {
		this.slctnDtm = slctnDtm;
	}

	public int getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Timestamp getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

}