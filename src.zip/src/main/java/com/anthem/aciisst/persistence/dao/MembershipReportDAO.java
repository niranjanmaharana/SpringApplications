package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.reports.web.view.request.MembershipReportRequest;

@Repository
public class MembershipReportDAO extends AbstractDAO {

	public List<Object[]> getMembershiprReportData(MembershipReportRequest reportreq, boolean total,
			String contactType) throws SQLException {
		List<Object[]> resultList= new ArrayList<>();

		String selectQuery = queryBuilder(reportreq);

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				setParameters(ps,reportreq);
				try (ResultSet rs = ps.executeQuery();) {
					if(rs!=null) {
						while(rs.next()) {
							Object[] obj= new Object[7];
							obj[0]=rs.getObject(1);
							obj[1]=rs.getObject(2);
							obj[2]=rs.getObject(3);
							obj[3]=rs.getObject(4);
							obj[4]=rs.getObject(5);
							obj[5]=rs.getObject(6);
							obj[6]=rs.getObject(7);
							resultList.add(obj);
						}
						
					}
				}
			}
		}
		
		return resultList;

	}

	public void setParameters(PreparedStatement query, MembershipReportRequest reportreq) throws SQLException {
		int i = 0;
		if (!ACIISSTConstants.CUSTOM.equalsIgnoreCase(reportreq.getTimeperiodType())) {
			query.setInt(++i, reportreq.getAciisstUserId());
			query.setString(++i, reportreq.getSessionKey());
		}
		
		query.setString(++i, reportreq.getAccountId());
		query.setString(++i, reportreq.getAccountId());
		query.setString(++i, reportreq.getSessionKey());
		query.setInt(++i, reportreq.getAciisstUserId());

		if (!(CollectionUtils.isEmpty(reportreq.getAgeBand()))) {
			for (String age : reportreq.getAgeBand()) {
				query.setString(++i, age);
			}
		}
		if (!(CollectionUtils.isEmpty(reportreq.getGender()))) {
			for (String gender : reportreq.getGender()) {
				query.setString(++i, gender);
			}
		}

		if ("Pharmacy".equalsIgnoreCase(reportreq.getCoverageType())) {
			reportreq.setCoverageType("RX");
		}
		query.setString(++i, reportreq.getCoverageType());


		if (!(CollectionUtils.isEmpty(reportreq.getRelationship()))) {
			for (String str : reportreq.getRelationship()) {

				query.setString(++i, str);
			}
		}
		if (!(CollectionUtils.isEmpty(reportreq.getHealthStatus()))) {
			for (String str : reportreq.getHealthStatus()) {
				query.setString(++i, str);
			}
		}
		
		if (!(CollectionUtils.isEmpty(reportreq.getMsa()))) {
			for (String str : reportreq.getMsa()) {
				query.setString(++i, str);
			}
		}
		if (!(CollectionUtils.isEmpty(reportreq.getState()))) {
			for (String str : reportreq.getState()) {
				query.setString(++i, str);
			}
		}

		if (!CollectionUtils.isEmpty(reportreq.getEngagement())
				&& !ACIISSTConstants.CUSTOM.equalsIgnoreCase(reportreq.getTimeperiodType())) {
			for (String str : reportreq.getEngagement()) {
				query.setString(++i, str);
			}
		}
		if (reportreq.getCurrentPeriodStart() != null && reportreq.getCurrentPeriodEnd() != null ) {
			query.setString(++i, reportreq.getCurrentPeriodStart());
			query.setString(++i, reportreq.getCurrentPeriodEnd());
		}
		if (reportreq.getPriorPeriod1End() != null && reportreq.getPriorPeriod1Start()!=null) {
			query.setString(++i, reportreq.getPriorPeriod1Start());
			query.setString(++i, reportreq.getPriorPeriod1End());
		}
		if (reportreq.getPriorPeriod2End() != null && reportreq.getPriorPeriod2Start()!=null) {
		
				query.setString(++i, reportreq.getPriorPeriod2Start());
			query.setString(++i, reportreq.getPriorPeriod2End());
		}
	}

	public String queryBuilder(MembershipReportRequest reportreq) {
		StringBuilder stringBuilder = new StringBuilder();
		String tierLevel = reportreq.getTierLevel();

		stringBuilder.append("SELECT ").append(tierLevel).append(", \r\n" + " R.ELGBLTY_CY_MNTH_END_NBR, \r\n"
				+ "          SUM(R.SBSCRBR_MBR_MNTH_CNT) AS SUBSCRIBER_MNTHS_TOTAL,\r\n"
				+ "          SUM(R.MBR_MNTH_CNT) AS MBR_MNTHS_TOTAL, \r\n"
				+ "          COALESCE(SUM(R.MBR_MNTH_CNT)/NULLIF(SUM(R.SBSCRBR_MBR_MNTH_CNT),0),0) AS AVG_MBR_PER_CNTRCT,\r\n"
				+ "          COALESCE(SUM(R.AGE_IN_YRS_NBR)/NULLIF(SUM(R.MBR_MNTH_CNT),0),0) AS MBR_AVG_AGE, \r\n"
				+ "          COALESCE(SUM(case when R.RPTG_MBR_RLTNSHP_CD=1 then R.AGE_IN_YRS_NBR else 0 end)/NULLIF(SUM(R.SBSCRBR_MBR_MNTH_CNT),0),0) AS SUBSCRIBER_AVG_AGE \r\n"
				+ " FROM ACIISST_MBRSHP_DSHBRD AS R\r\n");
		if (!ACIISSTConstants.CUSTOM.equalsIgnoreCase(reportreq.getTimeperiodType())) {

			stringBuilder.append(" LEFT JOIN ( SELECT ENGGMT.MCID, ENGGMT.YEAR_MNTH_NBR, \r\n"
					+ " CASE WHEN ENGGMT.TRDTNL_ID = 1 THEN 'Primary' \r\n"
					+ " WHEN ENGGMT.TRDTNL_ID = 0 AND ENHNCD_ID = 1 THEN 'Enhanced' \r\n"
					+ " WHEN ENGGMT.TRDTNL_ID = 0 AND ENHNCD_ID = 0 AND EXPNDD_ID = 1 THEN 'Comprehensive Only' \r\n"
					+ " ELSE 'Not Engaged' END AS ENGGMNT_TYPE_DESC \r\n"
					+ " FROM \r\n"
					+ "  (select * from  ACIISST_CLNCL_ENGGMNT_DTL \r\n"
					+ "      WHERE MCID in \r\n"
					+ "        ( SELECT DISTINCT MCID FROM  ACIISST_ACCT_MCID_PRD_DIM mbrs  \r\n "
					+ "            INNER JOIN  ACIISST_USER_SGMNTN SGMNT \r\n "
					+ "            ON mbrs.ACCT_ID = SGMNT.ACCT_ID AND SGMNT.ACIISST_USER_ID = ? AND SGMNT.SESN_ID = ? \r\n ) "
					+ "  ) ENGGMT \r\n "
					+ " ) D \r\n "
					+ " ON R.MCID = D.MCID AND R.ELGBLTY_CY_MNTH_END_NBR = D.YEAR_MNTH_NBR \r\n ");
		}
		stringBuilder
				.append(" INNER JOIN  ACIISST_USER_SGMNTN S \n" + "          ON R.ACCT_ID = S.ACCT_ID\r\n"
						+ "          AND R.ACIISST_SGMNTN_DIM_KEY = S.ACIISST_SGMNTN_DIM_KEY");

		stringBuilder.append(" WHERE S.ACCT_ID = ? AND R.LAST_3_DIGT_ACCT_ID = CAST(SUBSTR(?,6,3) AS INTEGER) and S.SESN_ID = ? and S.ACIISST_USER_ID = ?");

		if (!(CollectionUtils.isEmpty(reportreq.getAgeBand()))) {
			stringBuilder.append(" AND R.AGE_BAND_DESC IN ").append(appendQue(reportreq.getAgeBand()));
		}
		if (!(CollectionUtils.isEmpty(reportreq.getGender()))) {
			stringBuilder.append(" AND R.MBR_GNDR_NM IN ").append(appendQue(reportreq.getGender()));
		}

		stringBuilder.append(" AND R.MBR_MDCL_RX_CVRG_ID=? ");
		
		if (!(CollectionUtils.isEmpty(reportreq.getRelationship()))) {
			stringBuilder.append(" AND R.MBR_RLTNSHP_DESC IN  ").append(appendQue(reportreq.getRelationship()));
		}
		if (!(CollectionUtils.isEmpty(reportreq.getHealthStatus()))) {
			stringBuilder.append(" AND R.RISK_STG_VAL_TXT IN ").append(appendQue(reportreq.getHealthStatus()));
		}
		
		if (!(CollectionUtils.isEmpty(reportreq.getMsa()))) {
			stringBuilder.append(" AND R.CBSA_NM IN ").append(appendQue(reportreq.getMsa()));
		}
		if (!(CollectionUtils.isEmpty(reportreq.getState()))) {
			stringBuilder.append(" and R.ST_CD IN ").append(appendQue(reportreq.getState()));
		}
		if (!CollectionUtils.isEmpty(reportreq.getEngagement())
				&& !ACIISSTConstants.CUSTOM.equalsIgnoreCase(reportreq.getTimeperiodType())) {
			stringBuilder.append(" and D.ENGGMNT_TYPE_DESC IN ").append(appendQue(reportreq.getEngagement()));
		}
		stringBuilder.append(" GROUP BY R.ELGBLTY_CY_MNTH_END_NBR,");
		if (reportreq.getTierLevel() != null) {
			stringBuilder.append(" R.").append(tierLevel);
		}
		if (reportreq.getCurrentPeriodStart() != null && reportreq.getCurrentPeriodEnd() != null) {
			stringBuilder.append(" HAVING ( R.ELGBLTY_CY_MNTH_END_NBR >= ?")
					.append(" AND R.ELGBLTY_CY_MNTH_END_NBR <= ? )");																		

		}
		if (reportreq.getPriorPeriod1End() != null && reportreq.getPriorPeriod1Start() != null) {
			stringBuilder.append(" OR ( R.ELGBLTY_CY_MNTH_END_NBR >= ? ")
					.append(" AND R.ELGBLTY_CY_MNTH_END_NBR <= ?) ");
																		

		}
		if (reportreq.getPriorPeriod2End() != null && reportreq.getPriorPeriod2Start() != null) {
			stringBuilder.append(" OR ( R.ELGBLTY_CY_MNTH_END_NBR >= ?")
					.append(" AND R.ELGBLTY_CY_MNTH_END_NBR <= ? )");

		}

		if (reportreq.getTierLevel() != null) {
			stringBuilder.append("  ORDER BY  R.").append(reportreq.getTierLevel())
					.append(" asc ");
		}
		stringBuilder.append(" with UR ");

		return stringBuilder.toString();

	}


	public String appendQue(List<String> list) {
		StringBuilder sb = new StringBuilder();
		sb.append("(");
		for (int i = 0; i < list.size(); i++) {
			sb.append("?,");
		}
		sb.deleteCharAt(sb.length() - 1);
		sb.append(")");
		return sb.toString();
	}

}
