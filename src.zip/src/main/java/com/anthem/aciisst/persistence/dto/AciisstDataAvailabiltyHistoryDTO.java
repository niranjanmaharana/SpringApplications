package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;
import java.util.Date;


public class AciisstDataAvailabiltyHistoryDTO  {
	private String actvInd;

	private int creatdByUserId;

	private Timestamp creatdDtm;

	private Date dataThruDt;
	private String subjAreaTxt;

	private int updtdByUserId;

	private Timestamp updtdDtm;

	public String getActvInd() {
		return this.actvInd;
	}

	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}

	public int getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Date getDataThruDt() {
		return this.dataThruDt;
	}

	public void setDataThruDt(Date dataThruDt) {
		this.dataThruDt = dataThruDt;
	}

	public String getSubjAreaTxt() {
		return this.subjAreaTxt;
	}

	public void setSubjAreaTxt(String subjAreaTxt) {
		this.subjAreaTxt = subjAreaTxt;
	}

	public int getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Timestamp getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

}