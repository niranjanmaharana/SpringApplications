package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.account.web.view.response.KpiDTO;
import com.anthem.aciisst.common.constants.ACIISSTConstants;

@Repository
public class ClmsDashboardRepositoryDAO extends AbstractDAO {
	
	public List<List<String>> getTotalPMPM(KpiDTO reqData) throws SQLException {
		ResultSet rs=null;
		List<List<String>> clmsDshbrd = new ArrayList<>();
		
		String selectQuery = queryBuilder(reqData);

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
			//ps.setString(1, userId);
				int i = 1;
				if (reqData.getCurrentPeriodStart() != null && reqData.getCurrentPeriodEnd() != null) {
					prepareParameter(ps, reqData.getCurrentPeriodStart(), reqData.getCurrentPeriodEnd(),
							reqData.getAciisstUserId(), reqData.getAccountId(), reqData.getSessionKey(), i,false);
					i=i+4;
					if(ACIISSTConstants.INCURRED.equalsIgnoreCase(reqData.getPaidOrIncured())) {
						if(ACIISSTConstants.ACCOUNT_3061_IND_Y.equalsIgnoreCase(reqData.getAccount_3061_ind())) {
							ps.setString(i, reqData.getLastCompleteMonthDate());
							i++;
						}else{
							ps.setString(i, reqData.getCurrentPeriodStart());
							i++;
							ps.setString(i, reqData.getCurrRptgEndDate());
							i++;
						}
						ps.setString(i, reqData.getCurrentPeriodStart());
						i++;
						ps.setString(i, reqData.getCurrentPeriodEnd());
						i++;
						
					}else {
						ps.setString(i, reqData.getCurrentPeriodStart());
						i++;
						ps.setString(i, reqData.getCurrentPeriodEnd());
						i++;
					}
					
				}		
				
				if (reqData.getPriorPeriod1End() != null && reqData.getPriorPeriod1Start() != null) {
					prepareParameter(ps, reqData.getPriorPeriod1Start(), reqData.getPriorPeriod1End(),
							reqData.getAciisstUserId(), reqData.getAccountId(), reqData.getSessionKey(), i,false);
					i=i+4;
					if(ACIISSTConstants.INCURRED.equalsIgnoreCase(reqData.getPaidOrIncured())) {
						if(ACIISSTConstants.ACCOUNT_3061_IND_Y.equalsIgnoreCase(reqData.getAccount_3061_ind())) {
							ps.setString(i, reqData.getLastCompleteMonthDate());
							i++;
						}else{
							ps.setString(i, reqData.getPriorPeriod1Start());
							i++;
							ps.setString(i, reqData.getPrior1RptgEndDate());
							i++;
						}
						ps.setString(i, reqData.getPriorPeriod1Start());
						i++;
						ps.setString(i, reqData.getPriorPeriod1End());
						i++;
						
					}else {
						ps.setString(i, reqData.getPriorPeriod1Start());
						i++;
						ps.setString(i, reqData.getPriorPeriod1End());
						i++;
					}			
				}
				
				if (reqData.getPriorPeriod2End() != null && reqData.getPriorPeriod2Start() != null) {
					prepareParameter(ps, reqData.getPriorPeriod2Start(), reqData.getPriorPeriod2End(),
							reqData.getAciisstUserId(), reqData.getAccountId(), reqData.getSessionKey(), i,false);
					i=i+4;
					if(ACIISSTConstants.INCURRED.equalsIgnoreCase(reqData.getPaidOrIncured())) {
						if(ACIISSTConstants.ACCOUNT_3061_IND_Y.equalsIgnoreCase(reqData.getAccount_3061_ind())) {
							ps.setString(i, reqData.getLastCompleteMonthDate());
							i++;
						}else{
							ps.setString(i, reqData.getPriorPeriod2Start());
							i++;
							ps.setString(i, reqData.getPrior2RptgEndDate());
							i++;
						}
						ps.setString(i, reqData.getPriorPeriod2Start());
						i++;
						ps.setString(i, reqData.getPriorPeriod2End());
						i++;
						
					}else {
						ps.setString(i, reqData.getPriorPeriod2Start());
						i++;
						ps.setString(i, reqData.getPriorPeriod2End());
						i++;
					}				
				}
				
				if (reqData.getCurrentPeriodStart() != null && reqData.getCurrentPeriodEnd() != null) {
					prepareParameter(ps, reqData.getCurrentPeriodStart(), reqData.getCurrentPeriodEnd(),
							reqData.getAciisstUserId(), reqData.getAccountId(), reqData.getSessionKey(), i,true);
					i = i + 6;
				}
				if (reqData.getPriorPeriod1End() != null && reqData.getPriorPeriod1Start() != null) {
					prepareParameter(ps, reqData.getPriorPeriod1Start(), reqData.getPriorPeriod1End(),
							reqData.getAciisstUserId(), reqData.getAccountId(), reqData.getSessionKey(), i,true);
					i = i + 6;
				}
				if (reqData.getPriorPeriod2End() != null && reqData.getPriorPeriod2Start() != null) {
					prepareParameter(ps, reqData.getPriorPeriod2Start(), reqData.getPriorPeriod2End(),
							reqData.getAciisstUserId(), reqData.getAccountId(), reqData.getSessionKey(), i,true);					
				}
				
    			rs = ps.executeQuery();   	    	 	    		
    			clmsDshbrd = prepareResult(rs,clmsDshbrd);    			
			}	
		} finally{
			try {rs.close();} catch (SQLException e) {}
		}
		
		return clmsDshbrd;
	}
		
	
	
	public PreparedStatement prepareParameter(PreparedStatement ps, String startDate, String endDate, int userId, String accountId,
			String sessionId, int i,boolean flag) throws SQLException {
		if (startDate != null && endDate != null) {
			ps.setString(i, accountId);
			i++;
			ps.setString(i, accountId);
			i++;
			if(flag) {
				ps.setString(i, startDate);
				i++;
				ps.setString(i, endDate);
				i++;
			}
			ps.setString(i, sessionId);
			i++;
			ps.setInt(i, userId);
			
		}
		
		return ps;
	}
	
	
	public String queryBuilder(KpiDTO reqData) {
		StringBuilder stringBuilder = new StringBuilder();
	
		stringBuilder.append(" SELECT PERIOD, SUM(COST) AS COST,   \n" + 
				"  SUM(MBR_MONTHS) AS MBR_MONTHS,   \n" + 
				"  CAST (CASE WHEN SUM(MBR_MONTHS) = 0 THEN 0 ELSE CAST (SUM(COST) AS decimal (22,6)) / CAST (SUM(MBR_MONTHS) AS decimal (22,6)) END AS decimal (22,6)) AS PMPM   \n" + 
				"	 FROM ( \n");
		if (reqData.getCurrentPeriodStart() != null && reqData.getCurrentPeriodEnd() != null) {
			stringBuilder.append( " SELECT 'CP' AS PERIOD, SUM(TOTL_COST_AMT) AS COST, CAST (0 AS decimal (22,6)) AS MBR_MONTHS  \n" + 
					"		 FROM  ACIISST_CLMS_DSHBRD  AS CLM  \n" + 
					"		 INNER  JOIN  ACIISST_USER_SGMNTN USR   \n" + 
					"				ON CLM.ACCT_ID = USR.ACCT_ID AND   CLM.ACIISST_SGMNTN_DIM_KEY = USR.ACIISST_SGMNTN_DIM_KEY  \n" + 
					"		 WHERE CLM.ACCT_ID = ?  AND CLM.LAST_3_DIGT_ACCT_ID =  CAST(SUBSTR(?,6,3) AS INTEGER)  \n" + //--1? acctid ,2?acctid 
					"		 AND USR.SESN_ID = ? AND  USR.ACIISST_USER_ID = ?  \n");	//3?sessId 4?userId	
			//Incurred
			if(ACIISSTConstants.INCURRED.equalsIgnoreCase(reqData.getPaidOrIncured())) {
				if(ACIISSTConstants.ACCOUNT_3061_IND_Y.equalsIgnoreCase(reqData.getAccount_3061_ind())) {
					stringBuilder.append(" AND  CLM.RPTG_PAID_YEAR_MNTH_NBR <= ?  \n" );
				}else{
					stringBuilder.append( "AND CLM.RPTG_PAID_YEAR_MNTH_NBR >= ?  AND  CLM.RPTG_PAID_YEAR_MNTH_NBR <= ?  \n" );
				}
				stringBuilder.append(" AND CLM.CLM_SRVC_YEAR_MNTH_NBR >= ? AND  CLM.CLM_SRVC_YEAR_MNTH_NBR <= ?  \n  " ); 
				
			}else {//Paid
				stringBuilder.append("AND  CLM.RPTG_PAID_YEAR_MNTH_NBR >= ?  AND CLM.RPTG_PAID_YEAR_MNTH_NBR <= ? ");
			}
		}
		//Prior1 Period
		if (reqData.getPriorPeriod1End() != null && reqData.getPriorPeriod1Start() != null) {
			stringBuilder = stringBuilder.length() > 0 ? stringBuilder.append(" UNION  ") : stringBuilder.append("");
			stringBuilder.append( " SELECT 'P1' AS PERIOD, SUM(TOTL_COST_AMT) AS COST, CAST (0 AS decimal (22,6)) AS MBR_MONTHS  \n" + 
					"		 FROM  ACIISST_CLMS_DSHBRD  AS CLM  \n" + 
					"		 INNER JOIN  ACIISST_USER_SGMNTN USR   \n" + 
					"				ON CLM.ACCT_ID = USR.ACCT_ID AND  CLM.ACIISST_SGMNTN_DIM_KEY = USR.ACIISST_SGMNTN_DIM_KEY  \n" + 
					"		 WHERE CLM.ACCT_ID = ?  AND CLM.LAST_3_DIGT_ACCT_ID = CAST(SUBSTR(?,6,3) AS INTEGER)  \n" + //--1? acctid ,2?acctid 
					"		 AND USR.SESN_ID = ? AND USR.ACIISST_USER_ID = ?  \n");	//3?sessId 4?userId	
			//Incurred
			if(ACIISSTConstants.INCURRED.equalsIgnoreCase(reqData.getPaidOrIncured())) {
				if(ACIISSTConstants.ACCOUNT_3061_IND_Y.equalsIgnoreCase(reqData.getAccount_3061_ind())) {
					stringBuilder.append(" AND CLM.RPTG_PAID_YEAR_MNTH_NBR <= ?  \n" );
				}else{
					stringBuilder.append( "AND CLM.RPTG_PAID_YEAR_MNTH_NBR >= ?  AND  CLM.RPTG_PAID_YEAR_MNTH_NBR <= ?  \n" );
				}
				stringBuilder.append(" AND CLM.CLM_SRVC_YEAR_MNTH_NBR >= ? AND  CLM.CLM_SRVC_YEAR_MNTH_NBR <= ?  \n  " ); 
				
			}else {//Paid
				stringBuilder.append("AND CLM.RPTG_PAID_YEAR_MNTH_NBR >= ?  AND CLM.RPTG_PAID_YEAR_MNTH_NBR <= ? ");
			}
		}
		//Prior2 Period
		if (reqData.getPriorPeriod2End() != null && reqData.getPriorPeriod2Start() != null) {
			stringBuilder = stringBuilder.length() > 0 ? stringBuilder.append(" UNION  ") : stringBuilder.append("");
			stringBuilder.append( " SELECT 'P2' AS PERIOD, SUM(TOTL_COST_AMT) AS COST, CAST (0 AS decimal (22,6)) AS MBR_MONTHS  \n" + 
					"		 FROM  ACIISST_CLMS_DSHBRD  AS CLM  \n" + 
					"		 INNER JOIN  ACIISST_USER_SGMNTN USR   \n" + 
					"				ON CLM.ACCT_ID = USR.ACCT_ID AND  CLM.ACIISST_SGMNTN_DIM_KEY = USR.ACIISST_SGMNTN_DIM_KEY  \n" + 
					"		 WHERE CLM.ACCT_ID = ?  AND CLM.LAST_3_DIGT_ACCT_ID = CAST(SUBSTR(?,6,3) AS INTEGER)  \n" + //--1? acctid ,2?acctid 
					"		 AND USR.SESN_ID = ? AND USR.ACIISST_USER_ID = ?  \n");	//3?sessId 4?userId	
			//Incurred
			if(ACIISSTConstants.INCURRED.equalsIgnoreCase(reqData.getPaidOrIncured())) {
				if(ACIISSTConstants.ACCOUNT_3061_IND_Y.equalsIgnoreCase(reqData.getAccount_3061_ind())) {
					stringBuilder.append(" AND CLM.RPTG_PAID_YEAR_MNTH_NBR <= ?  \n" );
				}else{
					stringBuilder.append( "AND CLM.RPTG_PAID_YEAR_MNTH_NBR >= ?  AND  CLM.RPTG_PAID_YEAR_MNTH_NBR <= ?  \n" );
				}
				stringBuilder.append(" AND CLM.CLM_SRVC_YEAR_MNTH_NBR >= ? AND  CLM.CLM_SRVC_YEAR_MNTH_NBR <= ?  \n  " ); 
				
				
			}else {//Paid
				stringBuilder.append("AND CLM.RPTG_PAID_YEAR_MNTH_NBR >= ?  AND CLM.RPTG_PAID_YEAR_MNTH_NBR <= ? ");
			}
		}
		
		if (reqData.getCurrentPeriodStart() != null && reqData.getCurrentPeriodEnd() != null) {	
			stringBuilder = stringBuilder.length() > 0 ? stringBuilder.append(" UNION ") : stringBuilder.append("");
			stringBuilder.append(  "  SELECT 'CP' AS PERIOD, CAST (0 AS decimal (22,6)) AS COST, SUM(MEMBER_MONTHS_TOTAL) AS MBR_MONTHS  \n" + 
					"		 FROM  ( \n" + 
					"				 SELECT  \n " + 
					"				 (CASE WHEN MBR_MDCL_RX_CVRG_Id = 'Medical' THEN \n" + 
					"												(CASE WHEN  MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 2 THEN 1 \n" + 
					"													  WHEN  (MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 1 AND PHRMCY_CVRG_CNT = 1)  THEN 0 \n" + 
					"													  WHEN  (MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 1 AND MDCL_CVRG_CNT = 1) THEN 1  \n" + 
					"													  ELSE 0 END ) \n" + 
					"											  WHEN MBR_MDCL_RX_CVRG_Id ='RX'  THEN \n" + 
					"												(CASE WHEN MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 2  THEN 0 \n" + 
					"													  WHEN (MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 1 AND  PHRMCY_CVRG_CNT = 1) THEN 1 \n" + 
					"													  WHEN (MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 1 AND  MDCL_CVRG_CNT = 1) THEN 0  \n" + 
					"													  ELSE 0  END) \n" + 
					"											  ELSE 0 END ) AS  MEMBER_MONTHS_TOTAL \n" + 
					"				 FROM  ACIISST_MBRSHP_DSHBRD  AS DSH  \n" + 
					"				 INNER JOIN  ACIISST_USER_SGMNTN  USR  \n" + 
					"						ON DSH.ACCT_ID =  USR.ACCT_ID AND DSH.ACIISST_SGMNTN_DIM_KEY = USR.ACIISST_SGMNTN_DIM_KEY \n" + 
					"				 WHERE DSH.ACCT_ID = ?  AND DSH.LAST_3_DIGT_ACCT_ID = CAST(SUBSTR(?,6,3) AS INTEGER)  \n" + 
					"				 AND  DSH.ELGBLTY_CY_MNTH_END_NBR >= ? AND DSH.ELGBLTY_CY_MNTH_END_NBR <= ?      \n" + //--UI Dates
					"				 AND ( DSH.MDCL_CVRG_CNT > 0 OR DSH.PHRMCY_CVRG_CNT > 0 )  \n" + 
					"				 AND USR.SESN_ID = ? AND  USR.ACIISST_USER_ID = ?   \n" + 
					"				) AS A  \n");
		}
				
		if (reqData.getPriorPeriod1End() != null && reqData.getPriorPeriod1Start() != null) {
			stringBuilder = stringBuilder.length() > 0 ? stringBuilder.append(" UNION ALL ") : stringBuilder.append("");		
			stringBuilder.append( " SELECT 'P1' AS PERIOD, CAST (0 AS decimal (22,6)) AS COST, SUM(MEMBER_MONTHS_TOTAL) AS MBR_MONTHS  \n" + 
					"		 FROM ( \n" + 
					"				 SELECT  \n" + 
					"				  (CASE WHEN MBR_MDCL_RX_CVRG_Id ='Medical' THEN \n" + 
					"												(CASE WHEN MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 2 THEN 1 \n" + 
					"													  WHEN (MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 1 AND PHRMCY_CVRG_CNT = 1) THEN 0 \n" + 
					"													  WHEN (MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 1 AND MDCL_CVRG_CNT = 1) THEN 1  \n" + 
					"													  ELSE 0 END ) \n" + 
					"											  WHEN MBR_MDCL_RX_CVRG_Id ='RX' THEN \n" + 
					"												(CASE WHEN MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 2 THEN 0 \n" + 
					"													  WHEN (MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 1 AND PHRMCY_CVRG_CNT = 1) THEN 1 \n" + 
					"													  WHEN (MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 1 AND MDCL_CVRG_CNT = 1) THEN 0  \n" + 
					"													  ELSE 0 END  ) \n" + 
					"											  ELSE 0 END ) AS MEMBER_MONTHS_TOTAL \n" + 
					"				 FROM  ACIISST_MBRSHP_DSHBRD AS DSH  \n" + 
					"				 INNER JOIN  ACIISST_USER_SGMNTN USR  \n" + 
					"						ON DSH.ACCT_ID = USR.ACCT_ID AND DSH.ACIISST_SGMNTN_DIM_KEY = USR.ACIISST_SGMNTN_DIM_KEY \n" + 
					"				 WHERE DSH.ACCT_ID = ? AND DSH.LAST_3_DIGT_ACCT_ID = CAST(SUBSTR(?,6,3) AS INTEGER)  \n" + 
					"				 AND DSH.ELGBLTY_CY_MNTH_END_NBR >= ? AND DSH.ELGBLTY_CY_MNTH_END_NBR <= ?    \n" + //--UI Dates
					"				 AND ( DSH.MDCL_CVRG_CNT > 0 OR DSH.PHRMCY_CVRG_CNT > 0 )  \n" + 
					"				 AND USR.SESN_ID = ? AND USR.ACIISST_USER_ID = ?  \n" + 
					"			) AS A  \n");
		}
				
		if (reqData.getPriorPeriod2End() != null && reqData.getPriorPeriod2Start() != null) {
			stringBuilder = stringBuilder.length() > 0 ? stringBuilder.append(" UNION ALL ") : stringBuilder.append("");		
			stringBuilder.append( "  SELECT 'P2' AS PERIOD, CAST (0 AS decimal (22,6)) AS COST, SUM(MEMBER_MONTHS_TOTAL) AS MBR_MONTHS  \n" + 
					"		 FROM ( \n" + 
					"				 SELECT  \n" + 
					"				   (CASE WHEN MBR_MDCL_RX_CVRG_Id ='Medical' THEN \n" + 
					"												(CASE WHEN MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 2 THEN 1 \n" + 
					"													  WHEN (MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 1 AND PHRMCY_CVRG_CNT = 1) THEN 0 \n" + 
					"													  WHEN (MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 1 AND MDCL_CVRG_CNT = 1) THEN 1  \n" + 
					"													  ELSE 0 END) \n" + 
					"											  WHEN MBR_MDCL_RX_CVRG_Id ='RX' THEN \n" + 
					"												(CASE WHEN MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 2 THEN 0 \n" + 
					"													  WHEN (MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 1 AND PHRMCY_CVRG_CNT = 1) THEN 1 \n" + 
					"													  WHEN (MDCL_CVRG_CNT + PHRMCY_CVRG_CNT = 1 AND MDCL_CVRG_CNT = 1) THEN 0  \n" + 
					"													  ELSE 0 END) \n" + 
					"											  ELSE 0 END ) AS MEMBER_MONTHS_TOTAL \n" + 
					"				 FROM  ACIISST_MBRSHP_DSHBRD AS DSH  \n" + 
					"				 INNER JOIN  ACIISST_USER_SGMNTN USR  \n" + 
					"						ON DSH.ACCT_ID = USR.ACCT_ID AND DSH.ACIISST_SGMNTN_DIM_KEY = USR.ACIISST_SGMNTN_DIM_KEY \n" + 
					"				 WHERE DSH.ACCT_ID = ? AND DSH.LAST_3_DIGT_ACCT_ID = CAST(SUBSTR(?,6,3) AS INTEGER)  \n" + 
					"				 AND DSH.ELGBLTY_CY_MNTH_END_NBR >= ? AND DSH.ELGBLTY_CY_MNTH_END_NBR <= ?   \n" + //--UI Dates
					"				 AND ( DSH.MDCL_CVRG_CNT > 0 OR DSH.PHRMCY_CVRG_CNT > 0 ) \n" + 
					"				 AND USR.SESN_ID = ? AND USR.ACIISST_USER_ID = ?  \n" + 
					"			) AS A \n");	
		}
				stringBuilder.append(") AS A \n"
						+ " GROUP BY PERIOD \n"
						+ " with UR ");
				
		return stringBuilder.toString();
	}
	
	
	public List<List<String>> prepareResult(ResultSet rs, List<List<String>> clmsDshbrd) throws SQLException {
		if(rs!=null) {			
			while(rs.next()) {
				//Map<Integer, String> innerRow = new HashMap<Integer, String>();
				List<String> innerRow = new ArrayList<>();
				innerRow.add(rs.getString(1));
				innerRow.add(rs.getString(2));
				innerRow.add(rs.getString(3));
				innerRow.add(rs.getString(4));	
				
				clmsDshbrd.add(innerRow);					
			}
		}		
		return clmsDshbrd;		
	}
	
}
