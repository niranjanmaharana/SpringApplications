package com.anthem.aciisst.persistence.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AbstractDAO {
	@Autowired
	DataSource dataSource;
}
