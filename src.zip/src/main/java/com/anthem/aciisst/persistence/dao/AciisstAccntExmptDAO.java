package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.persistence.dto.AciisstAccntExmptDTO;

@Repository
public class AciisstAccntExmptDAO extends AbstractDAO {
	
	public AciisstAccntExmptDTO getAcctExmpt(String acctId) throws SQLException {
		AciisstAccntExmptDTO accntExmpt=null;
		String selectQuery = "select * from ACIISST_ACCNT_EXMPT where ACCT_ID=? with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement ps = connObj.prepareStatement(selectQuery);) {
				ps.setString(1, acctId);
				try (ResultSet rs = ps.executeQuery();) {
					accntExmpt=prepareAccntExmptResult(rs);
				}
			}
		}
		
		return accntExmpt;
		
	}
	
	public AciisstAccntExmptDTO prepareAccntExmptResult(ResultSet rs) throws SQLException {
		AciisstAccntExmptDTO exmpt=null;
		if(rs!=null) {
				while(rs.next()) {
					exmpt = new AciisstAccntExmptDTO();
					exmpt.setAcctId(rs.getString("ACCT_ID"));
					exmpt.setRptgIncrdIndCd(rs.getString("RPTG_INCRD_IND_CD"));
				}
		}
		return exmpt;
		
	}
	
	
}
