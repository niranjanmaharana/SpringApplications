package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.anthem.aciisst.account.web.view.response.AccountStructureRequest;
import com.anthem.aciisst.account.web.view.response.UserSegmentRequest;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.StringUtil;
import com.anthem.aciisst.persistence.dto.AccountDTO;
import com.anthem.aciisst.persistence.dto.User;

@Repository
public class AccountDAO extends AbstractDAO{

	@Value("${spring.jpa.properties.hibernate.jdbc.batch_size}")
	private int batchSize;

	public AccountDTO findAccount(String accountId) throws SQLException {
		List<AccountDTO> accountList = new ArrayList<>();

		String selectQuery = "select a.* from ACIISST_ACCT_PRFL a WHERE a.ACCT_ID=?  with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				pstmt.setString(1, accountId);
				try (ResultSet rs = pstmt.executeQuery();) {
					prepareAccountResult(rs, accountList);
				}
			}
		}

		if (!CollectionUtils.isEmpty(accountList)) {
			return accountList.get(0);
		}
		return null;
	}

	/**
	 * @param userId
	 * @return
	 * @throws SQLException 
	 */
	public List<AccountDTO> getRecentlyAccessedAccountForInternalUser(int userId) throws SQLException {
		List<AccountDTO> accountList = new ArrayList<>();

		String selectQuery = "select a.* from ACIISST_ACCT_PRFL a  join "
				+ "(SELECT SLCTN.ACCT_ID,SLCTN.SLCTN_DTM FROM ACIISST_USER_ACCT_SLCTN SLCTN "
				+ "JOIN ACIISST_ACCT_PRFL ACCT   ON SLCTN.ACCT_ID = ACCT.ACCT_ID AND ACCT.SCRTY_LVL_CD = 'N'   "
				+ "AND SLCTN.ACIISST_USER_ID =?   "
//				+ "AND CURRENT_DATE >= ACCT.ACCT_EFCTV_DT AND ACCT.ACCT_TRMNTN_DT > CURRENT_DATE  "
				+ " UNION   SELECT SLCTN.ACCT_ID,SLCTN.SLCTN_DTM FROM ACIISST_USER_ACCT_SLCTN SLCTN   "
				+ "JOIN ACIISST_ACCT_PRFL ACCT   ON SLCTN.ACCT_ID = ACCT.ACCT_ID   "
				+ "JOIN ACIISST_USER_ACCT_ACS_LIST L   ON SLCTN.ACCT_ID = L.ACCT_ID   AND SLCTN.ACIISST_USER_ID = L.ACIISST_USER_ID  "
				+ " AND ACCT.SCRTY_LVL_CD = 'Y'   AND SLCTN.ACIISST_USER_ID =?   "
				+ "AND CURRENT_DATE >= L.USER_ACCT_ACS_LIST_EFCTV_DT AND L.USER_ACCT_ACS_LIST_TRMNTN_DT > CURRENT_DATE  "
//				+ " AND CURRENT_DATE >= ACCT.ACCT_EFCTV_DT AND ACCT.ACCT_TRMNTN_DT > CURRENT_DATE  "
				+ " ORDER BY SLCTN_DTM DESC  ) t on t.acct_id = a.acct_id  with UR";
				
			try (Connection connObj = dataSource.getConnection();) {
				try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
					pstmt.setInt(1, userId);
					pstmt.setInt(2, userId);
					try (ResultSet rs = pstmt.executeQuery();) {
						prepareAccountResult(rs, accountList);
					}
				}
			}

			return accountList;
	}

	/**
	 * @param userId
	 * @return
	 * @throws SQLException 
	 */
	public List<AccountDTO> getRecentlyAccessedAccountForExternalUser(int userId) throws SQLException {
		List<AccountDTO> accountList = new ArrayList<>();

		String selectQuery = "select account1_.* from ACIISST_USER_ACCT_SLCTN useracctsl0_ "
				+ "inner join ACIISST_ACCT_PRFL account1_ on useracctsl0_.ACCT_ID=account1_.ACCT_ID "
				+ "inner join ACIISST_USER_ACCT_ACS_LIST aciisstuse2_ on account1_.ACCT_ID=aciisstuse2_.ACCT_ID and ( current_date >= aciisstuse2_.USER_ACCT_ACS_LIST_EFCTV_DT and coalesce( aciisstuse2_.USER_ACCT_ACS_LIST_TRMNTN_DT,'8888-12-31')> CURRENT_DATE ) "
				+ "where useracctsl0_.ACIISST_USER_ID=? and aciisstuse2_.ACIISST_USER_ID=? "
				+ "and (account1_.ACCT_SIZE_CLSFCTN_CD not in  ('SMALL' , 'KEY')) "
//				+ "and current_date>=account1_.ACCT_EFCTV_DT and account1_.ACCT_TRMNTN_DT>current_date "
				+ "order by useracctsl0_.SLCTN_DTM desc with UR";

			try (Connection connObj = dataSource.getConnection();) {
				try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
					pstmt.setInt(1, userId);
					pstmt.setInt(2, userId);
					try (ResultSet rs = pstmt.executeQuery();) {
						prepareAccountResult(rs, accountList);
					}
				}
			}

		return accountList;
	}

	/**
	 * @param userId
	 * @return
	 * @throws SQLException 
	 */
	public List<AccountDTO> findUserAccounts(String userId) throws SQLException {
		List<AccountDTO> accountList = new ArrayList<>();
		String selectQuery = "select account0_.* from ACIISST_ACCT_PRFL account0_ "
				+ "inner join ACIISST_USER_ACCT_ACS_LIST aciisstuse1_ on account0_.ACCT_ID=aciisstuse1_.ACCT_ID"
				+ " and ( current_date >= aciisstuse1_.USER_ACCT_ACS_LIST_EFCTV_DT and coalesce( aciisstuse1_.USER_ACCT_ACS_LIST_TRMNTN_DT,'8888-12-31')> CURRENT_DATE ) "
				+ "inner join ACIISST_USER user2_ on aciisstuse1_.ACIISST_USER_ID=user2_.ACIISST_USER_ID "
				+ "where user2_.LOGN_USER_ID=? " + "and (account0_.ACCT_SIZE_CLSFCTN_CD not in  ('SMALL' , 'KEY')) "
				+ "order by account0_.ACCT_NM asc with UR";

			try (Connection connObj = dataSource.getConnection();) {
				try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
					pstmt.setString(1, userId);
					try (ResultSet rs = pstmt.executeQuery();) {
						prepareAccountResult(rs, accountList);
					}
				}
			}

		return accountList;
	}

	public List<AccountDTO> getInternalUserAccountsWithSearch(String lognUserId, String searchStr) throws SQLException {
		List<AccountDTO> accountList = new ArrayList<>();
		String selectQuery = "select account0_.* from ACIISST_ACCT_PRFL account0_ "
				+ "where account0_.SCRTY_LVL_CD='N' and (lower(account0_.ACCT_ID) like '%'||?||'%' or lower(account0_.ACCT_NM) like '%'||?||'%') "
				+ "and (account0_.ACCT_SIZE_CLSFCTN_CD not in  ('SMALL' , 'KEY'))"
//				+ " and CURRENT_DATE>=account0_.ACCT_EFCTV_DT and account0_.ACCT_TRMNTN_DT>CURRENT_DATE "
				+ "or account0_.ACCT_ID in (select account1_.ACCT_ID from ACIISST_ACCT_PRFL account1_ "
				+ "inner join ACIISST_USER_ACCT_ACS_LIST aciisstuse2_ on account1_.ACCT_ID=aciisstuse2_.ACCT_ID "
				+ "and ( current_date >= aciisstuse2_.USER_ACCT_ACS_LIST_EFCTV_DT and coalesce( aciisstuse2_.USER_ACCT_ACS_LIST_TRMNTN_DT,'8888-12-31')> CURRENT_DATE )"
				+ " inner join ACIISST_USER user3_ on aciisstuse2_.ACIISST_USER_ID=user3_.ACIISST_USER_ID "
				+ "where user3_.LOGN_USER_ID=? and current_date>=aciisstuse2_.USER_ACCT_ACS_LIST_EFCTV_DT "
				+ "and aciisstuse2_.USER_ACCT_ACS_LIST_TRMNTN_DT>CURRENT_DATE and account1_.SCRTY_LVL_CD='Y' "
				+ "and (account1_.ACCT_SIZE_CLSFCTN_CD not in  ('SMALL' , 'KEY')) "
//				+ "and CURRENT_DATE>=account1_.ACCT_EFCTV_DT and account1_.ACCT_TRMNTN_DT>CURRENT_DATE"
				+ " and (lower(account1_.ACCT_ID) like '%'||?||'%' or lower(account1_.ACCT_NM) like '%'||?||'%'))"
				+ " order by account0_.ACCT_NM asc with UR";

			try (Connection connObj = dataSource.getConnection();) {
				try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
					pstmt.setString(1, searchStr);
					pstmt.setString(2, searchStr);
					pstmt.setString(3, lognUserId);
					pstmt.setString(4, searchStr);
					pstmt.setString(5, searchStr);
					try (ResultSet rs = pstmt.executeQuery();) {
						prepareAccountResult(rs, accountList);
					}
				}
			}

		return accountList;

	}

	/**
	 * @param rs
	 * @param accountList
	 * @throws SQLException 
	 */
	public void prepareAccountResult(ResultSet rs, List<AccountDTO> accountList) throws SQLException {
		if (rs != null) {
				while (rs.next()) {
					AccountDTO acct = new AccountDTO();
					acct.setAccountId(rs.getString("ACCT_ID"));
					acct.setAccountName(rs.getString("ACCT_NM"));
					acct.setAcctEfctvDt(rs.getDate("ACCT_EFCTV_DT"));
					acct.setAcctPlanMnthNbr(rs.getInt("ACCT_PLAN_MNTH_NBR"));
					acct.setAcctSizeClsfctnCd(rs.getString("ACCT_SIZE_CLSFCTN_CD"));
					acct.setAcctTrmntnDt(rs.getDate("ACCT_TRMNTN_DT"));
					// acct.setAciisstAccntExmpt(rs.getInt(""));
					acct.setCreatdByUserId(rs.getInt("CREATD_BY_USER_ID"));
					acct.setCreatdDtm(rs.getTimestamp("CREATD_DTM"));
					acct.setDfltHccThrshldAmt(rs.getString("DFLT_HCC_THRSHLD_AMT"));
					acct.setDfltPaidAmtTypeDesc(rs.getString("DFLT_PAID_AMT_TYPE_DESC"));
					acct.setDfltTmPrdCd(rs.getString("DFLT_TM_PRD_TYPE_CD"));
					acct.setDsplyDept(rs.getString("DSPLY_DEPT"));
					acct.setDsplyGrpRptg1Cd(rs.getString("DSPLY_GRP_RPTG_1_CD"));
					acct.setDsplyGrpRptg2Cd(rs.getString("DSPLY_GRP_RPTG_2_CD"));
					acct.setDsplyGrpRptg3Cd(rs.getString("DSPLY_GRP_RPTG_3_CD"));
					acct.setDsplyRlup1Cd(rs.getString("DSPLY_RLUP_1_CD"));
					acct.setDsplyRlup2Cd(rs.getString("DSPLY_RLUP_2_CD"));
					acct.setDsplyRlup3Cd(rs.getString("DSPLY_RLUP_3_CD"));
					acct.setDsplyRlup4Cd(rs.getString("DSPLY_RLUP_4_CD"));
					acct.setDsplyStts(rs.getString("DSPLY_STTS"));
					acct.setGrpRptg1LblCd(rs.getString("GRP_RPTG_1_LBL_CD"));
					acct.setGrpRptg2LblCd(rs.getString("GRP_RPTG_2_LBL_CD"));
					acct.setGrpRptg3LblCd(rs.getString("GRP_RPTG_3_LBL_CD"));
					acct.setMembershipTierValCnt(rs.getString("DFLT_MBRSHP_TIER_VAL_CNT"));// SUBGRP_RPTG_1_LBL_CD
					acct.setRptgBrndLogoCd(rs.getString("RPTG_BRND_LOGO_CD"));
					acct.setRptgDsplyDeptInd(rs.getString("RPTG_DSPLY_DEPT_IND"));
					acct.setRptgDsplyGrpRptg1Cd(rs.getString("RPTG_DSPLY_GRP_RPTG_1_CD"));
					acct.setRptgDsplyGrpRptg2Cd(rs.getString("RPTG_DSPLY_GRP_RPTG_2_CD"));
					acct.setRptgDsplyGrpRptg3Cd(rs.getString("RPTG_DSPLY_GRP_RPTG_3_CD"));
					acct.setRptgDsplyRlup1Cd(rs.getString("RPTG_DSPLY_RLUP_1_CD"));
					acct.setRptgDsplyRlup2Cd(rs.getString("RPTG_DSPLY_RLUP_2_CD"));
					acct.setRptgDsplyRlup3Cd(rs.getString("RPTG_DSPLY_RLUP_3_CD"));
					acct.setRptgDsplyRlup4Cd(rs.getString("RPTG_DSPLY_RLUP_4_CD"));
					acct.setUpdtdByUserId(rs.getInt("UPDTD_BY_USER_ID"));
					acct.setUpdtdDtm(rs.getTimestamp("UPDTD_DTM"));
					acct.setRptgDsplySttsCd(rs.getString("RPTG_DSPLY_STTS_CD"));
					acct.setSecurityLvlCode(rs.getString("SCRTY_LVL_CD"));
					accountList.add(acct);

				}

			}

	}

	public List<Object[]> getAccountStructureFilters(AccountStructureRequest request, String requiredFilter,
			boolean externalGrpSecurityInd) throws SQLException {
		List<Object[]> objList = new ArrayList<>();
		String selectQuery = queryBuilder(request, requiredFilter, externalGrpSecurityInd);

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				buildPreparedStatementForQuery(request, pstmt, externalGrpSecurityInd, requiredFilter);
				try (ResultSet rs = pstmt.executeQuery();) {
					while (rs.next()) {
						Object[] obj = new Object[2];
						obj[0] = rs.getObject(1);
						if (!ACIISSTConstants.SEGMENT_KEYS.equals(requiredFilter)) {
							obj[1] = rs.getObject(2);
						}
						objList.add(obj);
					}
				}
			}
		}

		return objList;
	}

	public String queryBuilder(AccountStructureRequest request, String requiredFilter, boolean externalGrpSecurityInd) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(buildSelectClause(requiredFilter)).append(buildFromClause(externalGrpSecurityInd))
				.append(buildWhereClause(request, requiredFilter, externalGrpSecurityInd));
		return stringBuilder.toString();

	}

	private String buildSelectClause(String requiredFilter) {
		String selectClause;
		switch (requiredFilter) {
		case ACIISSTConstants.GROUP:
			selectClause = " select distinct sgmnt.sgmntn_grp_id as code, SUBSTR(SGMNT.SGMNTN_GRP_ID,LOCATE('~',SGMNT.SGMNTN_GRP_ID) +1) as description ";
			break;
		case ACIISSTConstants.SUBGROUP:
			selectClause = " select distinct sgmnt.SGMNTN_SUBGRP_ID as code, SUBSTR(SUBSTR(SGMNT.SGMNTN_SUBGRP_ID,LOCATE('~',SGMNT.SGMNTN_SUBGRP_ID)+1),LOCATE('~',SUBSTR(SGMNT.SGMNTN_SUBGRP_ID,LOCATE('~',SGMNT.SGMNTN_SUBGRP_ID)+1))+1) as description ";
			break;
		case ACIISSTConstants.PRODUCT:
			selectClause = " select distinct sgmnt.HLTH_PROD_SRVC_TYPE_CD as code, sgmnt.HLTH_PROD_SRVC_TYPE_CD as description ";
			break;
		case ACIISSTConstants.PACKAGE:
			selectClause = "select distinct sgmnt.PLAN_ID as code, sgmnt.PLAN_ID as description ";
			break;
		case ACIISSTConstants.STATUS:
			selectClause = "select distinct sgmnt.GRP_STTS_CD as code,"
					+ " CASE WHEN sgmnt.GRP_STTS_DESC is null then sgmnt.GRP_STTS_CD"
					+ " ELSE sgmnt.GRP_STTS_CD || ' (' || sgmnt.GRP_STTS_DESC || ')' END as description ";
			break;
		case ACIISSTConstants.DEPARTMENT:
			selectClause = "select distinct sgmnt.EMPLR_DEPT_NBR as code, sgmnt.EMPLR_DEPT_NBR as description ";
			break;

		case ACIISSTConstants.SUBGROUPROLLUP1:
			selectClause = "select distinct sgrlp.SUBGRP_RLUP_1_CD as code, "
					+ " CASE WHEN sgrlp.SUBGRP_RLUP_1_DESC is null then sgrlp.SUBGRP_RLUP_1_CD "
					+ " ELSE sgrlp.SUBGRP_RLUP_1_DESC END as description ";
			break;
		case ACIISSTConstants.SUBGROUPROLLUP2:
			selectClause = "select distinct sgrlp.SUBGRP_RLUP_2_CD as code, "
					+ " CASE WHEN sgrlp.SUBGRP_RLUP_2_DESC is null then sgrlp.SUBGRP_RLUP_2_CD "
					+ " ELSE sgrlp.SUBGRP_RLUP_2_DESC END as description ";
			break;
		case ACIISSTConstants.SUBGROUPROLLUP3:
			selectClause = "select distinct sgrlp.SUBGRP_RLUP_3_CD as code, "
					+ " CASE WHEN sgrlp.SUBGRP_RLUP_3_DESC is null then sgrlp.SUBGRP_RLUP_3_CD "
					+ " ELSE sgrlp.SUBGRP_RLUP_3_DESC END as description ";
			break;
		case ACIISSTConstants.SUBGROUPROLLUP4:
			selectClause = "select distinct sgrlp.SUBGRP_RLUP_4_CD as code, "
					+ " CASE WHEN sgrlp.SUBGRP_RLUP_4_DESC is null then sgrlp.SUBGRP_RLUP_4_CD "
					+ " ELSE sgrlp.SUBGRP_RLUP_4_DESC END as description ";
			break;
		case ACIISSTConstants.EMPLOYERGROUPREPORTING1:
			// Adding outer select query in constants to avoid SonarLint error.
			selectClause = ACIISSTConstants.GRP_RPRTNG_OUTER_SELECT
					+ " select distinct RPTG_EMPLR_GRP_RPTG_1_CD as code"
					+ " , CASE WHEN RPTG_EMPLR_GRP_RPTG_1_CD = RPTG_EMPLR_GRP_RPTG_1_DESC then RPTG_EMPLR_GRP_RPTG_1_CD "
					+ " 	ELSE RPTG_EMPLR_GRP_RPTG_1_CD || ' (' || RPTG_EMPLR_GRP_RPTG_1_DESC || ')' END as description ";
			break;
		case ACIISSTConstants.EMPLOYERGROUPREPORTING2:
			selectClause = ACIISSTConstants.GRP_RPRTNG_OUTER_SELECT
					+ " select distinct RPTG_EMPLR_GRP_RPTG_2_CD as code"
					+ " , CASE WHEN RPTG_EMPLR_GRP_RPTG_2_CD = RPTG_EMPLR_GRP_RPTG_2_DESC then RPTG_EMPLR_GRP_RPTG_2_CD "
					+ " 	ELSE RPTG_EMPLR_GRP_RPTG_2_CD || ' (' || RPTG_EMPLR_GRP_RPTG_2_DESC || ')' END as description ";
			break;
		case ACIISSTConstants.EMPLOYERGROUPREPORTING3:
			selectClause = ACIISSTConstants.GRP_RPRTNG_OUTER_SELECT
					+ " select distinct RPTG_EMPLR_GRP_RPTG_3_CD as code"
					+ " , CASE WHEN RPTG_EMPLR_GRP_RPTG_3_CD = RPTG_EMPLR_GRP_RPTG_3_DESC then RPTG_EMPLR_GRP_RPTG_3_CD "
					+ " 	ELSE RPTG_EMPLR_GRP_RPTG_3_CD || ' (' || RPTG_EMPLR_GRP_RPTG_3_DESC || ')' END as description ";
			break;
		case ACIISSTConstants.SEGMENT_KEYS:
			selectClause = "select distinct sgmnt.aciisst_sgmntn_dim_key ";
			break;
		case ACIISSTConstants.SUBGRPRLUP_STATUS:
			selectClause = "select distinct SGRLP.SUBGRP_RLUP_STTS_CD as code,"
					+ " CASE WHEN sgrlp.SUBGRP_RLUP_STTS_DESC is null then sgrlp.SUBGRP_RLUP_STTS_CD"
					+ " ELSE sgrlp.SUBGRP_RLUP_STTS_DESC END as description ";
			break;
		default:
			selectClause = ACIISSTConstants.EMPTY_BLANK_STRING;
			break;
		}
		return selectClause;
	}

	public String buildFromClause(boolean externalGrpSecurityInd) {
		StringBuilder from = new StringBuilder();
		from.append(" FROM ACIISST_DDIM_SGMNTN sgmnt " + ACIISSTConstants.JOIN 
				+ " ACIISST_ACCT_SGMNT_BRDG brdg "
				+ "		ON sgmnt.aciisst_sgmntn_dim_key = brdg.aciisst_sgmntn_dim_key" + ACIISSTConstants.JOIN
				+ " ACIISST_ACCT_PRFL acct " + " ON acct.acct_id = brdg.acct_id "
				+ ACIISSTConstants.JOIN +" ACIISST_GRP_PRFL grp "
				+ " ON sgmnt.SGMNTN_GRP_ID = grp.GRP_ID " + "		AND sgmnt.SGMNTN_SOR_CD = grp.GRP_SOR_CD "
				+ " LEFT JOIN " + " ACIISST_SUBGRP_RLUP sgrlp "
				+ "		ON sgrlp.SGMNTN_GRP_ID = sgmnt.SGMNTN_GRP_ID "
				+ "		 AND sgrlp.SGMNTN_SUBGRP_ID = sgmnt.SGMNTN_SUBGRP_ID AND sgrlp.SGMNTN_SOR_CD = sgmnt.SGMNTN_SOR_CD ");
		if (externalGrpSecurityInd)
			from.append(ACIISSTConstants.JOIN 
					+ " ACIISST_USER_GRP_ACS_LIST GRPACS ON GRP.GRP_ID = GRPACS.GRP_ID AND GRPACS.ACCT_ID = ACCT.ACCT_ID "
					+ ACIISSTConstants.JOIN 
					+ " ACIISST_USER USR on GRPACS.ACIISST_USER_ID = USR.ACIISST_USER_ID ");
		return from.toString();
	}

	public String buildWhereClause(AccountStructureRequest request, String requiredFilter,
			boolean externalGrpSecurityInd) {
		StringBuilder where = new StringBuilder();
		where.append(" WHERE acct.acct_id = ? ");
		if (externalGrpSecurityInd) {
			where.append(" AND  USR.LOGN_USER_ID = ? ").append(
					" AND CURRENT_DATE >= GRPACS.GRP_ACS_LIST_EFCTV_DT AND GRPACS.GRP_ACS_LIST_TRMNTN_DT > current_date ");
		}
		if (!(requiredFilter.equals(ACIISSTConstants.GROUP) || StringUtils.isEmpty(request.getGroups())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getGroups()))) {
			where.append(" and sgmnt.SGMNTN_GRP_ID in ("
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getGroups()) + ") ");
		}
		if (!(requiredFilter.equals(ACIISSTConstants.SUBGROUP) || StringUtils.isEmpty(request.getSubGroups())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getSubGroups()))) {
			where.append(" and sgmnt.SGMNTN_SUBGRP_ID in ( "
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getSubGroups()) + ") ");
		}
		if (!(requiredFilter.equals(ACIISSTConstants.PRODUCT) || StringUtils.isEmpty(request.getProducts())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getProducts()))) {
			where.append(" and sgmnt.HLTH_PROD_SRVC_TYPE_CD in ( "
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getProducts()) + ") ");
		}
		if (!(requiredFilter.equals(ACIISSTConstants.STATUS)
				|| requiredFilter.equals(ACIISSTConstants.SUBGRPRLUP_STATUS) || StringUtils.isEmpty(request.getStatus())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getStatus()))) {
			where.append(" and (sgmnt.GRP_STTS_CD in ( "
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getStatus()) + ") ")
					.append(" or sgrlp.SUBGRP_RLUP_STTS_CD in ( "
							+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getStatus()) + ") ) ");

		}
		if (!(requiredFilter.equals(ACIISSTConstants.DEPARTMENT) || StringUtils.isEmpty(request.getDepartments())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getDepartments()))) {
			where.append(" and sgmnt.EMPLR_DEPT_NBR in ( "
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getDepartments()) + ") ");
		}
		if (!(requiredFilter.equals(ACIISSTConstants.PACKAGE) || StringUtils.isEmpty(request.getPackages())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getPackages()))) {
			where.append(" and sgmnt.PLAN_ID in ( "
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getPackages()) + ") ");
		}
		if (!(requiredFilter.equals(ACIISSTConstants.SUBGROUPROLLUP1)
				|| StringUtils.isEmpty(request.getSubGroupRollup1())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getSubGroupRollup1()))) {
			where.append(" and sgrlp.SUBGRP_RLUP_1_CD in ( "
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getSubGroupRollup1()) + ") ");
		}
		if (!(requiredFilter.equals(ACIISSTConstants.SUBGROUPROLLUP2)
				|| StringUtils.isEmpty(request.getSubGroupRollup2())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getSubGroupRollup2()))) {
			where.append(" and sgrlp.SUBGRP_RLUP_2_CD in ( "
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getSubGroupRollup2()) + ") ");
		}
		if (!(requiredFilter.equals(ACIISSTConstants.SUBGROUPROLLUP3)
				|| StringUtils.isEmpty(request.getSubGroupRollup3())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getSubGroupRollup3()))) {
			where.append(" and sgrlp.SUBGRP_RLUP_3_CD in ( "
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getSubGroupRollup3()) + ") ");
		}
		if (!(requiredFilter.equals(ACIISSTConstants.SUBGROUPROLLUP4)
				|| StringUtils.isEmpty(request.getSubGroupRollup4())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getSubGroupRollup4()))) {
			where.append(" and sgrlp.SUBGRP_RLUP_4_CD in ( "
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getSubGroupRollup4()) + ") ");
		}
		if (!(requiredFilter.equals(ACIISSTConstants.EMPLOYERGROUPREPORTING1)
				|| StringUtils.isEmpty(request.getEmployerGroupReporting1())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getEmployerGroupReporting1()))) {
			where.append(" and sgrlp.RPTG_EMPLR_GRP_RPTG_1_CD in ( "
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getEmployerGroupReporting1()) + ") ");
		}
		if (!(requiredFilter.equals(ACIISSTConstants.EMPLOYERGROUPREPORTING2)
				|| StringUtils.isEmpty(request.getEmployerGroupReporting2())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getEmployerGroupReporting2()))) {
			where.append(" and sgrlp.RPTG_EMPLR_GRP_RPTG_2_CD in ( "
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getEmployerGroupReporting2()) + ") ");
		}
		if (!(requiredFilter.equals(ACIISSTConstants.EMPLOYERGROUPREPORTING3)
				|| StringUtils.isEmpty(request.getEmployerGroupReporting3())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getEmployerGroupReporting3()))) {
			where.append(" and sgrlp.RPTG_EMPLR_GRP_RPTG_3_CD in ( "
					+ StringUtil.buildPlaceholdersFromCommaSeparatedList(request.getEmployerGroupReporting3()) + ") ");
		}
		if (!(requiredFilter.equalsIgnoreCase(ACIISSTConstants.SEGMENT_KEYS)
				|| requiredFilter.equalsIgnoreCase(ACIISSTConstants.EMPTY_BLANK_STRING))) {
			// Closing the outer select query which is used in case of group reporting 1/2/3
			// select clause
			if (requiredFilter.contains(ACIISSTConstants.EMPLOYERGROUPREPORTING))
				where.append(" ) ");
			where.append(" order by description, code asc ");
		}
		where.append(" with UR ");
		return where.toString();
	}

	public void buildPreparedStatementForQuery(AccountStructureRequest request, PreparedStatement query,
			boolean externalGrpSecurityInd, String requiredFilter) throws SQLException {
		int i = 0;
		query.setString(++i, request.getAccountId());
		if (externalGrpSecurityInd)
			query.setString(++i, request.getUserId());
		if (!(requiredFilter.equals(ACIISSTConstants.GROUP) || StringUtils.isEmpty(request.getGroups())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getGroups()))) {
			String[] array = request.getGroups().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
		}
		if (!(requiredFilter.equals(ACIISSTConstants.SUBGROUP) || StringUtils.isEmpty(request.getSubGroups())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getSubGroups()))) {
			String[] array = request.getSubGroups().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
		}
		if (!(requiredFilter.equals(ACIISSTConstants.PRODUCT) || StringUtils.isEmpty(request.getProducts())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getProducts()))) {
			String[] array = request.getProducts().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
		}
		if (!(requiredFilter.equals(ACIISSTConstants.STATUS)
				|| requiredFilter.equals(ACIISSTConstants.SUBGRPRLUP_STATUS) || StringUtils.isEmpty(request.getStatus())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getStatus()))) {
			String[] array = request.getStatus().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
			for (String item : array) {
				query.setString(++i, item);
			}
		}
		if (!(requiredFilter.equals(ACIISSTConstants.DEPARTMENT) || StringUtils.isEmpty(request.getDepartments())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getDepartments()))) {
			String[] array = request.getDepartments().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
		}
		if (!(requiredFilter.equals(ACIISSTConstants.PACKAGE) || StringUtils.isEmpty(request.getPackages())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getPackages()))) {
			String[] array = request.getPackages().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
		}
		if (!(requiredFilter.equals(ACIISSTConstants.SUBGROUPROLLUP1)
				|| StringUtils.isEmpty(request.getSubGroupRollup1())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getSubGroupRollup1()))) {
			String[] array = request.getSubGroupRollup1().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
		}
		if (!(requiredFilter.equals(ACIISSTConstants.SUBGROUPROLLUP2)
				|| StringUtils.isEmpty(request.getSubGroupRollup2())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getSubGroupRollup2()))) {
			String[] array = request.getSubGroupRollup2().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
		}
		if (!(requiredFilter.equals(ACIISSTConstants.SUBGROUPROLLUP3)
				|| StringUtils.isEmpty(request.getSubGroupRollup3())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getSubGroupRollup3()))) {
			String[] array = request.getSubGroupRollup3().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
		}
		if (!(requiredFilter.equals(ACIISSTConstants.SUBGROUPROLLUP4)
				|| StringUtils.isEmpty(request.getSubGroupRollup4())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getSubGroupRollup4()))) {
			String[] array = request.getSubGroupRollup4().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
		}
		if (!(requiredFilter.equals(ACIISSTConstants.EMPLOYERGROUPREPORTING1)
				|| StringUtils.isEmpty(request.getEmployerGroupReporting1())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getEmployerGroupReporting1()))) {
			String[] array = request.getEmployerGroupReporting1().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
		}
		if (!(requiredFilter.equals(ACIISSTConstants.EMPLOYERGROUPREPORTING2)
				|| StringUtils.isEmpty(request.getEmployerGroupReporting2())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getEmployerGroupReporting2()))) {
			String[] array = request.getEmployerGroupReporting2().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
		}
		if (!(requiredFilter.equals(ACIISSTConstants.EMPLOYERGROUPREPORTING3)
				|| StringUtils.isEmpty(request.getEmployerGroupReporting3())
				|| ACIISSTConstants.ALL_SELECTED.equalsIgnoreCase(request.getEmployerGroupReporting3()))) {
			String[] array = request.getEmployerGroupReporting3().split(",");
			for (String item : array) {
				query.setString(++i, item);
			}
		}
	}

	public void addUserSegment(UserSegmentRequest userSegmentRequest, User user) throws Exception {
		if (userSegmentRequest != null && userSegmentRequest.getSessionKey() != null
				&& userSegmentRequest.getUserId() != null) {

				try (Connection con = dataSource.getConnection();) {
					
					String  deleteSql = "delete FROM ACIISST_USER_SGMNTN WHERE SESN_ID = ? and ACIISST_USER_ID =? ";
					try (PreparedStatement psDelete = con.prepareStatement(deleteSql)) {
						psDelete.setString(1, userSegmentRequest.getSessionKey());
						psDelete.setInt(2, user.getUserId());
						psDelete.executeUpdate();
					}
					
					try{
						con.setAutoCommit(false);
						
						Calendar calendar = Calendar.getInstance();
						Timestamp currentTimestamp = new Timestamp(calendar.getTime().getTime());
						String insertSql = "insert into ACIISST_USER_SGMNTN (ACCT_ID, ACIISST_SGMNTN_DIM_KEY, SESN_ID, ACIISST_USER_ID, CREATD_DTM, CREATD_BY_USER_ID, UPDTD_DTM, UPDTD_BY_USER_ID) values( ?, ?, ?, ?, ?, ?, ?, ?)";
						try (PreparedStatement ps = con.prepareStatement(insertSql)) {
		
							if (null != userSegmentRequest.getSegmentKeys()
									&& !CollectionUtils.isEmpty(userSegmentRequest.getSegmentKeys())) {
								for (int i = 0; i < userSegmentRequest.getSegmentKeys().size(); i++) {
									int count = 0;
									ps.setString(++count, userSegmentRequest.getAccountId());
									ps.setInt(++count, userSegmentRequest.getSegmentKeys().get(i).getKey());
									ps.setString(++count, userSegmentRequest.getSessionKey());
									ps.setInt(++count, user.getUserId());
									ps.setTimestamp(++count, currentTimestamp);
									ps.setInt(++count, user.getUserId());
									ps.setTimestamp(++count, currentTimestamp);
									ps.setInt(++count, user.getUserId());
									ps.addBatch();
		
									if ((i > 0) && (i % batchSize == 0)) {
										ps.executeBatch();
										ps.clearBatch();
									}
								}
								ps.executeBatch();
							}
						}
						con.commit();
					} catch (SQLException e){
						con.rollback();
						throw new SQLException("JDBC transaction rollbacked successfully- " + e);
					}

			}
		}
	}
}
