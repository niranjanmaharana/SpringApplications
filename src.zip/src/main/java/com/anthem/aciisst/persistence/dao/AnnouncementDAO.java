package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.anthem.aciisst.persistence.dto.AciisstAncmntDTO;
import com.anthem.aciisst.persistence.dto.AciisstUserAncmntReadDTO;

@Repository
public class AnnouncementDAO extends AbstractDAO {

	
	public AciisstAncmntDTO getAnnouncement( int announcementId) throws SQLException{
		AciisstAncmntDTO accmt= null;
		String selectQuery = "select  ancmt.* from ACIISST_ANCMNT ancmt where ancmt.ANCMNT_ID=? with UR ";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				pstmt.setInt(1, announcementId);
				try (ResultSet rs = pstmt.executeQuery();) {
					while(rs.next()) {
						
						accmt=new AciisstAncmntDTO();
						accmt.setAncmntDesc(rs.getString("ANCMNT_DESC"));
						accmt.setAncmntId(rs.getInt("ANCMNT_ID"));
						accmt.setAncmntEfctvDt(rs.getDate("ANCMNT_EFCTV_DT"));
						accmt.setFileDcmnt(rs.getBytes("FILE_DCMNT"));
						accmt.setFileCntntTypeCd(rs.getString("FILE_CNTNT_TYPE_CD"));
						accmt.setDcmntTtlShrtNm(rs.getString("DCMNT_TTL_SHRT_NM"));
						accmt.setFileName(rs.getString("FILE_NM"));
					}
				}
			}
		}

		return accmt;
	}
	
	public List<AciisstAncmntDTO> getAllUserAnnouncement(String ctgrycd, int aciisstUserId, String alertInd) throws SQLException{
		List<AciisstAncmntDTO> ancmtList= new ArrayList<>();
		String selectQuery = "select  ancmt.* from ACIISST_ANCMNT ancmt where ancmt.ALL_ACCT_IND ='Y' and ancmt.ALRT_IND=? and "
				+ "ancmt.USER_CTGRY_CD in (?,'3') and ancmt.ANCMNT_ID not in (select ANCMNT_ID from ACIISST_USER_ANCMNT_READ where ACIISST_USER_ID=?)"
				+ " and CURRENT DATE between ancmt.ANCMNT_EFCTV_DT and coalesce(ancmt.ANCMNT_TRMNTN_DT, TO_DATE('8888-12-31','YYYY-MM-DD')) "
				+ "order by ancmt.ANCMNT_EFCTV_DT desc with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				int i=0;
				pstmt.setString(++i, alertInd);
				pstmt.setString(++i, ctgrycd);
				pstmt.setInt(++i, aciisstUserId);
				
				try (ResultSet rs = pstmt.executeQuery();) {
					prepareResult(rs,ancmtList);
				}
			}
		} 
		return ancmtList;
	}
	
	public void prepareResult(ResultSet rs,List<AciisstAncmntDTO>ancmtList) throws SQLException {
		if(rs!=null) {
			while (rs.next()) {
				AciisstAncmntDTO accmt= new AciisstAncmntDTO();
				accmt.setAncmntDesc(rs.getString("ANCMNT_DESC"));
				accmt.setAncmntId(rs.getInt("ANCMNT_ID"));
				accmt.setAncmntEfctvDt(rs.getDate("ANCMNT_EFCTV_DT"));
				accmt.setFileDcmnt(rs.getBytes("FILE_DCMNT"));
				accmt.setDcmntTtlShrtNm(rs.getString("DCMNT_TTL_SHRT_NM"));
				accmt.setFileCntntTypeCd(rs.getString("FILE_CNTNT_TYPE_CD"));
				accmt.setFileName(rs.getString("FILE_NM"));
				ancmtList.add(accmt);
			}
		}
	}
	
	public List<AciisstAncmntDTO> getAllUserAnnouncementRead(String ctgrycd,int aciisstUserId,  String alertInd) throws SQLException{
		List<AciisstAncmntDTO> ancmtList= new ArrayList<>();
		String selectQuery = "select * from ACIISST_ANCMNT aciisstanc0_ inner join ACIISST_USER_ANCMNT_READ userancmnt1_ "
				+ "on aciisstanc0_.ANCMNT_ID=userancmnt1_.ANCMNT_ID where userancmnt1_.ACIISST_USER_ID=? and "
				+ "(aciisstanc0_.USER_CTGRY_CD in (? , '3')) and aciisstanc0_.ALL_ACCT_IND='Y' and"
				+ " aciisstanc0_.ALRT_IND=?  and "
				+ "  CURRENT DATE between aciisstanc0_.ANCMNT_EFCTV_DT and coalesce(aciisstanc0_.ANCMNT_TRMNTN_DT, TO_DATE('8888-12-31','YYYY-MM-DD')) "
				+ " order by aciisstanc0_.ANCMNT_EFCTV_DT desc with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				int i=0;
				pstmt.setInt(++i, aciisstUserId);
				pstmt.setString(++i, ctgrycd);
				pstmt.setString(++i, alertInd);
				try (ResultSet rs = pstmt.executeQuery();) {
					prepareResult(rs,ancmtList);
				}
			}
		}

		return ancmtList;
	}
	
	public List<AciisstAncmntDTO> getAllUserAndAccountSpecificAnnouncement(String ctgrycd, int aciisstUserId, String accountId, String alertInd) throws SQLException{
		List<AciisstAncmntDTO> ancmtList= new ArrayList<>();
		String selectQuery = "select ancmt.* from ACIISST_ANCMNT ancmt where ancmt.ALRT_IND=? and ancmt.USER_CTGRY_CD in (?,'3')"
				+ " and (ancmt.ALL_ACCT_IND ='Y' or (ancmt.ALL_ACCT_IND ='N' and ancmt.ANCMNT_ID in (select ANCMNT_ID from ACIISST_ACCT_ANCMNT acct where acct.ACCT_ID=?))) "
				+ "and ancmt.ANCMNT_ID not in(select ANCMNT_ID from ACIISST_USER_ANCMNT_READ where ACIISST_USER_ID=? ) and CURRENT DATE "
				+ "between ancmt.ANCMNT_EFCTV_DT and coalesce(ancmt.ANCMNT_TRMNTN_DT, TO_DATE('8888-12-31','YYYY-MM-DD')) order by ancmt.ANCMNT_EFCTV_DT desc with UR";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				int i=0;
				pstmt.setString(++i, alertInd);
				pstmt.setString(++i, ctgrycd);
				pstmt.setString(++i, accountId);
				pstmt.setInt(++i, aciisstUserId);
				
				try (ResultSet rs = pstmt.executeQuery();) {
					prepareResult(rs,ancmtList);
				}
			}
		}

		return ancmtList;
	}
	
	public List<AciisstAncmntDTO> getAllUserAndAccountSpecificAnnouncementRead(String ctgrycd, int aciisstUserId, String accountId, String alertInd) throws SQLException{
		List<AciisstAncmntDTO> ancmtList= new ArrayList<>();
		String selectQuery = "select ancmt.* from ACIISST_ANCMNT ancmt join aciisst_user_ancmnt_read aread on ancmt.ancmnt_id=aread.ancmnt_id "
				+ " where ancmt.USER_CTGRY_CD in (?,'3') and ancmt.ALRT_IND=? and aread.ACIISST_USER_ID=? and"
				+ " (ancmt.ALL_ACCT_IND ='Y' or (ancmt.ALL_ACCT_IND ='N' and ancmt.ANCMNT_ID in"
				+ " (select ANCMNT_ID from ACIISST_ACCT_ANCMNT acct where acct.ACCT_ID=?))) and"
				+ " CURRENT DATE between ancmt.ANCMNT_EFCTV_DT and coalesce(ancmt.ANCMNT_TRMNTN_DT, TO_DATE('8888-12-31','YYYY-MM-DD')) order by ancmt.ANCMNT_EFCTV_DT desc with UR ";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				int i=0;
				pstmt.setString(++i, ctgrycd);
				pstmt.setString(++i, alertInd);
				pstmt.setInt(++i, aciisstUserId);
				pstmt.setString(++i, accountId);
				
				try (ResultSet rs = pstmt.executeQuery();) {
					prepareResult(rs,ancmtList);
				}
			}
		}
		return ancmtList;
	}
	
	public int saveReadAnnouncement(AciisstUserAncmntReadDTO announcement) throws SQLException {
		String insertQuery="INSERT INTO ACIISST_USER_ANCMNT_READ ( ANCMNT_ID, ACIISST_USER_ID, CREATD_BY_USER_ID, CREATD_DTM, UPDTD_BY_USER_ID, UPDTD_DTM) values(?,?,?,?,?,?) ";
		
		int result=-1;

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(insertQuery);) {
				int i=0;
				pstmt.setInt(++i, announcement.getAncmntId());
				pstmt.setInt(++i, announcement.getAciisstUserId());
				pstmt.setInt(++i, announcement.getAciisstUserId());
				pstmt.setTimestamp(++i, announcement.getCreatdDtm());
				pstmt.setInt(++i, announcement.getAciisstUserId());
				pstmt.setTimestamp(++i, announcement.getUpdtdDtm());
				result=pstmt.executeUpdate();
				
			}
		}
		return result;
	}
}
