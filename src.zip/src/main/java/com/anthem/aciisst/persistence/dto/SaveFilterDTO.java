package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;


public class SaveFilterDTO {
	private int id;
	private String name;
	private String description;
	private String typeCd;
	private String acctId;
	private String activeFlag;
	private Timestamp effectiveDtm;
	private Timestamp trmntnDtm;
	private int creatdByUserId;
	private Timestamp creatdDtm;
	private int updtdByUserId;
	private Timestamp updtdDtm;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTypeCd() {
		return typeCd;
	}
	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}
	public String getAcctId() {
		return acctId;
	}
	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}
	public String getActiveFlag() {
		return activeFlag;
	}
	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}
	public Timestamp getEffectiveDtm() {
		return effectiveDtm;
	}
	public void setEffectiveDtm(Timestamp effectiveDtm) {
		this.effectiveDtm = effectiveDtm;
	}
	public Timestamp getTrmntnDtm() {
		return trmntnDtm;
	}
	public void setTrmntnDtm(Timestamp trmntnDtm) {
		this.trmntnDtm = trmntnDtm;
	}
	public int getCreatdByUserId() {
		return creatdByUserId;
	}
	public void setCreatdByUserId(int creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}
	public Timestamp getCreatdDtm() {
		return creatdDtm;
	}
	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}
	public int getUpdtdByUserId() {
		return updtdByUserId;
	}
	public void setUpdtdByUserId(int updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}
	public Timestamp getUpdtdDtm() {
		return updtdDtm;
	}
	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}
}