package com.anthem.aciisst.persistence.dto;

import java.math.BigDecimal;

public class AciisstClmsDshbrdDTO  {
	private int aciisstSgmntnDimKey;
	private String acctId;
	private int rptgPaidYearMnthNbr;
	private long mcid;
	private BigDecimal totlCostAmt;
	
	public int getAciisstSgmntnDimKey() {
		return aciisstSgmntnDimKey;
	}

	public void setAciisstSgmntnDimKey(int aciisstSgmntnDimKey) {
		this.aciisstSgmntnDimKey = aciisstSgmntnDimKey;
	}

	public String getAcctId() {
		return acctId;
	}

	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}

	public int getRptgPaidYearMnthNbr() {
		return rptgPaidYearMnthNbr;
	}

	public void setRptgPaidYearMnthNbr(int rptgPaidYearMnthNbr) {
		this.rptgPaidYearMnthNbr = rptgPaidYearMnthNbr;
	}

	public long getMcid() {
		return mcid;
	}

	public void setMcid(long mcid) {
		this.mcid = mcid;
	}

	public BigDecimal getTotlCostAmt() {
		return totlCostAmt;
	}

	public void setTotlCostAmt(BigDecimal totlCostAmt) {
		this.totlCostAmt = totlCostAmt;
	}
	
	
	
}
