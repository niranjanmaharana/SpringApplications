package com.anthem.aciisst.persistence.dto;

public class AciisstRsrcCtgryDTO  {

	private String rscCtgryCD;
	 
	private String rscShrtNm;
		 
	private String rscCtgryDes;

	public String getRscCtgryCD() {
		return rscCtgryCD;
	}

	public void setRscCtgryCD(String rscCtgryCD) {
		this.rscCtgryCD = rscCtgryCD;
	}

	public String getRscShrtNm() {
		return rscShrtNm;
	}

	public void setRscShrtNm(String rscShrtNm) {
		this.rscShrtNm = rscShrtNm;
	}

	public String getRscCtgryDes() {
		return rscCtgryDes;
	}

	public void setRscCtgryDes(String rscCtgryDes) {
		this.rscCtgryDes = rscCtgryDes;
	}
	
}