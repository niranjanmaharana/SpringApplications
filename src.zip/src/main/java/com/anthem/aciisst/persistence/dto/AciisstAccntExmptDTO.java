package com.anthem.aciisst.persistence.dto;

import java.sql.Timestamp;


public class AciisstAccntExmptDTO {
	private String acctId;

	private String creatdByUserId;

	private Timestamp creatdDtm;

	private String rptgIncrdIndCd;

	private String updtdByUserId;

	private Timestamp updtdDtm;

	

	public String getAcctId() {
		return this.acctId;
	}

	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getRptgIncrdIndCd() {
		return this.rptgIncrdIndCd;
	}

	public void setRptgIncrdIndCd(String rptgIncrdIndCd) {
		this.rptgIncrdIndCd = rptgIncrdIndCd;
	}

	public String getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(String updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Timestamp getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Timestamp updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

}