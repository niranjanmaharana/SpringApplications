package com.anthem.aciisst.persistence.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.DateUtil;
import com.anthem.aciisst.persistence.dto.SaveFilterDTO;
import com.anthem.aciisst.persistence.dto.SaveFilterDtlDTO;


@Repository
public class SaveAccountStructureFilterDAO extends AbstractDAO{
	
	@Value("${spring.jpa.properties.hibernate.jdbc.batch_size}")
	private int batchSize;

	public List<SaveFilterDTO> getSavedFiltersByAcctIdAndUserId(String accountId, int aciisstUserId) throws SQLException {
		List<SaveFilterDTO> filterList = new ArrayList<>();
		Timestamp currentTime = DateUtil.getCurrentTimestamp();
		String selectQuery = "select fltr.* from ACIISST_SAVE_FLTR fltr WHERE fltr.ACCT_ID = ? and fltr.CREATD_BY_USER_ID = ? and fltr.FLTR_ACTV_FLAG_CD = ?"
				+ " and fltr.EFCTV_DTM <= ? and fltr.TRMNTN_DTM >= ? order by fltr.SAVE_FLTR_NM asc with UR ";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				pstmt.setString(1, accountId);
				pstmt.setInt(2, aciisstUserId);
				pstmt.setString(3, ACIISSTConstants.ACTV_FLG_Y);
				pstmt.setTimestamp(4, currentTime);
				pstmt.setTimestamp(5, currentTime);
				try (ResultSet rs = pstmt.executeQuery();) {
					SaveFilterDTO dto = null;
					while (rs.next()) {
						dto = new SaveFilterDTO();
						dto.setId(rs.getInt("SAVE_FLTR_ID"));
						dto.setName(rs.getString("SAVE_FLTR_NM"));
						dto.setDescription(rs.getString("SAVE_FLTR_DESC"));
						dto.setTypeCd(rs.getString("SAVE_FLTR_TYPE_CD"));
						dto.setAcctId(rs.getString("ACCT_ID"));
						dto.setActiveFlag(rs.getString("FLTR_ACTV_FLAG_CD"));
						dto.setEffectiveDtm(rs.getTimestamp("EFCTV_DTM"));
						dto.setTrmntnDtm(rs.getTimestamp("TRMNTN_DTM"));
						dto.setCreatdDtm(rs.getTimestamp("CREATD_DTM"));
						dto.setUpdtdDtm(rs.getTimestamp("UPDTD_DTM"));
						dto.setCreatdByUserId(rs.getInt("CREATD_BY_USER_ID"));
						dto.setUpdtdByUserId(rs.getInt("UPDTD_BY_USER_ID"));

						filterList.add(dto);
					}
				}
			}
		}

		return filterList;
	}
	
	public SaveFilterDTO getSavedFilterByName(String accountId, int aciisstUserId, String saveFltrName) throws SQLException {
		SaveFilterDTO dto = null;
		Timestamp currentTime = DateUtil.getCurrentTimestamp();

		String selectQuery = "select fltr.* from ACIISST_SAVE_FLTR fltr "
				+ "WHERE fltr.ACCT_ID = ? and fltr.CREATD_BY_USER_ID = ? and LOWER(fltr.SAVE_FLTR_NM) = ? and fltr.FLTR_ACTV_FLAG_CD = ?"
				+ " and fltr.EFCTV_DTM <= ? and fltr.TRMNTN_DTM >= ? with UR ";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				pstmt.setString(1, accountId);
				pstmt.setInt(2, aciisstUserId);
				pstmt.setString(3, saveFltrName.toLowerCase());
				pstmt.setString(4, ACIISSTConstants.ACTV_FLG_Y);
				pstmt.setTimestamp(5, currentTime);
				pstmt.setTimestamp(6, currentTime);
				try (ResultSet rs = pstmt.executeQuery();) {
					if (rs != null) {
						if (rs.next()) {
							dto = new SaveFilterDTO();
							dto.setId(rs.getInt("SAVE_FLTR_ID"));
							dto.setName(rs.getString("SAVE_FLTR_NM"));
							dto.setDescription(rs.getString("SAVE_FLTR_DESC"));
							dto.setTypeCd(rs.getString("SAVE_FLTR_TYPE_CD"));
							dto.setAcctId(rs.getString("ACCT_ID"));
							dto.setActiveFlag(rs.getString("FLTR_ACTV_FLAG_CD"));
							dto.setEffectiveDtm(rs.getTimestamp("EFCTV_DTM"));
							dto.setTrmntnDtm(rs.getTimestamp("TRMNTN_DTM"));
							dto.setCreatdDtm(rs.getTimestamp("CREATD_DTM"));
							dto.setUpdtdDtm(rs.getTimestamp("UPDTD_DTM"));
							dto.setCreatdByUserId(rs.getInt("CREATD_BY_USER_ID"));
							dto.setUpdtdByUserId(rs.getInt("UPDTD_BY_USER_ID"));
						}
					}
				}
			}
		}
		return dto;
	}
	
	public SaveFilterDTO updateSavedFilter(SaveFilterDTO dto) throws SQLException {

		String selectQuery = "update ACIISST_SAVE_FLTR set SAVE_FLTR_NM = ?, SAVE_FLTR_DESC = ?, UPDTD_DTM = ?, UPDTD_BY_USER_ID = ?"
				+ " WHERE SAVE_FLTR_ID = ? and CREATD_BY_USER_ID = ? ";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				pstmt.setString(1, dto.getName());
				pstmt.setString(2, dto.getDescription());
				pstmt.setTimestamp(3, dto.getUpdtdDtm());
				pstmt.setInt(4, dto.getUpdtdByUserId());
				pstmt.setInt(5, dto.getId());
				pstmt.setInt(6, dto.getUpdtdByUserId());

				pstmt.executeUpdate();
			}
		}

		return dto;
	}
	
	public SaveFilterDTO deleteSavedFilter(SaveFilterDTO dto) throws SQLException {
		
		String selectQuery = "update ACIISST_SAVE_FLTR set FLTR_ACTV_FLAG_CD = ?, TRMNTN_DTM = ?, UPDTD_DTM = ?, UPDTD_BY_USER_ID = ?"
				+ " WHERE SAVE_FLTR_ID = ? and CREATD_BY_USER_ID = ? ";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				pstmt.setString(1, dto.getActiveFlag());
				pstmt.setTimestamp(2, dto.getTrmntnDtm());
				pstmt.setTimestamp(3, dto.getUpdtdDtm());
				pstmt.setInt(4, dto.getUpdtdByUserId());
				pstmt.setInt(5, dto.getId());
				pstmt.setInt(6, dto.getUpdtdByUserId());
				
				pstmt.executeUpdate();
			}
		}

		return dto;
	}
	
	public List<SaveFilterDtlDTO> getFilterDtlsById(int fltrId, int aciisstUserId) throws SQLException {
		List<SaveFilterDtlDTO> filterDtlList = new ArrayList<>();

		String selectQuery = "select fltr.SAVE_FLTR_ID, fltr.SAVE_FLTR_NM, fltr.SAVE_FLTR_DESC, fltr.SAVE_FLTR_TYPE_CD, fltr.ACCT_ID, fltr.FLTR_ACTV_FLAG_CD"
				+ " ,dtl.FLTR_PARAM_NM, dtl.FLTR_CODE, dtl.FLTR_VALUE from ACIISST_SAVE_FLTR fltr "
				+ " left join ACIISST_SAVE_FLTR_DTL dtl on fltr.SAVE_FLTR_ID = dtl.SAVE_FLTR_ID"
				+ " WHERE fltr.CREATD_BY_USER_ID = ? and fltr.SAVE_FLTR_ID = ? "
				+ " with UR ";

		try (Connection connObj = dataSource.getConnection();) {
			try (PreparedStatement pstmt = connObj.prepareStatement(selectQuery);) {
				pstmt.setInt(1, aciisstUserId);
				pstmt.setInt(2, fltrId);
				try (ResultSet rs = pstmt.executeQuery();) {
					SaveFilterDtlDTO dto = null;
					while (rs.next()) {
						dto = new SaveFilterDtlDTO();
						dto.setSaveFltrId(rs.getInt("SAVE_FLTR_ID"));
						dto.setName(rs.getString("SAVE_FLTR_NM"));
						dto.setDescription(rs.getString("SAVE_FLTR_DESC"));
						dto.setTypeCd(rs.getString("SAVE_FLTR_TYPE_CD"));
						dto.setAcctId(rs.getString("ACCT_ID"));
						dto.setSaveFltrActiveFlag(rs.getString("FLTR_ACTV_FLAG_CD"));
						dto.setFilterParamName(rs.getString("FLTR_PARAM_NM"));
						dto.setFilterCode(rs.getString("FLTR_CODE"));
						dto.setFilterValue(rs.getString("FLTR_VALUE"));
						
						filterDtlList.add(dto);
					}
				}
			}
		}

		return filterDtlList;
	}

	public int addSaveFilter(SaveFilterDTO dto, List<SaveFilterDtlDTO> dtlDtoList) throws SQLException{
		SaveFilterDtlDTO dtlDto = null;
		int count = -1;
		int id = -1;
		try (Connection con = dataSource.getConnection();) {
			try{
				con.setAutoCommit(false);
				
				String insertSql = "insert into ACIISST_SAVE_FLTR "
						+ " (SAVE_FLTR_NM, SAVE_FLTR_DESC, SAVE_FLTR_TYPE_CD, ACCT_ID, FLTR_ACTV_FLAG_CD, EFCTV_DTM, TRMNTN_DTM"
						+ " ,CREATD_DTM, CREATD_BY_USER_ID, UPDTD_DTM, UPDTD_BY_USER_ID) "
						+ " values( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
				try (PreparedStatement ps = con.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
					ps.setString(1, dto.getName());
					ps.setString(2, dto.getDescription());
					ps.setString(3, dto.getTypeCd());
					ps.setString(4, dto.getAcctId());
					ps.setString(5, dto.getActiveFlag());
					ps.setTimestamp(6, dto.getEffectiveDtm());
					ps.setTimestamp(7, dto.getTrmntnDtm());
					ps.setTimestamp(8, dto.getCreatdDtm());
					ps.setInt(9, dto.getCreatdByUserId());
					ps.setTimestamp(10, dto.getUpdtdDtm());
					ps.setInt(11, dto.getUpdtdByUserId());
					
					count = ps.executeUpdate();
					
					try(ResultSet rs = ps.getGeneratedKeys();){
						if(rs.next()){
							dto.setId(rs.getInt(1));
							id = rs.getInt(1);
						}else{
							throw new SQLException("Creating save filter failed, Not able to get id");
						}
					}
				}
				
				String insertDtlSql = "insert into ACIISST_SAVE_FLTR_DTL "
						+ " (SAVE_FLTR_ID, FLTR_PARAM_NM, FLTR_CODE, FLTR_VALUE, ACTV_FLAG_CD, CREATD_DTM, CREATD_BY_USER_ID, UPDTD_DTM, UPDTD_BY_USER_ID) "
						+ " values( ?, ?, ?, ?, ?, ?, ?, ?, ?)";
				
				try (PreparedStatement ps = con.prepareStatement(insertDtlSql)) {
					if (!CollectionUtils.isEmpty(dtlDtoList)) {
						for (int i = 0; i < dtlDtoList.size(); i++) {
							dtlDto = dtlDtoList.get(i);
							ps.setInt(1,id);
							ps.setString(2, dtlDto.getFilterParamName());
							ps.setString(3, dtlDto.getFilterCode());
							ps.setString(4, dtlDto.getFilterValue());
							ps.setString(5, dtlDto.getActvFlagCd());
							ps.setTimestamp(6, dtlDto.getCreatdDtm());
							ps.setInt(7, dtlDto.getCreatdByUserId());
							ps.setTimestamp(8, dtlDto.getUpdtdDtm());
							ps.setInt(9, dtlDto.getUpdtdByUserId());
							ps.addBatch();
							
							if ((i > 0) && (i % 1 == 0)) {
								ps.executeBatch();
								ps.clearBatch();
							}
						}
						ps.executeBatch();
					}
				}
				
				con.commit();
			}catch (SQLException e){
				con.rollback();
				throw new SQLException("JDBC transaction rollbacked successfully- " + e);
			}
		} 
		
		return count;
	}

}
