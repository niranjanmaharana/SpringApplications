package com.anthem.aciisst.reports.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.core.io.ClassPathResource;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.AcisstUtil;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;

public class ReportPdfLayout extends PdfPageEventHelper{
	Image image ;
	PdfPTable table ;
	Paragraph rightHeader;
	public Paragraph getRightHeader() {
		return rightHeader;
	}
	public void setRightHeader(Paragraph rightHeader) {
		this.rightHeader = rightHeader;
	}

	protected String accountId; 
	protected float tableHeight ;
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	@Override
	public void onOpenDocument(PdfWriter writer, Document document) {
    	try {
    		ClassPathResource cpr = new ClassPathResource("./image/logo.png");
    		byte[] byteArray = AcisstUtil.convertInputstreamToByteArray(cpr.getInputStream());
    		    
        	image = Image.getInstance(byteArray);
			image.setAbsolutePosition(12, 300);
			image.setIndentationLeft(0);
			image.scaleAbsolute(120, 30);
			table = createPageHeaderTable(document, image);
		} catch (IOException | DocumentException e) {
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(accountId);
			logDetail.setUserId( ACIISSTConstants.NA);
			logDetail.setUri("./image/logo.png");
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}
        
    }
	@Override
    public void onEndPage(PdfWriter writer, Document document) {
        table.writeSelectedRows(0, 1, document.left(), document.top() + ((document.topMargin() + tableHeight) / 2) , writer.getDirectContent());
        table.writeSelectedRows(1, 2, document.left(), document.bottom() , writer.getDirectContent());
	}
	
	private PdfPTable createPageHeaderTable(Document document, Image image) {
		Font normalFont = new Font(Font.FontFamily.TIMES_ROMAN, 9, Font.NORMAL);
		SimpleDateFormat dt1 = new SimpleDateFormat("MM/dd/yyyy");
		float[] columnWidths = new float[]{500, 500};
		table = new PdfPTable(columnWidths);
		PdfPCell imageCell = new PdfPCell(image);
		imageCell.setHorizontalAlignment(Element.ALIGN_LEFT);
		imageCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		imageCell.setBorder(0);
		PdfPCell cell = new PdfPCell(rightHeader); 
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setVerticalAlignment(Element.ALIGN_TOP);
		cell.setBorder(0);
		table.setTotalWidth(document.right() - document.left());
		table.addCell(imageCell);
		table.addCell(cell);
		PdfPCell footercell = new PdfPCell(new Paragraph("Report run Date :" + dt1.format(new Date()), normalFont)); 
		footercell.setHorizontalAlignment(Element.ALIGN_LEFT);
		footercell.setBorder(0);
		table.addCell(footercell);
		footercell = new PdfPCell(new Paragraph(" "));
		footercell.setBorder(0);
		table.addCell(footercell);
		tableHeight = table.getTotalHeight();
		return table;
	}
	
	public float getTableHeight() {
        return tableHeight;
    }
}
