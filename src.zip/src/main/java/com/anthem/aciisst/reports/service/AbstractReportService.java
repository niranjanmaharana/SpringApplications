package com.anthem.aciisst.reports.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DateFormatSymbols;
import java.text.DecimalFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.AcisstUtil;
import com.anthem.aciisst.common.util.StringUtil;
import com.anthem.aciisst.reports.dto.MembershipReportDTO;
import com.anthem.aciisst.reports.dto.MembershipReportTotalDTO;
import com.anthem.aciisst.reports.web.view.request.MembershipReportRequest;
import com.anthem.aciisst.reports.web.view.response.ReportHeader;

/**
 * @author AF72803
 *
 */
public abstract class AbstractReportService {
	
	public static final String AVG_MEM_PER_CONTRACT=" Avg Members per Contract : ";

	/**
	 * This method will return the Report Headers
	 * 
	 * @param request
	 * @return
	 */
	public abstract List<ReportHeader> getReportHeader(MembershipReportRequest request);

	/**
	 * This method will get the Membership report data
	 * 
	 * @param request
	 * @param forReport
	 * @return
	 */
	public abstract List<Map<String, String>> getReportDetails(MembershipReportRequest request, boolean forReport);

	public abstract void updateExportStatus(String exportId, String smUserId, String status, String errTxt) throws SQLException; 

	/**
	 * This method is to prepare tooltip value for the Month/Total cell
	 * @param month
	 * @param year
	 * @param colName
	 * @param cellValue
	 * @param total
	 * @param columtoal
	 * @param contractTier
	 * @return
	 */
	public String prepareTooltip(String month, String year,BigDecimal columnTotal, MembershipReportDTO cellData,
			String contractTier,String reportType) {
		StringBuilder sb = new StringBuilder();
		int cellValue=0;
		if (ACIISSTConstants.MEMBERS.equals(reportType)) {
			cellValue=cellData!=null?cellData.getMemberMonthsTotal():0;
		}else if ("Contracts".equals(reportType)) {
			cellValue=cellData!=null?cellData.getSubscriberMonthsTotal():0;
		}
		sb.append("Month/Year:").append(new DateFormatSymbols().getShortMonths()[Integer.parseInt(month)-1]).append(" ").append(year).append(",");
		sb.append("Contract Type:").append(contractTier).append(",");
		sb.append("# of ").append(reportType+":").append(cellValue).append(",");
		BigDecimal perc = BigDecimal.ZERO;
		if(columnTotal.compareTo(BigDecimal.ZERO)!=0 || cellValue!=0) {
			
			 perc = AcisstUtil.bigDecimaldivision(new BigDecimal(cellValue),columnTotal).multiply(new BigDecimal(100));
		}
		DecimalFormat dformat = new DecimalFormat("0.0");

		sb.append("% of Total ").append(reportType+":").append(dformat.format(perc));
		if(ACIISSTConstants.MEMBERS.equals(reportType)) {
			sb.append(", ").append(AVG_MEM_PER_CONTRACT).append(cellData!=null?cellData.getAvgMbrPerCntrct():0);
					}

		return sb.toString();
	}
	
	
	/**
	 * @param month
	 * @param year
	 * @param colName
	 * @param cellValue
	 * @param total
	 * @param columtoal
	 * @param contractTier
	 * @param reportType
	 * @return
	 */
	public String prepareTooltip(String month, String year, String colName, MembershipReportTotalDTO cellValue,
			String contractTier,String reportType) {
		StringBuilder sb = new StringBuilder();
		sb.append("Month/Year:").append(new DateFormatSymbols().getShortMonths()[Integer.parseInt(month)-1]).append(" ").append(year).append(",");
		sb.append("Contract Type:").append(contractTier).append(",");
		sb.append("# of ").append(reportType+":").append(cellValue!=null?cellValue.getMonthValueTotal():0).append(",");	

		sb.append("% of Total ").append(reportType+":").append("100");	

		if(ACIISSTConstants.MEMBERS.equals(reportType)) {
			sb.append(", ").append(AVG_MEM_PER_CONTRACT).append(cellValue!=null?cellValue.getAvgMbrPerCntrctTotal():0);
					}
		return sb.toString();
	}

	/**
	 * This method prepare tooltip for the avrage column
	 * 
	 * @param colName
	 * @param cellValue
	 * @return
	 */
	public String prepareTooltipAvg(String colName, BigDecimal cellValue, BigDecimal avgPercOfAvgTotal, String reportType,Integer avgMemperCntrct,Integer avgAge) {
		StringBuilder sb = new StringBuilder();
		sb.append("Time Period:").append(colName).append(",");
		sb.append("Avg # of ").append(reportType + ":").append(cellValue).append(",");
		
		DecimalFormat dformat = new DecimalFormat("0.0");
		sb.append("% of Avg total ").append(reportType + ":").append(dformat.format(avgPercOfAvgTotal)).append(",");
		sb.append("Avg ").append(ACIISSTConstants.MEMBERS.equals(reportType)?"Member":"Subscriber").append(" Age :").append(avgAge);
		if(ACIISSTConstants.MEMBERS.equals(reportType)) {
			sb.append(", ").append(AVG_MEM_PER_CONTRACT).append(avgMemperCntrct);
					}
		return sb.toString();
	}
	
	
	public BigDecimal getPercOfAvgTotal(BigDecimal cellValue, BigDecimal total) {		
		
		
		 return	AcisstUtil.bigDecimaldivision(cellValue, total).multiply(new BigDecimal(100));
		
		
	}
	
	
	public BigDecimal getPercOfAvgTotalforPrior(Map<String, MembershipReportDTO> priorMap,BigDecimal cellValue) {
		
		BigDecimal priorColumTotal=BigDecimal.ZERO;
		for(Map.Entry<String, MembershipReportDTO> mappingSet:priorMap.entrySet()) {
			if(mappingSet.getValue()!=null) {
				priorColumTotal=priorColumTotal.add(mappingSet.getValue().getPriorAvg());
			}
		}	
		return	AcisstUtil.bigDecimaldivision(cellValue, priorColumTotal).multiply(new BigDecimal(100));
		
	}

	/**
	 * This method prepare tooltip for the Trend column
	 * 
	 * @param colName
	 * @param cellValue
	 * @return
	 */
	public String prepareTooltipTrend(String colName, String cellValue) {
		StringBuilder sb = new StringBuilder();
		sb.append("Trend Period:").append(colName).append(",");
		sb.append("Trend :").append(cellValue);

		return sb.toString();
	}

	/**
	 * This method will return row total for particular row/contractTier data
	 * 
	 * @param responseData
	 * @param key
	 * @return
	 */
	public int getRowTotal(Map<String, Map<String, MembershipReportDTO>> responseData, String key,
			MembershipReportRequest request, Map<String, MembershipReportDTO> innermap,List<String> header) {
		int total = 0;
		Map<String, MembershipReportDTO> contractTierdata = responseData.get(key);
		if (ACIISSTConstants.REPORT_TYPE_MEMBERBYMONTH.equals(request.getReportType())) {
			for(String headerKey:header) {
				total+=	contractTierdata.get(headerKey)!=null?contractTierdata.get(headerKey).getMemberMonthsTotal():0;
			}
		} else if (ACIISSTConstants.REPORT_TYPE_CONTRACTSBYMONTH.equals(request.getReportType())) {
			for(String headerKey:header) {
				total+=	contractTierdata.get(headerKey)!=null?contractTierdata.get(headerKey).getSubscriberMonthsTotal():0;
			}
		}
		
		//At a time we will get only medical or Pharmacy
		if (ACIISSTConstants.MEM_RPRT_COV_MEDICAL.equalsIgnoreCase(request.getCoverageType())
				&& request.getHiddenMedicalColumns() != null) {

			for (String hiddenMonth : request.getHiddenMedicalColumns()) {
				if(innermap.get(hiddenMonth)!=null) {					
					total = ACIISSTConstants.REPORT_TYPE_MEMBERBYMONTH.equals(request.getReportType())
							? total - (innermap.get(hiddenMonth).getMemberMonthsTotal())
									: total - (innermap.get(hiddenMonth).getSubscriberMonthsTotal());
				}
			}
		}
		if (ACIISSTConstants.MEM_RPRT_COV_PHARMACY.equalsIgnoreCase(request.getCoverageType())
				&& request.getHiddenPharmacyColumns() != null) {

			for (String hiddenMonth : request.getHiddenPharmacyColumns()) {
				if(innermap.get(hiddenMonth)!=null) {	
				total = ACIISSTConstants.REPORT_TYPE_MEMBERBYMONTH.equals(request.getReportType())
						? total - (innermap.get(hiddenMonth).getMemberMonthsTotal())
						: total - (innermap.get(hiddenMonth).getSubscriberMonthsTotal());
				}
			}
		}
		return total;
	}

	/**
	 * This method will return Column Total
	 * 
	 * @param responseData
	 * @return
	 */
	public Map<String, MembershipReportTotalDTO> getColumnTotal(Map<String, Map<String, MembershipReportDTO>> responseData,
			String reportType) {
		Set<String> key = responseData.keySet();
		Map.Entry<String, Map<String, MembershipReportDTO>> entry = responseData.entrySet().iterator().next();
		String firstKey = entry.getKey();

		Set<String> monthValueKeys = responseData.get(firstKey).keySet();
		Map<String, MembershipReportTotalDTO> totMonthMap = new LinkedHashMap<>();
		for (String monthValue : monthValueKeys) {
			int monthTot = 0;
			int avgMbrPerCntrctTotal=0;
			for (String contKey : key) {
				if (ACIISSTConstants.REPORT_TYPE_MEMBERBYMONTH.equals(reportType) && responseData.get(contKey)!= null && responseData.get(contKey).get(monthValue) != null) {
						monthTot += responseData.get(contKey).get(monthValue).getMemberMonthsTotal();
						avgMbrPerCntrctTotal+=responseData.get(contKey).get(monthValue).getAvgMbrPerCntrct();
					
				} else if (ACIISSTConstants.REPORT_TYPE_CONTRACTSBYMONTH.equals(reportType) && responseData.get(contKey)!= null && responseData.get(contKey).get(monthValue) != null) {
						monthTot += responseData.get(contKey).get(monthValue).getSubscriberMonthsTotal();
				}
			}
			MembershipReportTotalDTO monthValueData= new MembershipReportTotalDTO();
			monthValueData.setMonthValueTotal(monthTot);
			monthValueData.setAvgMbrPerCntrctTotal(avgMbrPerCntrctTotal);
			totMonthMap.put(monthValue, monthValueData);
		}

		return totMonthMap;
	}

	/**
	 * This method will return list of ReportHeader which contains month value
	 * 
	 * @param request
	 * @param headerList
	 */
	public void getMonthValue(String startPeriod,String endPeriod, List<ReportHeader> headerList) {
		String currStart = startPeriod;
		int currTimePeriod = AcisstUtil.getDiffMonth(startPeriod, endPeriod);
		String month = currStart.length() > 2 ? currStart.substring(currStart.length() - 2) : currStart;
		String yearstr = currStart.length() > 4 ? currStart.substring(0, currStart.length() - 2) : currStart;
		int tempMon = Integer.parseInt(month);
		int tempYer = Integer.parseInt(yearstr);
		while (currTimePeriod != 0) {
			ReportHeader rHeader = new ReportHeader();
			if (tempMon > 12) {
				tempMon = 01;
				tempYer++;

			}

			rHeader.setColText(new DateFormatSymbols().getShortMonths()[tempMon - 1] + " " + tempYer);
			rHeader.setColDataIndex(ACIISSTConstants.MEM_RPRT_MONTH_KEY + String.format("%02d", tempMon) + tempYer);
			headerList.add(rHeader);
			tempMon++;
			currTimePeriod--;

		}
	}

	/**
	 * this method will prepare map with month details and total for that month/Year
	 * 
	 * @param yearMonth
	 * @param monthTotal
	 * @param mainMap
	 * @param key
	 * @return
	 */
	public Map<String, MembershipReportDTO> getvalue(MembershipReportDTO reportData,
			Map<String, Map<String, MembershipReportDTO>> mainMap) {
		String str = reportData.getYearMonth().toString();
		Map<String, MembershipReportDTO> innermap;
		String month = str.length() > 2 ? str.substring(str.length() - 2) : str;
		String yearstr = str.length() > 4 ? str.substring(0, str.length() - 2) : str;
		if (mainMap.get(reportData.getContractType()) == null) {
			innermap = new LinkedHashMap<>();

			innermap.put(ACIISSTConstants.MEM_RPRT_MONTH_KEY + month + yearstr, reportData);

		} else {
			innermap = mainMap.get(reportData.getContractType());
			innermap.put(ACIISSTConstants.MEM_RPRT_MONTH_KEY + month + yearstr, reportData);
		}

		return innermap;
	}

	/**
	 * This method will prepare map with Filter name as key and filters selected by
	 * user as values
	 * 
	 * @param request
	 * @return
	 */
	public Map<String, String> globalFilter(MembershipReportRequest request) {
		Map<String, String> globalFilters = new LinkedHashMap<>();
		globalFilters.put("Account Number", request.getAccountId());
		if(request.getStructuredFilterDisplayValues()!=null) {			
			globalFilters.put("Time Period Type", request.getStructuredFilterDisplayValues().getTimeperiodType());
			globalFilters.put("Number of Time Periods", request.getStructuredFilterDisplayValues().getNumberoftimeperiod());
			globalFilters.put("Paid or Incurred ", request.getStructuredFilterDisplayValues().getPaidTypeValue());
			globalFilters.put("Number of Run Out Months", request.getStructuredFilterDisplayValues().getRunOutMonthValue());
			globalFilters.put("HCC Threshold", request.getStructuredFilterDisplayValues().getHccThreshold());
		}
		
		String coverage = StringUtil.buildCommaSpaceSeperatedStringFromList(request.getCoverage());
		String ageBand = StringUtil.buildCommaSpaceSeperatedStringFromList(request.getAgeBand());
		String gender = StringUtil.buildCommaSpaceSeperatedStringFromList(request.getGender());
		String relationship = StringUtil.buildCommaSpaceSeperatedStringFromList(request.getRelationship());
		String healthStatus = StringUtil.buildCommaSpaceSeperatedStringFromList(request.getHealthStatus());
		String engagement = StringUtil.buildCommaSpaceSeperatedStringFromList(request.getEngagement());
		String cbsa = StringUtil.buildCommaSpaceSeperatedStringFromList(request.getMsa());
		String state = StringUtil.buildCommaSpaceSeperatedStringFromList(request.getState());
		
		globalFilters.put("Coverage", ACIISSTConstants.EMPTY_BLANK_STRING.equals(coverage) ? ACIISSTConstants.ALL : coverage);
		globalFilters.put("Age Band", ACIISSTConstants.EMPTY_BLANK_STRING.equals(ageBand) ? ACIISSTConstants.ALL : ageBand);
		globalFilters.put("Gender", ACIISSTConstants.EMPTY_BLANK_STRING.equals(gender) ? ACIISSTConstants.ALL : gender);
		globalFilters.put("Relationship", ACIISSTConstants.EMPTY_BLANK_STRING.equals(relationship) ? ACIISSTConstants.ALL : relationship);
		globalFilters.put("Health Status", ACIISSTConstants.EMPTY_BLANK_STRING.equals(healthStatus) ? ACIISSTConstants.ALL : healthStatus);
		//TimeperiodType =custom dont show Engagement
		if(request.getTimeperiodType()!=null && !"custom".equalsIgnoreCase(request.getTimeperiodType())) {			
			globalFilters.put("Engagement", ACIISSTConstants.EMPTY_BLANK_STRING.equals(engagement) ? ACIISSTConstants.ALL : engagement);
		}
		
		globalFilters.put("CBSA", ACIISSTConstants.EMPTY_BLANK_STRING.equals(cbsa) ? ACIISSTConstants.ALL : cbsa);
		globalFilters.put("State", ACIISSTConstants.EMPTY_BLANK_STRING.equals(state) ? ACIISSTConstants.ALL : state);
		return globalFilters;
	}
}