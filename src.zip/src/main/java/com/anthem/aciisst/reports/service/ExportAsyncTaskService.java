package com.anthem.aciisst.reports.service;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.persistence.dao.UserDAO;
import com.anthem.aciisst.persistence.dao.UserExportDAO;
import com.anthem.aciisst.persistence.dto.UserExportDTO;
import com.anthem.aciisst.reports.web.view.request.MembershipReportRequest;

@Service
public class ExportAsyncTaskService {

	@Autowired
	UserDAO userRepository;

	@Autowired
	MembershipReportService membershipReportService;
	
	@Autowired
	UserExportDAO userExportDAO;
	
	

	@Async("threadPoolTaskExecutor")
	public void saveReport(String type, MembershipReportRequest request, UserExportDTO userExport) throws SQLException {

		try {
			if (ACIISSTConstants.PDF.equalsIgnoreCase(type)) {
				
				membershipReportService.downloadReportAsPdf(request, userExport);
				
			} else if (ACIISSTConstants.EXCEL.equalsIgnoreCase(type)) {
				
				membershipReportService.downloadReportAsExcel(request, userExport);
				
			}
		} catch (Exception ex) {
			if(null != userExport ){
				userExport.setSttsCd(ACIISSTConstants.ERROR);
				userExport.setErrTxt(ex.getMessage());
				userExportDAO.updateUserExport(userExport);
			}
		}
	}

	public UserExportDTO init(MembershipReportRequest request, String type) throws SQLException {
		if (ACIISSTConstants.PDF.equalsIgnoreCase(type)) {
			type = ACIISSTConstants.PDF;
		}else if(ACIISSTConstants.EXCEL.equalsIgnoreCase(type)){
			type = ACIISSTConstants.EXCEL_XTN;
		}
		 String id;
		UserExportDTO userExp = new UserExportDTO();
		Calendar calendar = Calendar.getInstance();
		Timestamp currentTimestamp = new Timestamp(calendar.getTime().getTime());
		Date d = new Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		df.format(d);
		id = UUID.randomUUID().toString();
		userExp.setExprtId(id);
		userExp.setAciisstUserId(request.getAciisstUserId());
		userExp.setFileNm("ACIISST_Membership_Report_" + df.format(d));
		userExp.setFileTypeCd(type);
		userExp.setSttsCd(ACIISSTConstants.PENDING);
		userExp.setEnttlmntId(request.getAccountId() + request.getUserId());
		userExp.setCreatdDtm(currentTimestamp);
		userExp.setCreatdByUserId(request.getAciisstUserId());
		userExp.setSbmtDtm(currentTimestamp);
		userExp.setExprtDtm(currentTimestamp);
		userExp.setUpdtdByUserId(request.getAciisstUserId());
		userExp.setUpdtdDtm(currentTimestamp);
		
		userExportDAO.saveUserExport(userExp);
		return userExp;

	}
}
