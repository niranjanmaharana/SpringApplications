package com.anthem.aciisst.reports.web.view.response;

public class ReportHeader {

	private String colText;
	private String colDataIndex;
	
	public String getColText() {
		return colText;
	}
	public void setColText(String colText) {
		this.colText = colText;
	}
	public String getColDataIndex() {
		return colDataIndex;
	}
	public void setColDataIndex(String colDataIndex) {
		this.colDataIndex = colDataIndex;
	}
	
}
