package com.anthem.aciisst.reports.web.view.response;

import java.util.Map;

public class MembershipReportResponse {
	private String contractType;
	private Integer averageCurrent;
	private Integer totalPrior;
	private Integer averagePrior;
	private Integer totalPrior2;
	
	private Integer averagePrior2;
	private Integer trend;
	private Integer total;
	private Map<String,Integer> monthValue;
	
	public Map<String, Integer> getMonthValue() {
		return monthValue;
	}
	public void setMonthValue(Map<String, Integer> monthValue) {
		this.monthValue = monthValue;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public Integer getAverageCurrent() {
		return averageCurrent;
	}
	public void setAverageCurrent(Integer averageCurrent) {
		this.averageCurrent = averageCurrent;
	}
	public Integer getTotalPrior() {
		return totalPrior;
	}
	public void setTotalPrior(Integer totalPrior) {
		this.totalPrior = totalPrior;
	}
	public Integer getAveragePrior() {
		return averagePrior;
	}
	public void setAveragePrior(Integer averagePrior) {
		this.averagePrior = averagePrior;
	}
	public Integer getTrend() {
		return trend;
	}
	public void setTrend(Integer trend) {
		this.trend = trend;
	}
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	public Integer getTotalPrior2() {
		return totalPrior2;
	}
	public void setTotalPrior2(Integer totalPrior2) {
		this.totalPrior2 = totalPrior2;
	}
	public Integer getAveragePrior2() {
		return averagePrior2;
	}
	public void setAveragePrior2(Integer averagePrior2) {
		this.averagePrior2 = averagePrior2;
	} 

}
