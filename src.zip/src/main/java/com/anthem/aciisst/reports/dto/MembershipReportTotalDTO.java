package com.anthem.aciisst.reports.dto;

public class MembershipReportTotalDTO {
	private Integer monthValueTotal;
	private Integer avgMbrPerCntrctTotal;
	public Integer getAvgMbrPerCntrctTotal() {
		return avgMbrPerCntrctTotal;
	}
	public void setAvgMbrPerCntrctTotal(Integer avgMbrPerCntrctTotal) {
		this.avgMbrPerCntrctTotal = avgMbrPerCntrctTotal;
	}
	public Integer getMonthValueTotal() {
		return monthValueTotal;
	}
	public void setMonthValueTotal(Integer monthValueTotal) {
		this.monthValueTotal = monthValueTotal;
	}
	
	
	
}
