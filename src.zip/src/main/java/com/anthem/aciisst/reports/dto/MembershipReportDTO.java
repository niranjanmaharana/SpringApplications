package com.anthem.aciisst.reports.dto;

import java.math.BigDecimal;

public class MembershipReportDTO {
	
	 private String contractType;
	 private Integer yearMonth = 0;
	 private Integer subscriberMonthsTotal = 0;
	 private Integer memberMonthsTotal = 0;
	 private Integer avgMbrPerCntrct = 0;
	 private Integer mbrAvgAge = 0;
	 private Integer sbscrbrAvgAge = 0;
	 
	 private double priorTotal;
	 private Integer priorAvgMbrPerCnrct = 0;
	 private BigDecimal priorAvg = new BigDecimal(0);
	 
	 
	 public BigDecimal getPriorAvg() {
		return priorAvg;
	}
	public void setPriorAvg(BigDecimal priorAvg) {
		this.priorAvg = priorAvg;
	}
	private Integer avgAge;
	 
	public Integer getAvgAge() {
		return avgAge;
	}
	public void setAvgAge(Integer avgAge) {
		this.avgAge = avgAge;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public Integer getYearMonth() {
		return yearMonth;
	}
	public void setYearMonth(Integer yearMonth) {
		this.yearMonth = yearMonth;
	}
	public Integer getSubscriberMonthsTotal() {
		return subscriberMonthsTotal;
	}
	public void setSubscriberMonthsTotal(Integer subscriberMonthsTotal) {
		this.subscriberMonthsTotal = subscriberMonthsTotal;
	}
	public Integer getMemberMonthsTotal() {
		return memberMonthsTotal;
	}
	public void setMemberMonthsTotal(Integer memberMonthsTotal) {
		this.memberMonthsTotal = memberMonthsTotal;
	}
	public Integer getAvgMbrPerCntrct() {
		return avgMbrPerCntrct;
	}
	public void setAvgMbrPerCntrct(Integer avgMbrPerCntrct) {
		this.avgMbrPerCntrct = avgMbrPerCntrct;
	}
	public Integer getMbrAvgAge() {
		return mbrAvgAge;
	}
	public void setMbrAvgAge(Integer mbrAvgAge) {
		this.mbrAvgAge = mbrAvgAge;
	}
	public Integer getSbscrbrAvgAge() {
		return sbscrbrAvgAge;
	}
	public void setSbscrbrAvgAge(Integer sbscrbrAvgAge) {
		this.sbscrbrAvgAge = sbscrbrAvgAge;
	}
	public 	 double getPriorTotal() {
		return priorTotal;
	}
	public void setPriorTotal(double priorTotal) {
		this.priorTotal = priorTotal;
	}
	
	public Integer getPriorAvgMbrPerCnrct() {
		return priorAvgMbrPerCnrct;
	}
	public void setPriorAvgMbrPerCnrct(Integer priorAvgMbrPerCnrct) {
		this.priorAvgMbrPerCnrct = priorAvgMbrPerCnrct;
	}
	
	
	
}
