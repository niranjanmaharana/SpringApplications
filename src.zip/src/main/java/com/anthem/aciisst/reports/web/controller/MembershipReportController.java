package com.anthem.aciisst.reports.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.account.web.view.response.BaseAccountStructureDTO;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.common.web.view.ResponseView;
import com.anthem.aciisst.persistence.dto.UserExportDTO;
import com.anthem.aciisst.reports.service.ExportAsyncTaskService;
import com.anthem.aciisst.reports.service.ExportFileHelper;
import com.anthem.aciisst.reports.service.MembershipReportService;
import com.anthem.aciisst.reports.web.view.request.MembershipReportRequest;
import com.anthem.aciisst.reports.web.view.response.ReportHeader;
import com.anthem.aciisst.reports.web.view.response.UserExportResponseView;
import com.anthem.aciisst.security.dto.AppUser;

/**
 * @author AF72803
 *
 */
@CrossOrigin
@RestController
@RequestMapping("report/membershipReport")
public class MembershipReportController {
	
	@Autowired
	MembershipReportService reportService;
	
	@Autowired
	ExportFileHelper helper;
	
	@Autowired
	ExportAsyncTaskService exportAsyncTaskService;
	
	/**
	 * This method will get header for the membership report grid
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/header")
	public List<ReportHeader> getMembershipReportHeader(@RequestBody MembershipReportRequest request, HttpServletRequest httpRequest) {
		List<ReportHeader> resp = new ArrayList<>();
		try {
			
			 resp = reportService.getReportHeader(request);
			 return resp;
			 
		} catch (Exception e) {
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(request.getAccountId());
			logDetail.setUserId( request.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}

		return resp;
	}
	
	/**
	 * This method will take request as MembershipReportRequest and return the report data for the given request
	 * 
	 * @param request
	 * @param coverageType
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/{coverageType}")
	public List<Map<String, String>> getMembershipReport(@RequestBody MembershipReportRequest request,
			@PathVariable("coverageType") String coverageType, HttpServletRequest httpRequest) {
		List<Map<String,String>> resp = new ArrayList<>();
		boolean downloadReportFlag = true;
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		AppUser user = (AppUser) authentication.getPrincipal();
	
		int userIdInt = user.getUserIdInt();
		request.setAciisstUserId(userIdInt);
		
		try {
			 request.setCoverageType(coverageType);
			 resp= reportService.getReportDetails(request, downloadReportFlag);
			 return resp;
			 
		} catch (Exception e) {
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(request.getAccountId());
			logDetail.setUserId( request.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}
		
		return resp;
	}
	
	/**
	 * This method is to save  the membership report in particular location
	 * @param request
	 * @param coverageType
	 * @param response
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/download/{coverageType}/{type}")
	public ResponseView<String> saveReportsAtNasLocation(@RequestBody MembershipReportRequest request,@PathVariable("coverageType") String coverageType,@PathVariable("type") String type
			,HttpServletResponse response, HttpServletRequest httpRequest) {
		
			ResponseView<String> responseView = new ResponseView<>();
			responseView.setData("Download request submitted successfully");
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);

			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			AppUser user = (AppUser) authentication.getPrincipal();
		
			int userIdInt = user.getUserIdInt();
			request.setAciisstUserId(userIdInt);
		
		try {
							
			request.setCoverageType(coverageType);

			UserExportDTO userExport =exportAsyncTaskService.init(request, type);
			exportAsyncTaskService.saveReport(type, request, userExport);
				
				
		} catch (Exception e) {
			responseView.setData("Error submitting Download request - " + e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(request.getAccountId());
			logDetail.setUserId( request.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}	

		return responseView;
	}
	
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/read/{exportid}")
    public void readFromNasLocation(@PathVariable("exportid") String exportId, @RequestParam("smUserId") String smUserId,HttpServletResponse response, HttpServletRequest httpRequest){
    		
			ResponseView<String> responseView = new ResponseView<>();
			responseView.setData("Read request submitted successfully for exportId = " + exportId);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
			
			try {	
				reportService.getExportForUser(exportId, smUserId, response);
			} catch (Exception e) {
				responseView.setData("Error reading file for exportId = " + exportId + " :: " + e.getMessage());
				LogDetail logDetail = new LogDetail();
				logDetail.setAccountId(ACIISSTConstants.NA);
				logDetail.setUserId(ACIISSTConstants.NA);
				logDetail.setUri(httpRequest.getRequestURI());
				logDetail.setSystem(ACIISSTConstants.SYSTEM);
				LoggingUtil.logError(this.getClass(),logDetail, e);
			}
           
    } 
	
	
	/**
     * @param userId
     * @param httpRequest
     * @return list of exports available for user to download 
     * with status 'COMPLETED','PENDING','ERROR'
     */
    @RequestMapping(method = RequestMethod.POST, value = "/download/details")
    public ResponseView<List<UserExportResponseView>> getDownloadDetails(@RequestBody BaseAccountStructureDTO request, HttpServletRequest httpRequest){
    	
    	ResponseView<List<UserExportResponseView>> responseView = new ResponseView<>(); 
    	try {
    		List<UserExportResponseView> exportsList = reportService.getUserExportDownloads(request.getUserId());
			responseView.setData(exportsList);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(ACIISSTConstants.NA);
			logDetail.setUserId( request.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);

		}
    	return responseView;
    } 
	
    
	
}
