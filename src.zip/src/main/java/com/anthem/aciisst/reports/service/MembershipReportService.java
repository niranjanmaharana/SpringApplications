package com.anthem.aciisst.reports.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.anthem.aciisst.account.web.view.response.AccountStructureDisplayValueDTO;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.AcisstUtil;
import com.anthem.aciisst.persistence.dao.AccountDAO;
import com.anthem.aciisst.persistence.dao.AppPropertyDAO;
import com.anthem.aciisst.persistence.dao.MembershipReportDAO;
import com.anthem.aciisst.persistence.dao.UserDAO;
import com.anthem.aciisst.persistence.dao.UserExportDAO;
import com.anthem.aciisst.persistence.dto.AccountDTO;
import com.anthem.aciisst.persistence.dto.AppPropertyDTO;
import com.anthem.aciisst.persistence.dto.User;
import com.anthem.aciisst.persistence.dto.UserExportDTO;
import com.anthem.aciisst.reports.dto.MembershipReportDTO;
import com.anthem.aciisst.reports.dto.MembershipReportTotalDTO;
import com.anthem.aciisst.reports.web.view.request.MembershipReportRequest;
import com.anthem.aciisst.reports.web.view.response.ReportHeader;
import com.anthem.aciisst.reports.web.view.response.UserExportResponseView;

/**
 * @author AF72803
 *
 */
@Service
public class MembershipReportService extends AbstractReportService {
	

	@Autowired
	PdfExporterService pdfExportService;

	@Autowired
	ExcelExpoterService excelExpoterAspose;

	@Autowired
	UserDAO userDAO;

	@Autowired
	ExportFileHelper exportFileHelper;

	@Autowired
	UserExportDAO userExportDAO;
	
	@Autowired
	AppPropertyDAO appPropertyDAO;
	
	@Autowired
	AccountDAO accountDao;
	
	@Autowired
	MembershipReportDAO membershipReportDAO;

	private static final Logger logger = LoggerFactory.getLogger(MembershipReportService.class);

	/**
	 * This method will get the Membership report data
	 * 
	 * @param request
	 * @param forReport
	 * @return
	 */
	@Override
	public List<Map<String, String>> getReportDetails(MembershipReportRequest request, boolean forReport) {
		List<Map<String, String>> responseData = new ArrayList<>();

		List<Map<String, String>> reportData = retrieveReports(request, forReport);
		responseData.addAll(reportData);

		return responseData;
	}

	/**
	 * This method will return the Report Headers
	 * 
	 * @param request
	 * @return
	 */
	@Override
	public List<ReportHeader> getReportHeader(MembershipReportRequest request) {

		List<ReportHeader> headerList = new ArrayList<>();
		ReportHeader conHeader = new ReportHeader();
		conHeader.setColDataIndex(ACIISSTConstants.MEM_RPRT_CONTRACT_TYPE);
		conHeader.setColText("Contract Type");
		headerList.add(conHeader);
		getMonthValue(request.getCurrentPeriodStart(), request.getCurrentPeriodEnd(), headerList);
		ReportHeader currAvgHeader = new ReportHeader();
		currAvgHeader.setColDataIndex(ACIISSTConstants.MEM_RPRT_AVG_CUR);
		currAvgHeader.setColText("Average Current");
		headerList.add(currAvgHeader);
		if (request.getPriorPeriod1Start() != null) {

			ReportHeader currPrior1Header = new ReportHeader();
			currPrior1Header.setColDataIndex(ACIISSTConstants.MEM_RPRT_AVG_PRIOR1);
			currPrior1Header.setColText(request.getPriorPeriod2Start() != null ? "Average Prior1" : "Average Prior");
			headerList.add(currPrior1Header);
			ReportHeader trend1Header = new ReportHeader();
			trend1Header.setColDataIndex(ACIISSTConstants.MEM_RPRT_TREND1);
			trend1Header.setColText("Trend");
			headerList.add(trend1Header);
		}
		if (request.getPriorPeriod2Start() != null) {

			ReportHeader currPrior2Header = new ReportHeader();
			currPrior2Header.setColDataIndex(ACIISSTConstants.MEM_RPRT_AVG_PRIOR2);
			currPrior2Header.setColText("Average Prior2");
			headerList.add(currPrior2Header);
			ReportHeader trend2Header = new ReportHeader();
			trend2Header.setColDataIndex(ACIISSTConstants.MEM_RPRT_TREND2);
			trend2Header.setColText("Trend1");
			headerList.add(trend2Header);
		}

		return headerList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.anthem.aciisst.reports.service.AbstractReportService#updateExportStatus()
	 * Updates the status of the export.
	 */
	@Override
	public void updateExportStatus(String exportId, String smUserId, String sttsCd, String errTxt) throws SQLException {
		User user = userDAO.findByLognUserId(smUserId);
		
		UserExportDTO userExport = userExportDAO.findUserExport(exportId,user.getUserId());
		if (userExport != null) {
			userExport.setSttsCd(sttsCd);
			userExport.setErrTxt(errTxt);
			userExportDAO.updateUserExport(userExport);
		}
	}

	/**
	 * @param exportId
	 * @param response
	 * @return
	 * @throws IOException
	 * @throws SQLException 
	 */
	public HttpServletResponse getExportForUser(String exportId, String smUserId, HttpServletResponse response)
			throws IOException, SQLException {
		String status = "RETRIEVED";
		String errTxt = ACIISSTConstants.RESPONSE_SUCCESS;

		User user = userDAO.findByLognUserId(smUserId);
	
		UserExportDTO userExport = userExportDAO.findUserExport(exportId, user.getUserId());

		if (userExport != null && "ERROR".equalsIgnoreCase(userExport.getSttsCd())) {
			status = "RETRIEVED_ERROR";
			updateExportStatus(exportId, smUserId, status, errTxt);
			return response;
		}
		boolean isRetrieved = exportFileHelper.readFile(userExport, response);

		if (isRetrieved) {
			userExport.setErrTxt("Sucess");
			userExport.setSttsCd("RETRIEVED");
			userExportDAO.updateUserExport(userExport);
		}

		return response;
	}

	/**
	 * @param userId
	 * @return
	 * @throws SQLException 
	 */
	public List<UserExportResponseView> getUserExportDownloads(String userId) throws SQLException {
		User user = userDAO.findByLognUserId(userId);
		List<UserExportDTO> userExports = userExportDAO.findExportsByUserID(user.getUserId());
		SimpleDateFormat dt1 = new SimpleDateFormat("dd MMM yyyy hh:mm:ss");
		return userExports.stream()
				.map(export -> new UserExportResponseView(export.getFileTypeCd(),
						export.getFileNm() + "." + export.getFileTypeCd(), dt1.format(export.getSbmtDtm()),
						export.getSttsCd(), export.getExprtId()))
				.collect(Collectors.toList());
	}

	/**
	 * This is to generate the excel for the report
	 * 
	 * @param request
	 * @return
	 */
	public void downloadReportAsExcel(MembershipReportRequest request, UserExportDTO userExport) throws Exception {
		List<ReportHeader> columns = getReportHeader(request);
		Map<String, String> medicalColumMap = new LinkedHashMap<>();
		Map<String, String> pharmacyColumMap = new LinkedHashMap<>();

		// preparing header Columns Map
		for (ReportHeader column : columns) {

			if (ACIISSTConstants.ALL.equalsIgnoreCase(request.getCoverageType())
					&& !(request.getHiddenPharmacyColumns().contains(column.getColDataIndex()))) {
				pharmacyColumMap.put(column.getColDataIndex(), column.getColText());
			}
			if (ACIISSTConstants.ALL.equalsIgnoreCase(request.getCoverageType())
					&& !(request.getHiddenMedicalColumns().contains(column.getColDataIndex()))) {
				medicalColumMap.put(column.getColDataIndex(), column.getColText());
			}
			if (ACIISSTConstants.MEM_RPRT_COV_PHARMACY.equalsIgnoreCase(request.getCoverageType())
					&& !(request.getHiddenPharmacyColumns().contains(column.getColDataIndex()))) {
				pharmacyColumMap.put(column.getColDataIndex(), column.getColText());
			}
			if (ACIISSTConstants.MEM_RPRT_COV_MEDICAL.equalsIgnoreCase(request.getCoverageType())
					&& !(request.getHiddenMedicalColumns().contains(column.getColDataIndex()))) {
				medicalColumMap.put(column.getColDataIndex(), column.getColText());
			}

		}
		Map<String, List<Map<String, String>>> resultList = getMembershipReportDataForDownload(request);
		Map<String, String> globalFilter = globalFilter(request);
		AccountDTO account = accountDao.findAccount(request.getAccountId());
		populateAccountStructureFilters(globalFilter, request,account);

		excelExpoterAspose.reportExtractor(resultList, medicalColumMap, pharmacyColumMap, request, globalFilter,
				userExport,account.getAccountName());

		userExport.setSttsCd(ACIISSTConstants.COMPLETED);
		userExport.setErrTxt("Download completed successfully");

		userExportDAO.updateUserExport(userExport);
	}

	/**
	 * This is to generate the pdf for the report
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public void downloadReportAsPdf(MembershipReportRequest request, UserExportDTO userExport) throws Exception {
		List<ReportHeader> columns = getReportHeader(request);
		Map<String, String> medicalColumMap = new LinkedHashMap<>();
		Map<String, String> pharmacyColumMap = new LinkedHashMap<>();
		// preparing header Columns Map
		for (ReportHeader column : columns) {
			if (ACIISSTConstants.ALL.equalsIgnoreCase(request.getCoverageType())
					&& !(request.getHiddenPharmacyColumns().contains(column.getColDataIndex()))) {
				pharmacyColumMap.put(column.getColDataIndex(), column.getColText());
			}
			if (ACIISSTConstants.ALL.equalsIgnoreCase(request.getCoverageType())
					&& !(request.getHiddenMedicalColumns().contains(column.getColDataIndex()))) {
				medicalColumMap.put(column.getColDataIndex(), column.getColText());
			}
			if (ACIISSTConstants.MEM_RPRT_COV_PHARMACY.equalsIgnoreCase(request.getCoverageType())
					&& !(request.getHiddenPharmacyColumns().contains(column.getColDataIndex()))) {
				pharmacyColumMap.put(column.getColDataIndex(), column.getColText());
			}
			if (ACIISSTConstants.MEM_RPRT_COV_MEDICAL.equalsIgnoreCase(request.getCoverageType())
					&& !(request.getHiddenMedicalColumns().contains(column.getColDataIndex()))) {
				medicalColumMap.put(column.getColDataIndex(), column.getColText());
			}

		}

		Map<String, List<Map<String, String>>> resultList = getMembershipReportDataForDownload(request);
		Map<String, String> globalFilter = globalFilter(request);
		AccountDTO account = accountDao.findAccount(request.getAccountId());
		
		populateAccountStructureFilters(globalFilter, request,account);
		pdfExportService.genratePdf(resultList, medicalColumMap, pharmacyColumMap, request, globalFilter, userExport,account.getAccountName());

		userExport.setSttsCd(ACIISSTConstants.COMPLETED);
		userExport.setErrTxt("Download completed successfully");

		userExportDAO.updateUserExport(userExport);
	}

	/**
	 * This method will prepare result set data to map
	 * 
	 * @param resultset
	 * @param contractTypeMap
	 */
	public void resultDataToMap(List<Object[]> resultset,
			Map<String, Map<String, MembershipReportDTO>> contractTypeMap,List<String> contractType) {

		ListIterator<Object[]> itr = resultset.listIterator();
		while (itr.hasNext()) {
			Object[] data = itr.next();
			MembershipReportDTO reportData = new MembershipReportDTO();
			reportData.setContractType((String) data[0]);
			reportData.setYearMonth((Integer) data[1]);
			reportData.setSubscriberMonthsTotal((Integer) data[2]);
			reportData.setMemberMonthsTotal((Integer) data[3]);
			reportData.setAvgMbrPerCntrct((Integer) data[4]);
			reportData.setMbrAvgAge((Integer) data[5]);
			reportData.setSbscrbrAvgAge((Integer) data[6]);
			// collecting each Contract tier data
			if (reportData.getContractType() != null) {
				
				Map<String, MembershipReportDTO> innerMapReturn = getvalue(reportData, contractTypeMap);
				contractTypeMap.put(reportData.getContractType(), innerMapReturn);
				
			}

		}
		Set<String>keySet=contractTypeMap.keySet();
		List<String> resultCntrTyp=new ArrayList<>();
		for(String key:keySet) {
			resultCntrTyp.add(key.toLowerCase());			
		}
		
		for(String cntctTyp:contractType) {				
			if(!resultCntrTyp.contains(cntctTyp.toLowerCase())) {
				Map<String, MembershipReportDTO> innerMap=new HashMap<>();
				contractTypeMap.put(cntctTyp, innerMap);
			}			
		}
		
	}

	/**
	 * This method will get all contract type for the Contract tier
	 * @param reqContractTier
	 * @return
	 * @throws SQLException 
	 */
	public List<String> prepareContractType(String reqContractTier) throws SQLException {
		
		List<String> tierLevel= new LinkedList<>();
		AppPropertyDTO contrctTypes=null;
		switch(reqContractTier) {
		case ACIISSTConstants.CNTRCT_TIER_2:	  contrctTypes = appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.CNTRCT_TIER_2_TYPES);
									    break;
		case ACIISSTConstants.CNTRCT_TIER_3: contrctTypes =  appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.CNTRCT_TIER_3_TYPES);
										break;							   
		case ACIISSTConstants.CNTRCT_TIER_4_OPA: contrctTypes =  appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.CNTRCT_TIER_4_OPA_TYPES);
										break;
		case ACIISSTConstants.CNTRCT_TIER_4_OPB: contrctTypes =  appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.CNTRCT_TIER_4_OPB_TYPES);
							    	   break;	
		case ACIISSTConstants.CNTRCT_TIER_5: contrctTypes =  appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.CNTRCT_TIER_5_TYPES);
										break;
		default:break;
		
		}
		if (!ObjectUtils.isEmpty(contrctTypes)) {
			tierLevel = Arrays.asList(contrctTypes.getAciisstPrptyValTxt().split("\\|"));			
		}
		
	return 	tierLevel;
	}
	
	
	/**
	 * @param request
	 * @param value
	 * @return
	 * @throws SQLException 
	 */
	public Object getPriorTotal(MembershipReportRequest request, String value) throws SQLException {
		if (request.getPriorPeriod1End() != null && request.getPriorPeriod1Start() != null) {
			request.setCurrentPeriodEnd(request.getPriorPeriod1End());
			request.setCurrentPeriodStart(request.getPriorPeriod1Start());
			List<Object[]> priorTotalList = membershipReportDAO.getMembershiprReportData(request, true, value);
			return priorTotalList.get(0);
		}
		return null;
	}

	/**
	 * @param request
	 * @param forReport
	 * @return
	 */
	public List<Map<String, String>> retrieveReports(MembershipReportRequest request, boolean forReport) {
		try {

		List<Object[]> resultset = membershipReportDAO.getMembershiprReportData(request, false,
				request.getTierLevel());
		// calculating the Month diff
		String reportType = null;
		String prior1Value = null;
		String prior2Value = null;

		DecimalFormat dformat = new DecimalFormat("0.0");

		List<Map<String, String>> respList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(resultset)) {
			logger.info("getMembershipReportDetails  {}", resultset.size());

			// setting report type
			if (ACIISSTConstants.REPORT_TYPE_MEMBERBYMONTH.equals(request.getReportType())) {
				reportType = "Members";
			} else if (ACIISSTConstants.REPORT_TYPE_CONTRACTSBYMONTH.equals(request.getReportType())) {
				reportType = "Contracts";
			}

			// value to show in Tooltip
			if (request.getPriorPeriod1Start() != null && request.getPriorPeriod2Start() != null) {
				prior1Value = "Prior1";
				prior2Value = "Prior2";
			} else if (request.getPriorPeriod1Start() != null && request.getPriorPeriod2Start() == null) {
				prior1Value = "Prior";
			}
			Map<String, Map<String, MembershipReportDTO>> contractTypeMap = new LinkedHashMap<>();
			
			List<String>  contractTypeList = prepareContractType(request.getTierLevel());

			resultDataToMap(resultset, contractTypeMap,contractTypeList);
			//  variables for total row
			BigDecimal avgPrior1ColTotal=BigDecimal.ZERO;
			BigDecimal avgPrior2ColTotal =BigDecimal.ZERO;
			BigDecimal avgCurColTotal =BigDecimal.ZERO;
			BigDecimal trend1ColTotal = BigDecimal.ZERO;
			BigDecimal trend2ColTotal = BigDecimal.ZERO;
			int prior1AvgMbrPerCnrctTotal = 0;
			int prior2AvgMbrPerCnrctTotal = 0;
			int curAvgMbrPerCnrctTotal = 0;
			int prior1AvgAgeTot = 0;
			int prior2AvgAgeTot = 0;
			int curAvgAgeTot = 0;

			BigDecimal totalRowCurAvgPercOfAvg = BigDecimal.ZERO;
			BigDecimal totalRowPr1AvgPercOfAvg = BigDecimal.ZERO;
			BigDecimal totalRowPr2AvgPercOfAvg = BigDecimal.ZERO;

			// only MONTH values header
			List<ReportHeader> headerList = new ArrayList<>();
			getMonthValue(request.getCurrentPeriodStart(), request.getCurrentPeriodEnd(), headerList);
			List<String> header = headerList.stream().map(ReportHeader::getColDataIndex).collect(Collectors.toList());
			Map<String, MembershipReportTotalDTO> colTotal = getColumnTotal(contractTypeMap, request.getReportType());

			// Preparing Response
			// iterating Contact tier data
			Set<String> setv = contractTypeMap.keySet();
			for (String value : setv) {
				int currTimePeriod = AcisstUtil.getDiffMonth(request.getCurrentPeriodStart(),
						request.getCurrentPeriodEnd());
				Map<String, String> responseMap = new LinkedHashMap<>();
				Map<String, MembershipReportDTO> innermap = contractTypeMap.get(value);

				int rowTotal = getRowTotal(contractTypeMap, value, request, innermap, header);
				int tooltip = 01;
				int monthNoValue = 0;
				int avgMemberperContract = 0;
				int sumAvgAge = 0;
				int avgMemPerContr = 0;
				int avgAge = 0;

				BigDecimal avgCurr = BigDecimal.ZERO;
				BigDecimal avgPrior1 = BigDecimal.ZERO;
				BigDecimal avgPrior2 = BigDecimal.ZERO;

				BigDecimal totalPercOfAvgTotal = BigDecimal.ZERO;
				BigDecimal avgPercOfAvgTotal = BigDecimal.ZERO;
				// Contract type
				responseMap.put(ACIISSTConstants.MEM_RPRT_CONTRACT_TYPE, value);
				if (!forReport) {

					responseMap.put(ACIISSTConstants.MEM_RPRT_CONTRACT_TYPE + ACIISSTConstants.REPORT_TOOLTIP, value);
				}

				// iterating Header and adding data
				for (String monthHeader : header) {

					String month = monthHeader.substring(10, monthHeader.length() - 4);
					String year = monthHeader.substring(monthHeader.length() - 4);
					Integer cellValue = null;

					// Adding monthYear values
					if (innermap.containsKey(monthHeader)) {
						if (ACIISSTConstants.REPORT_TYPE_MEMBERBYMONTH.equals(request.getReportType())) {
							cellValue = innermap.get(monthHeader).getMemberMonthsTotal();
							sumAvgAge += innermap.get(monthHeader).getMbrAvgAge();
						} else if (ACIISSTConstants.REPORT_TYPE_CONTRACTSBYMONTH.equals(request.getReportType())) {
							cellValue = innermap.get(monthHeader).getSubscriberMonthsTotal();
							sumAvgAge += innermap.get(monthHeader).getSbscrbrAvgAge();
						}

						responseMap.put(monthHeader, String.valueOf(cellValue));

						avgMemberperContract += innermap.get(monthHeader).getAvgMbrPerCntrct();
						Integer columnTotal = colTotal.get(monthHeader) != null
								? colTotal.get(monthHeader).getMonthValueTotal()
								: 0;
						String tooltipValue = prepareTooltip(month, year, new BigDecimal(columnTotal),
								innermap.get(monthHeader), value, reportType);
						totalPercOfAvgTotal = totalPercOfAvgTotal.add(
								AcisstUtil.bigDecimaldivision(new BigDecimal(cellValue), new BigDecimal(columnTotal))
										.multiply(new BigDecimal(100)));
						if (forReport) {
							responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), tooltipValue);
							tooltip++;
						} else {
							responseMap.put(monthHeader + ACIISSTConstants.REPORT_TOOLTIP, tooltipValue);

						}

					} else {
						// if data not present for the monthYear adding 0
						responseMap.put(monthHeader, "0");
						Integer columnTotal = colTotal.get(monthHeader) != null
								? colTotal.get(monthHeader).getMonthValueTotal()
								: 0;
						String tooltipValue = prepareTooltip(month, year, new BigDecimal(columnTotal), null, value,
								reportType);
						if (forReport) {

							responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), tooltipValue);
							tooltip++;
						} else {

							responseMap.put(monthHeader + ACIISSTConstants.REPORT_TOOLTIP, tooltipValue);
						}
						monthNoValue++;

					}
				}

				// time period calc by subtracting hidden columns
				if (!CollectionUtils.isEmpty(request.getHiddenPharmacyColumns())) {
					for (String hiddenCol : request.getHiddenPharmacyColumns()) {
						if (innermap.get(hiddenCol) != null) {
							currTimePeriod = currTimePeriod - 1;
						}
					}
				} else if (!CollectionUtils.isEmpty(request.getHiddenMedicalColumns())) {
					for (String hiddenCol : request.getHiddenMedicalColumns()) {
						if (innermap.get(hiddenCol) != null) {
							currTimePeriod = currTimePeriod - 1;
						}
					}
				}

				// total/(total months (unhidden columns)-months which as no values in DB)
				int months = currTimePeriod - monthNoValue;
				if(months!=0) {
					
					avgCurr = AcisstUtil.bigDecimaldivision(new BigDecimal(rowTotal), new BigDecimal(months));
					avgMemPerContr = avgMemberperContract / (currTimePeriod - monthNoValue);
					curAvgMbrPerCnrctTotal += avgMemPerContr;
					avgPercOfAvgTotal = AcisstUtil.bigDecimaldivision(totalPercOfAvgTotal, new BigDecimal(months));
					totalRowCurAvgPercOfAvg = totalRowCurAvgPercOfAvg.add(avgPercOfAvgTotal);
					avgAge = sumAvgAge / (currTimePeriod - monthNoValue);
					curAvgAgeTot += avgAge;
				}

				// adding Current avg data to map
				avgCurr = new BigDecimal(dformat.format(avgCurr));
				responseMap.put(ACIISSTConstants.MEM_RPRT_AVG_CUR, String.valueOf(avgCurr));
				String avgCurtooltipValue = prepareTooltipAvg("Current", avgCurr, avgPercOfAvgTotal, reportType,
						avgMemPerContr, avgAge);
				if (forReport) {
					responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), avgCurtooltipValue);
					tooltip++;
				} else {
					responseMap.put(ACIISSTConstants.MEM_RPRT_AVG_CUR + ACIISSTConstants.REPORT_TOOLTIP,
							avgCurtooltipValue);

				}

				// adding Prior period 1 data to map
				if (request.getPriorPeriod1Start() != null) {
					Map<String, MembershipReportDTO> priorMap = priorValues(request.getPriorPeriod1Start(),
							request.getPriorPeriod1End(), contractTypeMap, request);
					int priorAvgMbrPerCnrct = 0;
					int priorAvgAge = 0;
					if (priorMap.containsKey(value)) {
						MembershipReportDTO priorReport = priorMap.get(value);

						avgPrior1 = priorReport.getPriorAvg();
						priorAvgMbrPerCnrct = priorReport.getPriorAvgMbrPerCnrct();
						prior1AvgMbrPerCnrctTotal += priorAvgMbrPerCnrct;
						if (ACIISSTConstants.REPORT_TYPE_MEMBERBYMONTH.equals(request.getReportType())) {
							priorAvgAge = priorReport.getMbrAvgAge();
						} else {
							priorAvgAge = priorReport.getSbscrbrAvgAge();
						}
						prior1AvgAgeTot += priorAvgAge;

					}
					avgPrior1 = new BigDecimal(dformat.format(avgPrior1));
					BigDecimal percOfAvgTotalforPrior = getPercOfAvgTotalforPrior(priorMap, avgPrior1);
					totalRowPr1AvgPercOfAvg = totalRowPr1AvgPercOfAvg.add(percOfAvgTotalforPrior);

					String avgtooltipValue = prepareTooltipAvg(prior1Value, avgPrior1, percOfAvgTotalforPrior,
							reportType, priorAvgMbrPerCnrct, priorAvgAge);
					responseMap.put(ACIISSTConstants.MEM_RPRT_AVG_PRIOR1, String.valueOf(avgPrior1));
					if (forReport) {
						responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), avgtooltipValue);
						tooltip++;
					} else {

						responseMap.put(ACIISSTConstants.MEM_RPRT_AVG_PRIOR1 + ACIISSTConstants.REPORT_TOOLTIP,
								avgtooltipValue);
					}
					// trend using cur total and prior total

					BigDecimal trend1 = AcisstUtil
							.bigDecimaldivision((avgCurr.subtract(avgPrior1)).multiply(new BigDecimal(100)), avgPrior1);

					trend1 = new BigDecimal(dformat.format(trend1));

					responseMap.put(ACIISSTConstants.MEM_RPRT_TREND1, dformat.format(trend1));
					String tooltipValue = prepareTooltipTrend(
							prior2Value != null ? "Current to Prior1" : "Current to Prior", dformat.format(trend1));
					if (forReport) {

						responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), tooltipValue);
						tooltip++;
					} else {
						responseMap.put(ACIISSTConstants.MEM_RPRT_TREND1 + ACIISSTConstants.REPORT_TOOLTIP,
								tooltipValue);

					}
					trend1ColTotal = trend1ColTotal.add(trend1);
				}
				// adding Prior period 2 data to map
				if (request.getPriorPeriod2Start() != null) {
					Map<String, MembershipReportDTO> priorMap = priorValues(request.getPriorPeriod2Start(),
							request.getPriorPeriod2End(), contractTypeMap, request);

					int priorAvgMbrPerCnrct = 0;
					int priorAvgAge = 0;
					if (priorMap.containsKey(value)) {
						MembershipReportDTO priorReport = priorMap.get(value);

						avgPrior2 = priorReport.getPriorAvg();
						priorAvgMbrPerCnrct = priorReport.getPriorAvgMbrPerCnrct();
						prior2AvgMbrPerCnrctTotal += priorAvgMbrPerCnrct;
						if (ACIISSTConstants.REPORT_TYPE_MEMBERBYMONTH.equals(request.getReportType())) {
							priorAvgAge = priorReport.getMbrAvgAge();
						} else {
							priorAvgAge = priorReport.getSbscrbrAvgAge();
						}
						prior2AvgAgeTot += priorAvgAge;

					}

					avgPrior2 = new BigDecimal(dformat.format(avgPrior2));
					responseMap.put(ACIISSTConstants.MEM_RPRT_AVG_PRIOR2, String.valueOf(avgPrior2));
					BigDecimal percOfAvgTotalforPrior = getPercOfAvgTotalforPrior(priorMap, avgPrior2);
					totalRowPr2AvgPercOfAvg = totalRowPr2AvgPercOfAvg.add(percOfAvgTotalforPrior);

					String tooltipValue = prepareTooltipAvg(prior2Value, avgPrior2, percOfAvgTotalforPrior, reportType,
							priorAvgMbrPerCnrct, priorAvgAge);
					if (forReport) {
						responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), tooltipValue);
						tooltip++;
					} else {
						responseMap.put(ACIISSTConstants.MEM_RPRT_AVG_PRIOR2 + ACIISSTConstants.REPORT_TOOLTIP,
								tooltipValue);

					}

					// trend cal using avgprior1 and avgprior2

					BigDecimal trend2 = AcisstUtil.bigDecimaldivision(
							(avgPrior1.subtract(avgPrior2)).multiply(new BigDecimal(100)), avgPrior2);
					trend2 = new BigDecimal(dformat.format(trend2));
					responseMap.put(ACIISSTConstants.MEM_RPRT_TREND2, dformat.format(trend2));
					String trendTooltip = prepareTooltipTrend("Prior1 to Prior2", dformat.format(trend2));
					if (forReport) {
						responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), trendTooltip);
					} else {
						responseMap.put(ACIISSTConstants.MEM_RPRT_TREND2 + ACIISSTConstants.REPORT_TOOLTIP,
								trendTooltip);

					}
					trend2ColTotal = trend2ColTotal.add(trend2);
				}

				respList.add(responseMap);

				// For Columnwise total/Total row data calculation
				avgPrior1ColTotal = avgPrior1ColTotal.add(avgPrior1);
				avgPrior2ColTotal = avgPrior2ColTotal.add(avgPrior2);
				avgCurColTotal = avgCurColTotal.add(avgCurr);

			}
			// data for total row
			if (setv != null && !CollectionUtils.isEmpty(setv)) {

				prior1AvgAgeTot = prior1AvgAgeTot / setv.size();
				prior2AvgAgeTot = prior1AvgAgeTot / setv.size();
				curAvgAgeTot = curAvgAgeTot / setv.size();
				totalRowPr1AvgPercOfAvg = AcisstUtil.bigDecimaldivision(totalRowPr1AvgPercOfAvg,
						new BigDecimal(setv.size()));
				totalRowPr2AvgPercOfAvg = AcisstUtil.bigDecimaldivision(totalRowPr2AvgPercOfAvg,
						new BigDecimal(setv.size()));

			}
			// Total row data
			if (!CollectionUtils.isEmpty(respList)) {
				int tooltip = 1;

				Map<String, String> responseMap = new LinkedHashMap<>();
				// adding contract type
				responseMap.put(ACIISSTConstants.MEM_RPRT_CONTRACT_TYPE, ACIISSTConstants.TOTAL);
				if (!forReport) {
					responseMap.put(ACIISSTConstants.MEM_RPRT_CONTRACT_TYPE + ACIISSTConstants.REPORT_TOOLTIP,
							ACIISSTConstants.TOTAL);
				}
				// adding months total
				for (String monthHeader : header) {
					String month = monthHeader.substring(10, monthHeader.length() - 4);
					String year = monthHeader.substring(monthHeader.length() - 4);
					if (colTotal.containsKey(monthHeader)) {

						responseMap.put(monthHeader, String.valueOf(colTotal.get(monthHeader).getMonthValueTotal()));
						String monthTooltip = prepareTooltip(month, year, monthHeader, colTotal.get(monthHeader),
								ACIISSTConstants.TOTAL, reportType);
						if (forReport) {

							responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), monthTooltip);
							tooltip++;
						} else {
							responseMap.put(monthHeader + ACIISSTConstants.REPORT_TOOLTIP, monthTooltip);
						}

					} else {

						responseMap.put(monthHeader, "0");
						String monthTooltip = prepareTooltip(month, year, monthHeader, colTotal.get(monthHeader),
								ACIISSTConstants.TOTAL, reportType);
						if (forReport) {

							responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), monthTooltip);
							tooltip++;
						} else {
							responseMap.put(monthHeader + ACIISSTConstants.REPORT_TOOLTIP, monthTooltip);
						}
					}
				}
				// adding current avg for total row

				responseMap.put(ACIISSTConstants.MEM_RPRT_AVG_CUR, String.valueOf(avgCurColTotal));
				String curAvgTooltip = prepareTooltipAvg("Current", avgCurColTotal, totalRowCurAvgPercOfAvg, reportType,
						curAvgMbrPerCnrctTotal, curAvgAgeTot);
				if (forReport) {
					responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), curAvgTooltip);
					tooltip++;
				} else {
					responseMap.put(ACIISSTConstants.MEM_RPRT_AVG_CUR + ACIISSTConstants.REPORT_TOOLTIP, curAvgTooltip);
				}

				if (respList.get(0).containsKey(ACIISSTConstants.MEM_RPRT_AVG_PRIOR1)) {
					// adding avg prior 1 for total row
					responseMap.put(ACIISSTConstants.MEM_RPRT_AVG_PRIOR1, String.valueOf(avgPrior1ColTotal));
					String avgPrTooltip = prepareTooltipAvg(prior1Value, avgPrior1ColTotal, totalRowPr1AvgPercOfAvg,
							reportType, prior1AvgMbrPerCnrctTotal, prior1AvgAgeTot);
					if (forReport) {
						responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), avgPrTooltip);
						tooltip++;
					} else {
						responseMap.put(ACIISSTConstants.MEM_RPRT_AVG_PRIOR1 + ACIISSTConstants.REPORT_TOOLTIP,
								avgPrTooltip);
					}
					// adding trend1 for total
					responseMap.put(ACIISSTConstants.MEM_RPRT_TREND1, dformat.format(trend1ColTotal));
					String trend1Tooltip = prepareTooltipTrend(
							prior2Value != null ? "Current to Prior1" : "Current to Prior",
							dformat.format(trend1ColTotal));
					if (forReport) {
						responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), trend1Tooltip);
						tooltip++;
					} else {
						responseMap.put(ACIISSTConstants.MEM_RPRT_TREND1 + ACIISSTConstants.REPORT_TOOLTIP,
								trend1Tooltip);
					}
				}
				if (respList.get(0).containsKey(ACIISSTConstants.MEM_RPRT_AVG_PRIOR2)) {
					// adding avg prior2 for total row
					responseMap.put(ACIISSTConstants.MEM_RPRT_AVG_PRIOR2, String.valueOf(avgPrior2ColTotal));
					String avgTooltip = prepareTooltipAvg(prior2Value, avgPrior2ColTotal, totalRowPr2AvgPercOfAvg,
							reportType, prior2AvgMbrPerCnrctTotal, prior2AvgAgeTot);
					if (forReport) {
						responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), avgTooltip);
						tooltip++;
					} else {
						responseMap.put(ACIISSTConstants.MEM_RPRT_AVG_PRIOR2 + ACIISSTConstants.REPORT_TOOLTIP,
								avgTooltip);
					}
					// adding trend2
					responseMap.put(ACIISSTConstants.MEM_RPRT_TREND2, dformat.format(trend2ColTotal));
					String trend2Tooltip = prepareTooltipTrend("Prior1 to Prior2", dformat.format(trend2ColTotal));
					if (forReport) {
						responseMap.put(ACIISSTConstants.UI_TOOLTIP + String.format("%02d", tooltip), trend2Tooltip);
					} else {
						responseMap.put(ACIISSTConstants.MEM_RPRT_TREND2 + ACIISSTConstants.REPORT_TOOLTIP,
								trend2Tooltip);
					}
				}
				respList.add(responseMap);

			}
		}
		
		return respList;
		}catch(Exception e) {
			logger.error("Exception :  {}",e);
		}
		return Collections.emptyList();
		
	}

	/**
	 * method to get the Prior total , avgMemPerCnrtct and avg age
	 * 
	 * @param startDate
	 * @param endDate
	 * @param contractTypeMap
	 * @return
	 */
	public Map<String, MembershipReportDTO> priorValues(String startDate, String endDate,
			Map<String, Map<String, MembershipReportDTO>> contractTypeMap, MembershipReportRequest request) {
		Map<String, MembershipReportDTO> priorMap = new LinkedHashMap<>();
		int currTimePeriod = AcisstUtil.getDiffMonth(startDate, endDate);
		String currStart = startDate;
		String month = currStart.length() > 2 ? currStart.substring(currStart.length() - 2) : currStart;
		String yearstr = currStart.length() > 4 ? currStart.substring(0, currStart.length() - 2) : currStart;

		Set<String> contractTypeSet = contractTypeMap.keySet();
		for (String contractType : contractTypeSet) {
			int tempCurrTimePeriod = currTimePeriod;
			int tempMon = Integer.parseInt(month);
			int tempYer = Integer.parseInt(yearstr);
			Map<String, MembershipReportDTO> monthValues = contractTypeMap.get(contractType);
			long priorRowTotal = 0;
			int prioravgMemPerCnrtct = 0;
			int sumMemAvgAge = 0;
			int sumsubscriberAvgAge = 0;
			int timePeriodToAvg = currTimePeriod;

			while (tempCurrTimePeriod != 0) {
				if (tempMon > 12) {
					tempMon = 01;
					tempYer++;

				}
				String key = ACIISSTConstants.MEM_RPRT_MONTH_KEY + String.format("%02d", tempMon) + tempYer;
				if (monthValues.containsKey(key)) {
					MembershipReportDTO reportData = monthValues.get(key);
					if (ACIISSTConstants.REPORT_TYPE_MEMBERBYMONTH.equals(request.getReportType())) {
						priorRowTotal += reportData.getMemberMonthsTotal();
					} else {

						priorRowTotal += reportData.getSubscriberMonthsTotal();
					}
					prioravgMemPerCnrtct += reportData.getAvgMbrPerCntrct();
					sumsubscriberAvgAge += reportData.getSbscrbrAvgAge();
					sumMemAvgAge += reportData.getMbrAvgAge();
				} else {
					timePeriodToAvg--;
				}
				tempMon++;
				tempCurrTimePeriod--;
			}
			MembershipReportDTO priorDto = new MembershipReportDTO();
			if (currTimePeriod != 0) {
				// timePeriodToAvg is used so that if monthYear dont have any data in DB we will
				// not consider that month
				if (timePeriodToAvg != 0) {
					priorDto.setPriorAvgMbrPerCnrct(prioravgMemPerCnrtct / timePeriodToAvg);
					priorDto.setSbscrbrAvgAge(sumsubscriberAvgAge / timePeriodToAvg);
					priorDto.setMbrAvgAge(sumMemAvgAge / timePeriodToAvg);
				}
			} else {
				priorDto.setPriorAvgMbrPerCnrct(prioravgMemPerCnrtct);
				priorDto.setSbscrbrAvgAge(sumsubscriberAvgAge);
				priorDto.setMbrAvgAge(sumMemAvgAge);
				priorDto.setPriorTotal(priorRowTotal);
			}
			priorDto.setPriorTotal(priorRowTotal);
			if (timePeriodToAvg != 0) {
				BigDecimal prioravg = AcisstUtil.bigDecimaldivision(BigDecimal.valueOf(priorRowTotal),
						new BigDecimal(timePeriodToAvg));
				DecimalFormat dformat = new DecimalFormat("0.0");
				prioravg = new BigDecimal(dformat.format(prioravg));

				priorDto.setPriorAvg(prioravg);
			} else {
				priorDto.setPriorAvg(new BigDecimal(priorRowTotal));
			}

			priorMap.put(contractType, priorDto);
		}

		return priorMap;

	}

	/**
	 * common code to get data to download
	 * 
	 * @param request
	 * @return
	 */
	public Map<String, List<Map<String, String>>> getMembershipReportDataForDownload(MembershipReportRequest request) {
		Map<String, List<Map<String, String>>> resultMap = new LinkedHashMap<>();
		List<List<Map<String, String>>> coverageTypeList = new ArrayList<>();
		if (ACIISSTConstants.ALL.equalsIgnoreCase(request.getCoverageType())) {
			request.setCoverageType(ACIISSTConstants.MEM_RPRT_COV_MEDICAL);
			List<Map<String, String>> reportData = getReportDetails(request, false);
			resultMap.put(ACIISSTConstants.MEM_RPRT_COV_MEDICAL, reportData);
			coverageTypeList.add(reportData);
			request.setCoverageType(ACIISSTConstants.MEM_RPRT_COV_PHARMACY);
			List<Map<String, String>> pharmacyReportData = getReportDetails(request, false);
			resultMap.put(ACIISSTConstants.MEM_RPRT_COV_PHARMACY, pharmacyReportData);
			coverageTypeList.add(pharmacyReportData);
		} else {
			request.setCoverageType(request.getCoverageType());
			List<Map<String, String>> reportData = getReportDetails(request, false);
			resultMap.put(request.getCoverageType(), reportData);
			coverageTypeList.add(reportData);

		}
		return resultMap;
	}

	/**
	 * Common method to get the required filters from DB
	 * 
	 * @param accountId
	 * @param sessionKey
	 * @param userId
	 * @param requiredFilter
	 * @return
	 */
	/*public List<String> getAccountStructureFilterForExport(String accountId, String sessionKey, String userId,
			String requiredFilter) {
		User user = userRepository.getUserDetails(userId);
		List<Object[]> accountStructureFilters = accountRepository.getAccountStructureFiltersForExport(accountId,
				sessionKey, user.getUserId(), requiredFilter);
		List<String> responseList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(accountStructureFilters)) {
			ListIterator<Object[]> itr = accountStructureFilters.listIterator();
			while (itr.hasNext()) {
				Object[] filterObj = itr.next();
				if (!StringUtils.isEmpty((String) filterObj[1]))
					responseList.add((String) filterObj[1]);
			}
		}
		return responseList;
	}*/

	/**
	 * Methos to get home page Filters for Export
	 * 
	 * @param globalFilters
	 * @param request
	 */
	private void populateAccountStructureFilters(Map<String, String> globalFilters, MembershipReportRequest request,AccountDTO account) {
	
		
		
		AccountStructureDisplayValueDTO structuredFilterDisplayValues = request.getStructuredFilterDisplayValues();
		if (structuredFilterDisplayValues != null) {
			globalFilters.put("Group ID",
					ACIISSTConstants.EMPTY_BLANK_STRING.equals(structuredFilterDisplayValues.getGroups())
							? ACIISSTConstants.ALL_SELECTED
							: structuredFilterDisplayValues.getGroups());
			globalFilters.put("Subgroup",
					ACIISSTConstants.EMPTY_BLANK_STRING.equals(structuredFilterDisplayValues.getSubGroups())
							? ACIISSTConstants.ALL_SELECTED
							: structuredFilterDisplayValues.getSubGroups());
			if(account.getRptgDsplyRlup1Cd().equalsIgnoreCase("Y")) {
				globalFilters.put(!StringUtils.isEmpty(account.getSubgrpRptg1LblCd())
						? account.getSubgrpRptg1LblCd() : ACIISSTConstants.SUBGRPRPTG1LBLCD1,
						ACIISSTConstants.EMPTY_BLANK_STRING.equals(structuredFilterDisplayValues.getSubGroupRollup1())
						? ACIISSTConstants.ALL_SELECTED
								: structuredFilterDisplayValues.getSubGroupRollup1());
			}
			if(account.getRptgDsplyRlup2Cd().equalsIgnoreCase("Y")) {
				globalFilters.put(!StringUtils.isEmpty(account.getSubgrpRptg2LblCd())
						? account.getSubgrpRptg2LblCd() : ACIISSTConstants.SUBGRPRPTG1LBLCD2,
						ACIISSTConstants.EMPTY_BLANK_STRING.equals(structuredFilterDisplayValues.getSubGroupRollup2())
						? ACIISSTConstants.ALL_SELECTED
								: structuredFilterDisplayValues.getSubGroupRollup2());
			}
			if(account.getRptgDsplyRlup3Cd().equalsIgnoreCase("Y")) {
				globalFilters.put(!StringUtils.isEmpty(account.getSubgrpRptg3LblCd())
						? account.getSubgrpRptg3LblCd() : ACIISSTConstants.SUBGRPRPTG1LBLCD3,
						ACIISSTConstants.EMPTY_BLANK_STRING.equals(structuredFilterDisplayValues.getSubGroupRollup3())
						? ACIISSTConstants.ALL_SELECTED
								: structuredFilterDisplayValues.getSubGroupRollup3());
			}
			if(account.getRptgDsplyRlup4Cd().equalsIgnoreCase("Y")) {
				globalFilters.put(!StringUtils.isEmpty(account.getSubgrpRptg4LblCd())
						? account.getSubgrpRptg4LblCd() : ACIISSTConstants.SUBGRPRPTG1LBLCD4,
						ACIISSTConstants.EMPTY_BLANK_STRING.equals(structuredFilterDisplayValues.getSubGroupRollup4())
								? ACIISSTConstants.ALL_SELECTED
								: structuredFilterDisplayValues.getSubGroupRollup4());
				}
			globalFilters.put("Plan",
					ACIISSTConstants.EMPTY_BLANK_STRING.equals(structuredFilterDisplayValues.getPackages())
							? ACIISSTConstants.ALL_SELECTED
							: structuredFilterDisplayValues.getPackages());
			if(account.getRptgDsplySttsCd().equalsIgnoreCase("Y")) {
				globalFilters.put("Status",
						ACIISSTConstants.EMPTY_BLANK_STRING.equals(structuredFilterDisplayValues.getStatus())
						? ACIISSTConstants.ALL_SELECTED
								: structuredFilterDisplayValues.getStatus());				
			}
			globalFilters.put("Product",
					ACIISSTConstants.EMPTY_BLANK_STRING.equals(structuredFilterDisplayValues.getProducts())
					? ACIISSTConstants.ALL_SELECTED
							: structuredFilterDisplayValues.getProducts());
			if(account.getRptgDsplyDeptInd().equalsIgnoreCase("Y")) {
				globalFilters.put("Department",
						ACIISSTConstants.EMPTY_BLANK_STRING.equals(structuredFilterDisplayValues.getDepartments())
						? ACIISSTConstants.ALL_SELECTED
								: structuredFilterDisplayValues.getDepartments());				
			}
			if(account.getRptgDsplyGrpRptg1Cd().equalsIgnoreCase("Y")) {
				globalFilters.put(!StringUtils.isEmpty(account.getGrpRptg1LblCd())
						? account.getGrpRptg1LblCd() : ACIISSTConstants.GROUPRPTG1LABELCODE,
						ACIISSTConstants.EMPTY_BLANK_STRING.equals(
								structuredFilterDisplayValues.getEmployerGroupReporting1()) ? ACIISSTConstants.ALL_SELECTED
										: structuredFilterDisplayValues.getEmployerGroupReporting1());
			}
			if(account.getRptgDsplyGrpRptg2Cd().equalsIgnoreCase("Y")) {
				globalFilters.put(!StringUtils.isEmpty(account.getGrpRptg2LblCd())
						? account.getGrpRptg2LblCd() : ACIISSTConstants.GROUPRPTG2LABELCODE,
						ACIISSTConstants.EMPTY_BLANK_STRING.equals(
								structuredFilterDisplayValues.getEmployerGroupReporting2()) ? ACIISSTConstants.ALL_SELECTED
										: structuredFilterDisplayValues.getEmployerGroupReporting2());
			}
			if(account.getRptgDsplyGrpRptg3Cd().equalsIgnoreCase("Y")) {
				globalFilters.put(!StringUtils.isEmpty(account.getGrpRptg3LblCd())
						? account.getGrpRptg3LblCd() : ACIISSTConstants.GROUPRPTG3LABELCODE,
						ACIISSTConstants.EMPTY_BLANK_STRING.equals(
								structuredFilterDisplayValues.getEmployerGroupReporting3()) ? ACIISSTConstants.ALL_SELECTED
										: structuredFilterDisplayValues.getEmployerGroupReporting3());
			}
		
		}
	}

}
