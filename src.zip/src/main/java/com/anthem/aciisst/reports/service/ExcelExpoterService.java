package com.anthem.aciisst.reports.service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.anthem.aciisst.account.web.view.response.AccountStructureDisplayValueDTO;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.persistence.dto.UserExportDTO;
import com.anthem.aciisst.reports.web.view.request.MembershipReportRequest;
import com.aspose.cells.AutoFitterOptions;
import com.aspose.cells.BackgroundType;
import com.aspose.cells.Border;
import com.aspose.cells.BorderType;
import com.aspose.cells.Cell;
import com.aspose.cells.CellBorderType;
import com.aspose.cells.Cells;
import com.aspose.cells.Color;
import com.aspose.cells.Comment;
import com.aspose.cells.CommentCollection;
import com.aspose.cells.FileFormatType;
import com.aspose.cells.Font;
import com.aspose.cells.License;
import com.aspose.cells.Style;
import com.aspose.cells.TextAlignmentType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;

@Service
public class ExcelExpoterService {

	@Autowired
	ExportFileHelper exportHelper;
	
	

	public String reportExtractor(Map<String, List<Map<String, String>>> reportData, Map<String, String> medicalHeader,
			Map<String, String> pharmacyHeader, MembershipReportRequest req, Map<String, String> globalFilters,
			UserExportDTO userExport,String accountName) throws Exception {
		int row = 0;
		int filterSheetRow = 0;
		License license = new License();
		if (!License.isLicenseSet()) {
			ClassPathResource cpr = new ClassPathResource("Aspose.Cells.lic");

			license.setLicense(cpr.getInputStream());
		}
		Workbook wb = new Workbook();

		Worksheet worksheet = wb.getWorksheets().get(0);
		worksheet.setName("Membership Reports");
		Cells cells = worksheet.getCells();

		addingLogo(worksheet, row);
		//right header
		addHeader(worksheet, req,accountName);

		// Report type
		row = row + 7;
		Cell c = cells.get(row, 0);
		c.setValue(req.getReportType());
		cells.merge(row, 0, 1, 12);
		cells.setRowHeight(row, 22);
		Style style = c.getStyle();
		Font font = style.getFont();
		font.setName("Times New Roman");
		font.setSize(14);
		font.setBold(true);
		c.setStyle(style);

		// Table
		row = row + 2;
		row = createReportTable(worksheet, reportData, medicalHeader, pharmacyHeader, req, row);

		// Report Run Cell
		row = row + 4;	
		addReportRunDate(worksheet, row);

		// Global Filters Sheet
		globalFilterSheet(wb, globalFilters, req, filterSheetRow,accountName);

		worksheet.autoFitColumns();
		Date d = new Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		df.format(d);

		ByteArrayOutputStream ms = new ByteArrayOutputStream();
		wb.save(ms, FileFormatType.DEFAULT);
		byte[] b = ms.toByteArray();
		
		return exportHelper.writeFile(b, userExport.getExprtId(), ACIISSTConstants.EXCEL_XTN); 

	}

	public void addReportRunDate(Worksheet worksheet, int row) {
		Cells cells = worksheet.getCells();
		cells.merge(row, 0, 18, 15);
		Cell copyRightCell = cells.get(row, 0);
		Style style = copyRightCell.getStyle();
		style.setVerticalAlignment(row);
		style.setTextWrapped(true);
		copyRightCell.setStyle(style);
		copyRightCell.setValue(ACIISSTConstants.REPORT_COPY_RIGHT);
		AutoFitterOptions options = new AutoFitterOptions();
		options.setAutoFitMergedCells(true);
		try {
			worksheet.autoFitRows(options);
		} catch (Exception e) {
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId( ACIISSTConstants.NA);
			logDetail.setUserId( ACIISSTConstants.NA);
			logDetail.setUri("addReportRunDate()");
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}
		row = row + 22;
		Cell reportRunCell = cells.get(row, 0);
		SimpleDateFormat dt1 = new SimpleDateFormat("MM/dd/yyyy");
		reportRunCell.setValue("Report Run Date :" + dt1.format(new Date()));
		cells.merge(row, 0, 1, 4);
	}

	public void addHeader(Worksheet worksheet, MembershipReportRequest req,String accountName) {
		Cells cells = worksheet.getCells();
		Cell accountIdCell = cells.get(0, 12);
		accountIdCell.setValue("Account Name: " + accountName);
		cells.merge(0, 12, 1, 4);
		Cell curDateCell = cells.get(1, 12);

		AccountStructureDisplayValueDTO structuredFilterDisplayValues = req.getStructuredFilterDisplayValues();
		if(structuredFilterDisplayValues !=null) {
			curDateCell.setValue("Current Period: " + structuredFilterDisplayValues.getCurrentPeriodStart() + " - " + structuredFilterDisplayValues.getCurrentPeriodEnd());
			cells.merge(1, 12, 1, 4);
			if(StringUtils.isEmpty(structuredFilterDisplayValues.getPriorPeriod2Start()) && !StringUtils.isEmpty(structuredFilterDisplayValues.getPriorPeriod1Start())){
				Cell prior1DateCell = cells.get(2, 12);
				prior1DateCell.setValue("Prior Period: " + structuredFilterDisplayValues.getPriorPeriod1Start() + " - " + structuredFilterDisplayValues.getPriorPeriod1End());
				cells.merge(2, 12, 1, 4);
			}
			else if(!StringUtils.isEmpty(structuredFilterDisplayValues.getPriorPeriod2Start()) && !StringUtils.isEmpty(structuredFilterDisplayValues.getPriorPeriod1Start())){
				Cell prior1DateCell = cells.get(2, 12);
				prior1DateCell.setValue("Prior Period 1: " + structuredFilterDisplayValues.getPriorPeriod1Start() + " - " + structuredFilterDisplayValues.getPriorPeriod1End());
				cells.merge(2, 12, 1, 4);
				Cell prior2DateCell = cells.get(3, 12);
				prior2DateCell.setValue("Prior Period 2: " + structuredFilterDisplayValues.getPriorPeriod2Start() + " - " + structuredFilterDisplayValues.getPriorPeriod2End());
				cells.merge(3, 12, 1, 4);
			}
		}
	}

	public void globalFilterSheet(Workbook wb, Map<String, String> globalFilters, MembershipReportRequest req,
			int filterSheetRow,String accountName) throws Exception {
		Worksheet worksheet = wb.getWorksheets().add("Filters Applied");
		Cells cells = worksheet.getCells();
		addingLogo(worksheet, filterSheetRow);

		addHeader(worksheet, req,accountName);

		cells.setColumnWidthInch(0, 2);
		cells.setColumnWidthInch(1, 8);
		filterSheetRow = filterSheetRow + 8;
		setGlobalFiltersHeader(worksheet, filterSheetRow);
		filterSheetRow++;

		filterSheetRow = setGlobalFiltersContent(worksheet, globalFilters, filterSheetRow);
		worksheet.autoFitColumns();
		addReportRunDate(worksheet, filterSheetRow + 4);

	}

	public int setGlobalFiltersContent(Worksheet worksheet, Map<String, String> globalFilter, int filterSheetRow) {

		Set<Entry<String, String>> globalFilters = globalFilter.entrySet();
		for (Map.Entry<String, String> reports : globalFilters) {
			Cells cells = worksheet.getCells();
			Cell fiters = cells.get(filterSheetRow, 0);
			fiters.setValue(reports.getKey());
			setBoarder(fiters);

			Cell fitersValue = cells.get(filterSheetRow, 1);
			Style style = fitersValue.getStyle();
			style.setTextWrapped(true);
			fitersValue.setStyle(style);
			fitersValue.setValue(reports.getValue());
			setBoarder(fitersValue);
			filterSheetRow++;
		}
		return filterSheetRow;
	}

	public void setGlobalFiltersHeader(Worksheet worksheet, int filterSheetRow) {
		Cells cells = worksheet.getCells();
		cells.setRowHeight(filterSheetRow, 28);

		Cell fiters = cells.get(filterSheetRow, 0);
		fiters.setValue("Fiter Name");
		Style style = tableHeaderStyle(fiters);
		fiters.setStyle(style);
		setBoarder(fiters);

		Cell fitersValue = cells.get(filterSheetRow, 1);
		fitersValue.setValue("Fiter Value");
		Style valueStyle = tableHeaderStyle(fitersValue);
		fitersValue.setStyle(valueStyle);
		setBoarder(fitersValue);

	}

	public int createReportTable(Worksheet worksheet, Map<String, List<Map<String, String>>> reportDataList,
			Map<String, String> medicalHeader, Map<String, String> pharmacyHeader, MembershipReportRequest req,
			int row) {

		Set<String> reportDataSet = reportDataList.keySet();
		Cells cells = worksheet.getCells();
		for (String reportDataKey : reportDataSet) {
			if (ACIISSTConstants.MEM_RPRT_COV_MEDICAL.equalsIgnoreCase(reportDataKey)) {
				// Coverage Type

				Cell contractTierCell = createCustomCell(worksheet.getCells().getCell(row, 0));
				cells.merge(row, 0, 1, medicalHeader.size());
				// Row height
				cells.setRowHeight(row, 22);
				contractTierCell.setValue(ACIISSTConstants.MEM_RPRT_COV_MEDICAL);
				setBoarder(contractTierCell);

				// Table Header
				row = row + 1;
				createTableHeader(worksheet, medicalHeader, req.getMedicalColumnSequence(), row);
				// Header row Height
				cells.setRowHeight(row, 27);

				// Table Content
				row = row + 1;
				for (Map<String, String> rData : reportDataList.get(reportDataKey)) {
					cells.setRowHeight(row, 23);
					createTableContent(worksheet, row, rData, medicalHeader, req.getMedicalColumnSequence());
					row++;
				}
			} else {
				if (ACIISSTConstants.MEM_RPRT_COV_PHARMACY.equalsIgnoreCase(reportDataKey)) {
					// Coverage Type
					cells.merge(row, 0, 1, pharmacyHeader.size());
					Cell contractTierCell = createCustomCell(worksheet.getCells().getCell(row, 0));
					cells.setRowHeight(row, 22);
					contractTierCell.setValue(ACIISSTConstants.MEM_RPRT_COV_PHARMACY);
					setBoarder(contractTierCell);

					// Table Header
					row = row + 1;
					createTableHeader(worksheet, pharmacyHeader, req.getPharmacyColumnSequence(), row);
					// Header row Height
					cells.setRowHeight(row, 27);

					// Table content
					row = row + 1;
					for (Map<String, String> rData : reportDataList.get(reportDataKey)) {
						cells.setRowHeight(row, 23);
						createTableContent(worksheet, row, rData, pharmacyHeader, req.getPharmacyColumnSequence());
						row++;
					}
				}
			}
			row = row + 3;
		}
		return row;

	}

	public void createTableHeader(Worksheet worksheet, Map<String, String> colHeader, List<String> seqCol, int row) {

		Cell c;

		int col = 0;
		if (CollectionUtils.isEmpty(seqCol)) {

			for (Map.Entry<String, String> entry : colHeader.entrySet()) {
				c = worksheet.getCells().get(row, col);

				c.setValue(entry.getValue());
				Style style = tableHeaderStyle(c);
				c.setStyle(style);
				setBoarder(c);

				col++;
			}
		} else {
			for (String column : seqCol) {
				c = worksheet.getCells().get(row, col);

				c.setValue(colHeader.get(column));
				Style style = tableHeaderStyle(c);
				c.setStyle(style);
				setBoarder(c);

				col++;
			}
		}

	}

	public void createTableContent(Worksheet worksheet, int row, Map<String, String> data, Map<String, String> col,
			List<String> seqCol) {

		Cell c;
		int colu = 0;
		CommentCollection comm = worksheet.getComments();

		if (CollectionUtils.isEmpty(seqCol)) {

			Set<String> colSet = col.keySet();

			for (String column : colSet) {
				if (data.get(column) != null) {

					c = worksheet.getCells().get(row, colu);
					c.setValue(data.get(column));
				} else {
					c = worksheet.getCells().get(row, colu);
					c.setValue(0);
				}
				int commentIndex = worksheet.getComments().add(row, colu);
				Comment comment = comm.get(commentIndex);
				comment.setAutoSize(true);
				comment.setNote(data.get(column + "_tooltip"));
				setBoarder(c);
				colu++;
			}
		} else {
			for (String seqColumn : seqCol) {
				if (data.get(seqColumn) != null) {

					c = worksheet.getCells().get(row, colu);
					c.setValue(data.get(seqColumn));
				} else {
					c = worksheet.getCells().get(row, colu);
					c.setValue(0);
				}
				setBoarder(c);
				int commentIndex = worksheet.getComments().add(row, colu);
				Comment comment = comm.get(commentIndex);
				comment.setAutoSize(true);
				comment.setNote(data.get(seqColumn + "_tooltip"));
				colu++;

			}
		}

	}

	public Style tableHeaderStyle(Cell c) {
		Style style = c.getStyle();
		Font font = style.getFont();
		font.setName("Arial");
		font.setSize(12);
		font.setBold(true);
		font.setColor(com.aspose.cells.Color.getWhite());
		style.setForegroundColor(Color.fromArgb(0, 102, 255));
		style.setPattern(BackgroundType.SOLID);
		style.setVerticalAlignment(TextAlignmentType.CENTER);

		return style;
	}

	public void setBoarder(Cell c) {
		Style style = c.getStyle();
		Border bootomBorder = style.getBorders().getByBorderType(BorderType.BOTTOM_BORDER);
		bootomBorder.setLineStyle(CellBorderType.THIN);
		bootomBorder.setColor(Color.getBlack());
		Border topBorder = style.getBorders().getByBorderType(BorderType.TOP_BORDER);
		topBorder.setLineStyle(CellBorderType.THIN);
		topBorder.setColor(Color.getBlack());
		Border leftBorder = style.getBorders().getByBorderType(BorderType.LEFT_BORDER);
		leftBorder.setLineStyle(CellBorderType.THIN);
		leftBorder.setColor(Color.getBlack());
		Border rightBorder = style.getBorders().getByBorderType(BorderType.RIGHT_BORDER);
		rightBorder.setLineStyle(CellBorderType.THIN);
		rightBorder.setColor(Color.getBlack());
		c.setStyle(style);

	}

	public Cell createCustomCell(Cell c) {

		Style style = c.getStyle();
		Font font = style.getFont();
		font.setName("Times New Roman");
		font.setSize(14);
		font.setBold(true);
		font.setColor(com.aspose.cells.Color.getWhite());
		style.setForegroundColor(Color.fromArgb(0, 102, 255));
		style.setPattern(BackgroundType.SOLID);
		style.setHorizontalAlignment(TextAlignmentType.CENTER);
		c.setStyle(style);
		setBoarder(c);
		return c;
	}

	public void addingLogo(Worksheet worksheet, int row) {
		try {
			ClassPathResource cpr = new ClassPathResource("./image/logo.png");
			try( InputStream targetStream = cpr.getInputStream()){
				worksheet.getPictures().add(row, 0, targetStream);
			}
		} catch (Exception e) {
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId( ACIISSTConstants.NA);
			logDetail.setUserId( ACIISSTConstants.NA);
			logDetail.setUri("ExcelExpoterService.addingLogo");
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		} 
		

	

	}

}
