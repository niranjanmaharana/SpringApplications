package com.anthem.aciisst.reports.web.view.response;

public class UserExportResponseView{
	
	private String type;
	private String name;
	private String date;
	private String status;
	private String exportId;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getExportId() {
		return exportId;
	}
	public void setExportId(String exportId) {
		this.exportId = exportId;
	}
	public UserExportResponseView(String type, String name, String date, String status, String exportId) {
		super();
		this.type = type;
		this.name = name;
		this.date = date;
		this.status = status;
		this.exportId = exportId;
	}
	

}
