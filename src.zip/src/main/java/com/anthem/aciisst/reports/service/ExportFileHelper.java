package com.anthem.aciisst.reports.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.persistence.dto.UserExportDTO;

@Component
public class ExportFileHelper {

	@Value("${export.path}")
	private String exportPath;

	/**
	 * This metod will write the file (Excel/Pdf) in specified location
	 * 
	 * @param dataByte
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	public String writeFile(byte[] dataByte, String fileName, String fileType) throws IOException {

		String path = exportPath + getPhysicalFileName(fileName, fileType);

		try (FileOutputStream out = new FileOutputStream(path)) {
			out.write(dataByte);
			out.flush();
		} catch (IOException e) {
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(ACIISSTConstants.NA);
			logDetail.setUserId(ACIISSTConstants.NA);
			logDetail.setUri("writeFile()");
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(), logDetail, e);
			throw new IOException(e);
		}

		return ACIISSTConstants.COMPLETED;
	}

	/**
	 * @param userExport
	 * @param response
	 * @return
	 * @throws IOException
	 */
	public boolean readFile(UserExportDTO userExport, HttpServletResponse response) throws IOException {
		boolean status = false;
		//Checking if file already downloaded
		if (userExport!=null && "COMPLETED".equalsIgnoreCase(userExport.getSttsCd())) {
			String path = exportPath + getPhysicalFileName(userExport.getExprtId(), userExport.getFileTypeCd());
			String fileNmae = userExport.getFileNm().trim() + "." + userExport.getFileTypeCd().trim();
			byte[] bytes = new byte[4096];
			response.setHeader("Content-Disposition",
					"attachment; filename=\"" + fileNmae.replace('\n', '_').replace('\r', '_') + "\"");

			if (userExport.getFileTypeCd().trim().equalsIgnoreCase(ACIISSTConstants.PDF)) {
				response.setHeader("Content-Type", ACIISSTConstants.PDF_MEDIA_TYPE);
			} else if (userExport.getFileTypeCd().trim().equalsIgnoreCase(ACIISSTConstants.EXCEL_XTN)) {
				response.setHeader("Content-Type", ACIISSTConstants.EXCEL_MEDIA_TYPE);
			}

			File file = null;
			ServletOutputStream os = null;
			file = new File(path);
			os = response.getOutputStream();

			try (InputStream is = new FileInputStream(file)) {
				int c = 0;

				while ((c = is.read(bytes, 0, bytes.length)) > 0) {
					os.write(bytes, 0, c);
					os.flush();
				}
				os.close();

				status = true;
			}

		}

		return status;
	}

	/**
	 * @param path
	 * @throws IOException
	 */
	// Delete the file after download
	public void cleanUp(Path path) throws IOException {
		Files.delete(path);
	}

	public String getPhysicalFileName(String exportId, String fileType) {

		/*
		 * Parse physical file name to ensure expected format.
		 */
		Pattern p = Pattern.compile("(^[a-zA-Z0-9_-]{1,})(\\.)(xlsx|xls|pdf|txt)$");
		Matcher m = p.matcher(exportId + "." + fileType);
		m.find();

		return m.group(1) + m.group(2) + m.group(3);
	}
}
