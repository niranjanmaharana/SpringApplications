package com.anthem.aciisst.reports.service;

import java.io.ByteArrayOutputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.anthem.aciisst.account.web.view.response.AccountStructureDisplayValueDTO;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.persistence.dto.UserExportDTO;
import com.anthem.aciisst.reports.web.view.request.MembershipReportRequest;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.RectangleReadOnly;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

/**
 * @author AF72803
 *
 */
@Service
public class PdfExporterService {
	
	@Autowired
	ExportFileHelper exportHelper;
	

	private static Font disclaimerFont = new Font(Font.FontFamily.HELVETICA, 6, Font.NORMAL);
	private static Font colorBoldfont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, new BaseColor(85, 148, 212));
	private static Font boldFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
	private static float eachCellWidth = 72; 

	/**
	 * This method is to generate pdf
	 * 
	 * @param reportDataList
	 * @param medicalColumMap
	 * @param pharmacyColumMap
	 * @param request
	 * @param globalFilter
	 * @return
	 * @throws Exception 
	 */
	public String genratePdf(Map<String, java.util.List<Map<String, String>>> reportDataList,
			Map<String, String> medicalColumMap, Map<String, String> pharmacyColumMap, MembershipReportRequest request,
			Map<String, String> globalFilter,UserExportDTO userExport,String accountName) throws Exception { 
		ByteArrayOutputStream out = new ByteArrayOutputStream();
			float tableWidth = ((medicalColumMap.size() >= pharmacyColumMap.size()) ? medicalColumMap.size()
					: pharmacyColumMap.size()) * eachCellWidth;
			float pageWidth = 595;//default A$ width
			pageWidth = (tableWidth+(36*2)) >= pageWidth ? tableWidth+(36*2) : pageWidth;
			ReportPdfLayout headerEvent = new ReportPdfLayout();
			Paragraph rightTopHeaderPara = new Paragraph();
			Phrase phrase = new Phrase("Account Name: "+accountName,colorBoldfont);
			AccountStructureDisplayValueDTO structuredFilterDisplayValues = request.getStructuredFilterDisplayValues();
			if(structuredFilterDisplayValues !=null) {
				Phrase phrase2 = new Phrase("\nCurrent Period: "+structuredFilterDisplayValues.getCurrentPeriodStart() +" - "+structuredFilterDisplayValues.getCurrentPeriodEnd(),boldFont);
				if(StringUtils.isEmpty(structuredFilterDisplayValues.getPriorPeriod2Start()) && !StringUtils.isEmpty(structuredFilterDisplayValues.getPriorPeriod1Start())){
					phrase2.add(new Phrase("\nPrior Period: "+structuredFilterDisplayValues.getPriorPeriod1Start() +" - "+structuredFilterDisplayValues.getPriorPeriod1End(),boldFont));
				}
				else if(!StringUtils.isEmpty(structuredFilterDisplayValues.getPriorPeriod2Start()) && !StringUtils.isEmpty(structuredFilterDisplayValues.getPriorPeriod1Start())){
					phrase2.add(new Phrase("\nPrior Period 1: "+structuredFilterDisplayValues.getPriorPeriod1Start() +" - "+structuredFilterDisplayValues.getPriorPeriod1End(),boldFont));
					phrase2.add(new Phrase("\nPrior Period 2: "+structuredFilterDisplayValues.getPriorPeriod2Start() +" - "+structuredFilterDisplayValues.getPriorPeriod2End(),boldFont));
				}
				rightTopHeaderPara.add(phrase);
				rightTopHeaderPara.add(phrase2);
				headerEvent.setRightHeader(rightTopHeaderPara);
				
			}
			
			Document document = new Document(new RectangleReadOnly(pageWidth,842), 36, 36, 56, 36);
			PdfWriter writer = PdfWriter.getInstance(document, out);
			writer.setPageEvent(headerEvent);
			document.open();
			addMetaData(document);
			Paragraph preface = new Paragraph();
			// We add one empty line
			addEmptyLine(preface, 2);
			preface.add(new Paragraph(request.getReportType(), boldFont));
			document.add(preface);

			Set<String> reportDataSet = reportDataList.keySet();
			for (String reportDataKey : reportDataSet) {				
				if (ACIISSTConstants.MEM_RPRT_COV_MEDICAL.equalsIgnoreCase(reportDataKey)) {
					request.setCoverageType(ACIISSTConstants.MEM_RPRT_COV_MEDICAL);
					addContent(document, request, reportDataList.get(reportDataKey), medicalColumMap, request.getMedicalColumnSequence());
				} else if (ACIISSTConstants.MEM_RPRT_COV_PHARMACY.equalsIgnoreCase(reportDataKey)) {
					request.setCoverageType(ACIISSTConstants.MEM_RPRT_COV_PHARMACY);
					addContent(document, request, reportDataList.get(reportDataKey), pharmacyColumMap, request.getPharmacyColumnSequence());
				}

			}
			Paragraph pre = new Paragraph();
			// We add one empty line
			addEmptyLine(pre, 1);

			pre.add(new Paragraph("Filters Applied", boldFont));

			document.add(pre);

			createFilterTable(document, globalFilter);

			Paragraph pre1 = new Paragraph();
			// We add one empty line
			addEmptyLine(pre1, 1);
			pre1.add(new Paragraph(ACIISSTConstants.REPORT_COPY_RIGHT,disclaimerFont ));
			document.add(pre1);
			document.close();
			return exportHelper.writeFile(out.toByteArray(), userExport.getExprtId(), ACIISSTConstants.PDF); 
	}

	/**
	 * to add metadata to the PDF which can be viewed in your Adobe
	 * 
	 * @param document
	 */
	private static void addMetaData(Document document) {
		document.addTitle("Aciisst Report");
		document.addSubject("Reports");
		document.addKeywords("Java, PDF, iText");

	}

	/**
	 * Method to addd the Content in the PDF
	 * 
	 * @param document
	 * @param request
	 * @param reportData
	 * @param columMap
	 * @throws DocumentException
	 */
	private static void addContent(Document document, MembershipReportRequest request,
			java.util.List<Map<String, String>> reportData, Map<String, String> columMap, List<String> columnSequence) throws DocumentException {

		// add a table
			
			createTable(document, reportData, columMap, columnSequence,request.getCoverageType());

	}

	/**
	 * Creating the Table and adding the table content
	 * 
	 * @param subCatPart
	 * @param reportData
	 * @param columMap
	 * @param seqCol
	 * @param pageWidth 
	 * @throws DocumentException
	 */
	private static void createTable(Document subCatPart, java.util.List<Map<String, String>> reportData,
			Map<String, String> columMap, List<String> seqCol, String coverageType) throws DocumentException {

		Paragraph para2 = new Paragraph();
		addEmptyLine(para2, 1);
		para2.add(new Paragraph(""));
		subCatPart.add(para2);
		Set<String> header = columMap.keySet();

		if (!CollectionUtils.isEmpty(header)) {
			PdfPTable table = new PdfPTable(header.size());
			table.setTotalWidth(eachCellWidth * header.size());
			table.setWidthPercentage(100);
			table.addCell(createTableHeaderCell(coverageType,header.size()));
			if (CollectionUtils.isEmpty(seqCol)) {

				for (String col : header) {
					table.addCell(createHeaderCell(columMap.get(col)));
				}
			} else {
				for (String col : seqCol) {
					table.addCell(createHeaderCell(columMap.get(col)));
				}
			}

			table.setHeaderRows(1);
			for (Map<String, String> reports : reportData) {
				List<String>colList= new LinkedList();
				colList.addAll(header);

				if (CollectionUtils.isEmpty(seqCol)) {
					table.addCell(createDetailCell(reports.get(colList.get(0))));
					for (int i=1;i<colList.size();i++) {
						table.addCell(createLabelCell(reports.get(colList.get(i))));
					}
				} else {
					table.addCell(createDetailCell(reports.get(seqCol.get(0))));
					for (int i=1;i<seqCol.size();i++) {
						table.addCell(createLabelCell(reports.get(seqCol.get(i))));
					}
				}
			}
			subCatPart.add(table);
		}

	}

	/**
	 * This method is to create the Filter Table
	 * 
	 * @param subCatPart
	 * @param globalFilter
	 * @throws DocumentException
	 */
	private static void createFilterTable(Document subCatPart, Map<String, String> globalFilter)
			throws DocumentException {

		Paragraph para2 = new Paragraph();
		addEmptyLine(para2, 1);
		para2.add(new Paragraph(""));
		subCatPart.add(para2);
		float[] columnWidths = new float[]{300, 700};
		PdfPTable table = new PdfPTable(columnWidths);
		table.setWidthPercentage(100);

		table.setHeaderRows(1);

		Set<Entry<String, String>> globalFilters = globalFilter.entrySet();
		table.addCell(createHeaderCell("Filter Name"));
		table.addCell(createHeaderCell("Filter Value"));
		for (Map.Entry<String, String> reports : globalFilters) {

			table.addCell(createDetailCell(reports.getKey()));
			table.addCell(createDetailCell(reports.getValue()));

		}

		subCatPart.add(table);

	}

	/**
	 * Method to create the Header Cells for the table
	 * 
	 * @param text
	 * @return
	 */
	private static PdfPCell createHeaderCell(String text) {
		// font
		Font font = new Font(Font.FontFamily.TIMES_ROMAN, 9, Font.BOLD, BaseColor.WHITE);

		// create cell
		PdfPCell cell = new PdfPCell(new Phrase(text, font));

		// set style
		headerCellStyle(cell);

		return cell;
	}
	
	/**
	 * Method to create the Table header for the table
	 * 
	 * @param text
	 * @return
	 */
	private static PdfPCell createTableHeaderCell(String text, int columnSize) {
		// font
		Font font = new Font(Font.FontFamily.TIMES_ROMAN, 11, Font.BOLD, BaseColor.WHITE);

		// create cell
		PdfPCell cell = new PdfPCell(new Phrase(text, font));
		cell.setColspan(columnSize);
		// set style
		headerCellStyle(cell);

		return cell;
	}

	/**
	 * Header cell style is defined
	 * 
	 * @param cell
	 */
	public static void headerCellStyle(PdfPCell cell) {
		// alignment
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);

		// padding
		cell.setPaddingLeft(3f);
		cell.setPaddingTop(0f);

		// background color
		cell.setBackgroundColor(new BaseColor(85, 148, 212));

		// border
		cell.setBorder(Rectangle.BOX);

		// height
		cell.setMinimumHeight(22f);
	}

	/**
	 * Method to create lable cell and style
	 * 
	 * @param text
	 * @return
	 */
	private static PdfPCell createLabelCell(String text) {
		// font
		Font font = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.NORMAL);

		// create cell
		PdfPCell cell = new PdfPCell(new Phrase(text, font));

		// set style
		labelCellStyle(cell);

		return cell;
	}
		
	/**
	 * Method to create detail cell and style
	 * 
	 * @param text
	 * @return
	 */
	private static PdfPCell createDetailCell(String text) {
		// font
		Font font = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.NORMAL);

		// create cell
		PdfPCell cell = new PdfPCell(new Phrase(text, font));

		// set style
		
			labelleftCellStyle(cell);

		return cell;
	}
	/**
	 * This is common method to defining the lable style
	 * 
	 * @param cell
	 */
	public static void labelCellStyle(PdfPCell cell) {
		// alignment
		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);

		// padding
		cell.setPaddingLeft(3f);
		cell.setPaddingTop(0f);

		// height
		cell.setMinimumHeight(18f);
	}
	
	public static void labelleftCellStyle(PdfPCell cell) {
		// alignment
		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);

		// padding
		cell.setPaddingLeft(3f);
		cell.setPaddingTop(0f);

		// height
		cell.setMinimumHeight(18f);
	}

	/**
	 * This is a common method to create the empty line
	 * 
	 * @param paragraph
	 * @param number
	 */
	private static void addEmptyLine(Paragraph paragraph, int number) {
		for (int i = 0; i < number; i++) {
			paragraph.add(new Paragraph(" "));
		}
	}

}