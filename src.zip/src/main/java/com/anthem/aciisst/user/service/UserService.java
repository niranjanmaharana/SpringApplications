package com.anthem.aciisst.user.service;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anthem.aciisst.persistence.dao.AciisstUserCategoryDAO;
import com.anthem.aciisst.persistence.dao.AciisstUserRolesDAO;
import com.anthem.aciisst.persistence.dao.UserDAO;
import com.anthem.aciisst.persistence.dto.AciisstRoleDTO;
import com.anthem.aciisst.persistence.dto.AciisstUserCtgryDTO;
import com.anthem.aciisst.persistence.dto.User;
import com.anthem.aciisst.user.dto.UserDTO;
import com.anthem.aciisst.user.web.view.response.UserResponse;

@Service
public class UserService {

	@Autowired
	UserDAO userDAO;
	@Autowired
	AciisstUserCategoryDAO userCategoryDao;

	@Autowired
	AciisstUserRolesDAO aciisstUserRolesDAO;

	private static final Logger logger = LoggerFactory.getLogger(UserService.class);

	public boolean validateUser(String smUserId) throws SQLException {
		User user = userDAO.findByLognUserId(smUserId);
		if (null != user && user.getLognUserId().equalsIgnoreCase(smUserId)) {
			logger.debug("User FirstName: {} lastName: {}", user.getFirstNm(), user.getLastNm());
			return true;
		}

		return false;
	}

	public boolean validateActiveUser(String smUserId) throws SQLException {

		User user = userDAO.findActiveUserByLognUserId(smUserId);
		if (null != user && user.getLognUserId().equalsIgnoreCase(smUserId)) {
			logger.debug("User FirstName: {} lastName: {}", user.getFirstNm(), user.getLastNm());
			return true;
		}

		return false;
	}

	public UserResponse getUserDetails(String smUserId) throws SQLException {
		UserResponse userDetails = null;
		User user = userDAO.findByLognUserId(smUserId);
		if (user != null) {
			userDetails = new UserResponse();
			userDetails.setFname(user.getFirstNm());
			userDetails.setLname(user.getLastNm());
			userDetails.setUserId(user.getUserId());
			userDetails.setuserCategoryCd(user.getUserCategoryCd().trim());
		}

		return userDetails;

	}

	public UserDTO getUserInfo(String logonUserId) throws SQLException {
		UserDTO userDetails = null;
		User user = userDAO.findByLognUserId(logonUserId);
		if (user != null) {
			AciisstUserCtgryDTO userCtgry = userCategoryDao.getUserCategory(user.getUserTypeCd());
			userDetails = new UserDTO();
			userDetails.setFirstName(user.getFirstNm());
			userDetails.setLastName(user.getLastNm());
			userDetails.setUserIdInt(user.getUserId());
			userDetails.setEmailAddress(user.getEmailId());
			userDetails.setUserCategory(userCtgry.getUserCtgryDesc().trim());
			List<AciisstRoleDTO> userRoles = aciisstUserRolesDAO.getUserRoles(user.getUserId());
			for (AciisstRoleDTO role : userRoles) {
				if (role != null) {
					userDetails.getUserRoles().add(role.getRoleNm());
				}
			}
		}

		return userDetails;

	}

	public String getUniqueId() {
		return UUID.randomUUID().toString();
	}

}
