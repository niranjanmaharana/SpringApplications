package com.anthem.aciisst.user.dto;

import java.util.ArrayList;
import java.util.List;

public class UserDTO {
	
	private String logonUserId;
	private int userIdInt;
	private String firstName;
	private String lastName;
	private String emailAddress;
	private String userCategory;
	private String sessionId;
	private List<String> userRoles = new ArrayList<>();
	
	public int getUserIdInt() {
		return userIdInt;
	}

	public void setUserIdInt(int userIdInt) {
		this.userIdInt = userIdInt;
	}

	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getLogonUserId() {
		return logonUserId;
	}

	public void setLogonUserId(String logonUserId) {
		this.logonUserId = logonUserId;
	}

	public String getUserCategory() {
		return userCategory;
	}

	public void setUserCategory(String userCategory) {
		this.userCategory = userCategory;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public List<String> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(List<String> userRoles) {
		this.userRoles = userRoles;
	}
	
}
