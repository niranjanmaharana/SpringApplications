package com.anthem.aciisst.user.web.view.response;

public class UserResponse {

	private int userId;

	public UserResponse() {

	}

	public UserResponse(int userId, String fname, String lname, String userCategoryCd) {
		super();
		this.userId = userId;
		this.fname = fname;
		this.lname = lname;
		this.userCategoryCd = userCategoryCd;
	}

	private String fname;
	private String lname;
	private String userCategoryCd;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getuserCategoryCd() {
		return userCategoryCd;
	}

	public void setuserCategoryCd(String userCategoryCd) {
		this.userCategoryCd = userCategoryCd;
	}

}
