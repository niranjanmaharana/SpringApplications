package com.anthem.aciisst.user.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.common.web.view.ResponseView;
import com.anthem.aciisst.user.service.UserService;
import com.anthem.aciisst.user.web.view.response.UserResponse;

@CrossOrigin
@RestController
@RequestMapping("user")
public class UserController {

	@Autowired
	UserService userService;

	@RequestMapping(method = RequestMethod.GET, value = "/details")
	public ResponseView<UserResponse> getUserAccounts(@RequestParam("SM_USER_ID") String smUserId, HttpServletRequest httpRequest) {
		UserResponse user = null;
		ResponseView<UserResponse> responseView = new ResponseView<>();
		try {
			user = userService.getUserDetails(smUserId);
			responseView.setData(user);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(ACIISSTConstants.NA);
			logDetail.setUserId( smUserId);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}

		return responseView;
	}

}
