package com.anthem.aciisst.common.constants;

public enum Status {
	PUBLISHED("PUBLISHED"),
	PENDING("PENDING"),
	RETIRED("RETIRED");
	
	public static Status fromString(String title) {
		if(title == null) {
			return null;
		}
		
		if(title.equalsIgnoreCase("APPROVED")) {
			return Status.PUBLISHED;
		}
		
		for(Status status: Status.values()) {
			if(status.getTitle().equalsIgnoreCase(title)) {
				return status;
			}
		}
		
		return null;
	}
	
	private String title;
	
	private Status(String title) {
		this.title = title;
	}
	
	public boolean checkEquals(Status status) {
		return this.getTitle().equalsIgnoreCase(status.getTitle());
	}
	
	
	@Override
	public String toString() {
		return this.title;
	}
	
	public String getTitle() {
		return this.title;
	}
}
