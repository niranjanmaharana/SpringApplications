package com.anthem.aciisst.common.util;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.anthem.aciisst.account.web.view.response.AccountStructureFilterResponseView;
import com.anthem.aciisst.account.web.view.response.KeyValueResponse;
import com.anthem.aciisst.filter.web.view.response.BenchmarkResponse;

public class StringUtil {

	private StringUtil() {

	}

	public static String buildPlaceholdersFromCommaSeparatedList(String list) {
		if (StringUtils.isEmpty(list)) {
			return "";
		} else if (list.contains(",")) {
			StringBuilder placeholders = new StringBuilder("");
			String[] array = list.split(",");
			for (int i = 0; i < array.length; i++) {
				placeholders.append(",?");
			}
			placeholders = placeholders.replace(0, 1, "");
			return placeholders.toString();
		}
		return "?";
	}

	public static String buildCommaSeperatedStringFromList(List<String> stringList) {

		StringBuilder strBuilder = new StringBuilder("");
		if (!CollectionUtils.isEmpty(stringList)) {

			for (String str : stringList) {
				strBuilder.append(str).append(",");
			}
		}
		return strBuilder.length() > 2 ? strBuilder.substring(0, strBuilder.length() - 1) : strBuilder.toString();

	}

	public static String buildCommaSpaceSeperatedStringFromList(List<String> stringList) {

		StringBuilder strBuilder = new StringBuilder("");
		if (!CollectionUtils.isEmpty(stringList)) {

			for (String str : stringList) {
				strBuilder.append(str).append(",").append(" ");
			}
		}
		return strBuilder.length() > 2 ? strBuilder.substring(0, strBuilder.length() - 2) : strBuilder.toString();

	}

	public static List<KeyValueResponse> setKeyValuesForFilters(List<String> dataList) {
		// To generate Key value response from List<String> in format All|All,
		// 1-17|1-17, 18-26|18-26
		List<KeyValueResponse> data = new ArrayList<>();
		if (!CollectionUtils.isEmpty(dataList)) {
			ListIterator<String> itr = dataList.listIterator();
			while (itr.hasNext()) {
				KeyValueResponse value = new KeyValueResponse();
				String filter = itr.next();
				String[] filterValues = filter.split("\\|");
				// Adding length condition as 2(key-index[0] and value-
				// index[1])
				if (!ObjectUtils.isEmpty(filterValues) && filterValues.length == 2) {
					value.setKey(filterValues[0]);
					value.setValue(filterValues[1]);
				}
				data.add(value);
			}
		}
		return data;

	}
	
	public static BenchmarkResponse prepareBenchmark(String value) {
		BenchmarkResponse resp= new BenchmarkResponse();
		if(value!=null) {
			String[] filterValues = value.split("\\|");
			if (!ObjectUtils.isEmpty(filterValues) && filterValues.length == 2) {
				resp.setCode(filterValues[0]);
				resp.setDescription(filterValues[1]);
			}
			
		}	
		
		return resp;
		
		
	}
	
	public static List<AccountStructureFilterResponseView> setCodeDescValuesForFilters(List<String> dataList) {
		// To generate Key value response from List<String> in format All|All,
		// 1-17|1-17, 18-26|18-26
		List<AccountStructureFilterResponseView> data = new ArrayList<>();
		if (!CollectionUtils.isEmpty(dataList)) {
			ListIterator<String> itr = dataList.listIterator();
			while (itr.hasNext()) {
				AccountStructureFilterResponseView value = new AccountStructureFilterResponseView();
				String filter = itr.next();
				String[] filterValues = filter.split("\\|");
				// Adding length condition as 2(key-index[0] and value-
				// index[1])
				if (!ObjectUtils.isEmpty(filterValues) && filterValues.length == 2) {
					value.setCode(filterValues[0]);
					value.setDescription(filterValues[1]);
				}
				data.add(value);
			}
		}
		return data;

	}
}
