package com.anthem.aciisst.common.util;

import java.sql.Timestamp;
import java.util.Calendar;

public class DateUtil {

	private DateUtil(){
		
	}
	
	public static Timestamp getCurrentTimestamp(){
		Calendar calendar = Calendar.getInstance();
		Timestamp currentTimestamp = new Timestamp(calendar.getTime().getTime());
		
		return currentTimestamp;
	}
	
	public static Timestamp getHighEndDate(){
		Timestamp highEndDate = new java.sql.Timestamp(218342543400000L);
		
		return highEndDate;
	}
}
