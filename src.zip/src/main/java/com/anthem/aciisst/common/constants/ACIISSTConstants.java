package com.anthem.aciisst.common.constants;

public class ACIISSTConstants {
	public static final int DEFAULT_EXPORT_THREAD_POOL_SIZE = 3;
	public static final String PDF = "pdf";
	public static final String EXCEL = "excel";
	public static final String EXCEL_XTN = "xls";
	public static final String EXCEL_MEDIA_TYPE = "application/vnd.ms-excel";
	public static final String PDF_MEDIA_TYPE = "application/pdf";
	public static final String RECEIPT_READ = "read";
	public static final String RECEIPT_UNREAD = "unread";
	public static final String RESPONSE_SUCCESS = "Success";
	public static final String RESPONSE_SUCCESS_DESCP = "Success Completed";
	public static final String RESPONSE_FAILURE = "Failure";
	public static final String EXTERNAL_USER = "2";
	public static final String INTERNAL_USER = "1";
	public static final String USER_ID = "USER_ID";
	public static final String USER_NAME = "USER_NAME";
	public static final String ACCOUNT_ID = "accountid";
	public static final String ACCOUNT_NAME = "accountname";
	public static final String RECENTLY_ACCESSED = "R";
	public static final String ALL_ACCOUNT = "A";
	public static final String TRUE_FLAG = "Y";
	public static final String FALSE_FLAG = "N";

	public static final String ALL = "ALL";
	public static final String EMPTY_BLANK_STRING = "";
	public static final String SEGMENT_KEYS = "segmentKeys";
	public static final String SAVE_FILTERS = "save";
	public static final boolean FALSE = false;
	public static final String NA = "NA";
	public static final CharSequence SUBGROUPROOLUP_FILTER = "subGroupRollup";
	public static final String EMPLOYERGROUPREPORTING_FILTER = "employerGroupReporting";
	public static final String NA_0 = "NA_0";
	public static final String CONTRACT_TIER_FAMILY = "Family";
	public static final String CONTRACT_TIER_SUBSCRIBER = "Subscriber";
	public static final String CONTRACT_TIER_SUBSCRIBER_CHILD = "Subscriber + Child";
	public static final String CONTRACT_TIER_SUBSCRIBER_CHILDREN = "Subscriber + Children";
	public static final String CONTRACT_TIER_SUBSCRIBER_SPOUSE = "Subscriber + Spouse";
	public static final String CONTRACT_TIER_SUBSCRIBER_DEPENDENT = "Subscriber + 1 Dependent";
	public static final String GROUP = "group";
	public static final String SUBGROUP = "subgroup";
	public static final String PRODUCT = "product";
	public static final String PACKAGE = "package";
	public static final String STATUS = "status";
	public static final String DEPARTMENT = "department";
	public static final String SUBGROUPROLLUP1 = "subGroupRollup1";
	public static final String SUBGROUPROLLUP2 = "subGroupRollup2";
	public static final String SUBGROUPROLLUP3 = "subGroupRollup3";
	public static final String SUBGROUPROLLUP4 = "subGroupRollup4";
	public static final String EMPLOYERGROUPREPORTING1 = "employerGroupReporting1";
	public static final String EMPLOYERGROUPREPORTING2 = "employerGroupReporting2";
	public static final String EMPLOYERGROUPREPORTING3 = "employerGroupReporting3";
	public static final String EMPLOYERGROUPREPORTING = "employerGroupReporting";
	public static final String HEALTH_STATUS_CRITICAL = "Critical";
	public static final String HEALTH_STATUS_RISK = "At Risk";
	public static final String HEALTH_STATUS_HEALTHY = "Healthy";
	public static final String HEALTH_STATUS_CHRONIC = "Chronic";
	public static final String GENDER_MALE = "male";
	public static final String GENDER_FEMALE = "female";
	public static final String SUBGRPRPTG1LBLCD1 = "Subgroup Rollup 1";
	public static final String SUBGRPRPTG1LBLCD2 = "Subgroup Rollup 2";
	public static final String SUBGRPRPTG1LBLCD3 = "Subgroup Rollup 3";
	public static final String SUBGRPRPTG1LBLCD4 = "Subgroup Rollup 4";
	public static final String GROUPRPTG1LABELCODE = "Group Reporting 1";
	public static final String GROUPRPTG2LABELCODE = "Group Reporting 2";
	public static final String GROUPRPTG3LABELCODE = "Group Reporting 3";
	public static final String ROLLING3TYPE = "r3m";
	public static final String ROLLING12TYPE = "r12m";
	public static final String CYTD = "cytd";
	public static final String PYTD = "pytd";

	public static final String MEM_RPRT_CONTRACT_TYPE = "contractType";
	public static final String MEM_RPRT_AVG_CUR = "averageCurrent";
	public static final String MEM_RPRT_AVG_PRIOR1 = "averagePrior";
	public static final String MEM_RPRT_AVG_PRIOR2 = "averagePrior2";
	public static final String MEM_RPRT_TOTAL_PRIOR1 = "totalPrior";
	public static final String MEM_RPRT_TOTAL_PRIOR2 = "totalPrior2";
	public static final String MEM_RPRT_TREND1 = "trend1";
	public static final String MEM_RPRT_TREND2 = "trend2";
	public static final String MEM_RPRT_COV_MEDICAL = "Medical";
	public static final String MEM_RPRT_COV_PHARMACY = "Pharmacy";
	public static final String KPI_TOTAL_PMPM = "Total Cost PMPM";
	public static final String KPI_CLINICAL = "Risk Score";
	public static final String KPI_DOWN_SYMBOL = "down";
	public static final String KPI_UP_SYMBOL = "up";

	public static final String REPORT_TOOLTIP = "_tooltip";
	public static final String UI_TOOLTIP = "tooltip";
	public static final String TOTAL = "Total";

	public static final String UNIQUE_CHAR = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	public static final String SYSTEM = "ACIISST";

	public static final String SUBGRPRLUP_STATUS = "subGrpRlupStts";

	public static final String MEM_RPRT_MONTH_KEY = "MonthValue";
	public static final String MEM_RPRT_VALUE = "Value";
	public static final String ALL_CAMELCASE = "All";

	public static final String PENDING = "PENDING";
	public static final String ERROR = "ERROR";
	public static final String COMPLETED = "COMPLETED";
	public static final String RETRIEVED = "RETRIEVED";
	
	public static final String JOIN=" JOIN ";
	
	public static final String REPORT_TYPE_MEMBERBYMONTH ="MemberByMonth";
	public static final String REPORT_TYPE_CONTRACTSBYMONTH ="ContractsByMonth";
	
	public static final String HCC_FILTER = "hccfilter";
	public static final String HEALTHSTATUS_FILTER = "healthstatusfilter";
	public static final String RELATIONSHIP_FILTER = "relationshipfilter";
	public static final String ENGAGEMENT_FILTER = "engagementfilter";
	public static final String GENDER_FILTER = "genderfilter";
	public static final String COVERAGE_FILTER = "coveragefilter";
	
	public static final String MBRSHP_BENCHMARK1 = "defaultMbrshpBenchmark1Filter";
	public static final String MBRSHP_SMALL_ACCT_BENCHMARK = "defaultMbrshpBenchmark1SGFilter";
	
	public static final String CLINICAL_BENCHMARK1 = "defaultClinicalBenchmark1filter";
	public static final String CLINICAL_SMALL_ACCT_BENCHMARK = "defaultClinicalBenchmark1SGFilter";
	
	public static final String REPORT_COPY_RIGHT = "Anthem Blue Cross and Blue Shield is the trade name of: In Colorado: Rocky Mountain Hospital and Medical Service, Inc. HMO products underwritten by HMO Colorado, Inc. In Connecticut: Anthem Health Plans, Inc. In Georgia: Blue Cross and Blue Shield of Georgia, Inc. In Indiana: Anthem Insurance Companies, Inc. In Kentucky: Anthem Health Plans of Kentucky, Inc. In Maine: Anthem Health Plans of Maine, Inc. In Missouri (excluding 30 counties in the Kansas City area): RightCHOICEÂ® Managed Care, Inc. (RIT), Healthy AllianceÂ® Life Insurance Company (HALIC), and HMO Missouri, Inc. RIT and certain affiliates administer non-HMO benefits underwritten by HALIC and HMO benefits underwritten by HMO Missouri, Inc. RIT and certain affiliates only provide administrative services for self-funded plans and do not underwrite benefits. In Nevada: Rocky Mountain Hospital and Medical Service, Inc."
			+ "HMO products underwritten by HMO Colorado, Inc., dba HMO Nevada. In New Hampshire: Anthem Health Plans of New Hampshire, Inc. Anthem Health Plans of New Hampshire, Inc. HMO plans are administered by Anthem Health Plans of New Hampshire, Inc. and underwritten by Matthew Thornton Health Plan, Inc. In Ohio: Community Insurance Company. "
			+ "In Virginia Anthem Health Plans of Virginia, Inc. trades as Anthem Blue Cross and Blue Shield in Virginia, and its service area is all of Virginia except for the City of Fairfax, the Town of Vienna, and the area east of State Route 123. In Wisconsin: Blue Cross Blue Shield of Wisconsin (\"BCBSWi\") underwrites or administers PPO and indemnity policies and underwrites the out of network benefits in POS policies offered by Compcare Health Services Insurance Corporation (\"Compcare\") or Wisconsin Collaborative Insurance Company (\"WCIC\"); Compcare underwrites or administers HMO or POS policies; WCIC underwrites or administers Well Priority HMO or POS policies.  Independent licensees of the Blue Cross and Blue Shield Association. ANTHEM is a registered trademark of Anthem Insurance Companies, Inc. The Blue Cross and Blue Shield names and symbols are registered marks of the Blue Cross and Blue Shield Association."
			+ "\n\nCopyright (c) 2012, Anthem Blue Cross and Blue Shield.  All Rights Reserved. This confidential information should not be distributed without prior written consent and should only be used to review health care utilization.";
	public static final String  AGE_BAND_FILTER = "agebandfilter";
	public static final String HCC_THRESHOLD_FILTER = "hccthreshholdfilter";
	public static final String DEFAULT_HCC_THRESHOLD_VALUE = "defaultHccthreshold";
	public static final String PAID_INCURRED_FILTER = "paidandincurredfilter";
	public static final String TIMEPERIOD_TYPE_FILTER = "timeperiodtypefilter";
	public static final String CONTRACT_TIER_LVL_FILTER = "mbrshpreporttierlvlfilter";
	public static final String GRP_RPRTNG_OUTER_SELECT = "select distinct CODE, case when CODE = DESCRIPTION then CODE else max(DESCRIPTION) over(partition by CODE) "
			+ "  end   as DESCRIPTION from (";
	public static final String ALL_SELECTED = "ALL-SELECTED";
	public static final String MEMBERS="Members";
	public static final String INCURRED = "Incurred";
	public static final String PAID = "Paid";
	public static final String ACCOUNT_3061_IND_Y = "1";
	public static final String ACCOUNT_3061_IND_N = "0";
	public static final String TABLEAU_URL_PRPTY_NM = "TABLEAU_URL";
	public static final String KPI_CUR_PMPM = "CP";
	public static final String KPI_PRIOR1_PMPM = "P1";
	public static final String KPI_PRIOR2_PMPM = "P2";
	public static final String CNTRCT_TIER_2_TYPES = "tierLevel2ContractTypes";
	public static final String CNTRCT_TIER_3_TYPES = "tierLevel3ContractTypes";
	public static final String CNTRCT_TIER_4_OPA_TYPES = "tierLevel4OPAContractTypes";
	public static final String CNTRCT_TIER_4_OPB_TYPES = "tierLevel4OPBContractTypes";
	public static final String CNTRCT_TIER_5_TYPES = "tierLevel5ContractTypes";
	public static final String CNTRCT_TIER_2 = "CNTRCT_TIER_2_TYPE_DESC";
	public static final String CNTRCT_TIER_3 = "CNTRCT_TIER_3_TYPE_DESC";
	public static final String CNTRCT_TIER_4_OPA = "CNTRCT_TIER_4_OPA_DESC";
	public static final String CNTRCT_TIER_4_OPB = "CNTRCT_TIER_4_OPB_DESC";
	public static final String CNTRCT_TIER_5 = "CNTRCT_TIER_5_TYPE_DESC";
	public static final String KPI_TYPE_FINANCIAL = "financial";
	public static final String KPI_TYPE_CLINICAL = "clinical";
	public static final String KPI_TYPE_PROVIDER = "provider";
	
	public static final String TRUSTED ="/trusted";
	public static final String UTF8 = "UTF-8";
	public static final String CUSTOM = "custom";
	public static final String SM_USER = "SM_USER";
	public static final String SM_FIRST_NAME = "SM_FIRST_NAME";
	public static final String SM_LAST_NAME = "SM_LAST_NAME";
	public static final String SM_DOMAIN = "SM_DOMAIN";
	public static final String WORKNET_USER_PREFIX = "US\\";
	public static final char EXTN_SEPERATOR = '.';
	public static final String ACTV_FLG_Y ="Y";
	public static final String ACTV_FLG_N ="N";
	
	private ACIISSTConstants() {

	}

}
