package com.anthem.aciisst.common.constants;

public enum UserAttribute {
	
	LDAP_ATTR_MAIL("mail"),
	LDAP_ATTR_ACCOUNT("sAMAccountName"),
	FULL_ADMIN("Full Admin"),
	RESTRICTED_ADMIN("Restricted Admin"),
	USER("User");
	
	public static UserAttribute fromString(String title) {
		if(title == null) {
			return null;
		}
		
		for(UserAttribute status: UserAttribute.values()) {
			if(status.isEqual(title)) {
				return status;
			}
		}
		
		return null;
	}
	
	private String title;
	
	private UserAttribute(String title) {
		this.title = title;
	}
	
	public boolean isEqual(Status status) {
		return this.isEqual(status.getTitle());
	}
	
	public boolean isEqual(String title) {
		return this.getTitle().equalsIgnoreCase(title);
	}
	
	@Override
	public String toString() {
		return this.title;
	}
	
	public String getTitle() {
		return this.title;
	}
}
