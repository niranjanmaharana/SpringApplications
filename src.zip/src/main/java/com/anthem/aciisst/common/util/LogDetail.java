package com.anthem.aciisst.common.util;

import com.anthem.aciisst.common.constants.ACIISSTConstants;

public class LogDetail {
	private String system;
	private String userId;
	private String accountId;
	private String uri;
	private Exception exception;
	
	public LogDetail(String userId, String accountId, String uri) {
		super();
		this.system = ACIISSTConstants.SYSTEM;
		this.userId = userId;
		this.accountId = accountId;
		this.uri = uri;
	}
	
	public LogDetail() {
		
	}
	
	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}

	public Exception getException() {
		return exception;
	}

	public void setException(Exception exception) {
		this.exception = exception;
	}
	
}
