package com.anthem.aciisst.common.util;

import org.slf4j.LoggerFactory;

/**
 * @author AF48929
 *	LoggingUtil - An utility class to handle all the logging
 *  functionality of the application.
 */
public class LoggingUtil {
	
	private LoggingUtil() {
		super();
	}

	/**
	 * @param clazz
	 * @param system
	 * @param userId
	 * @param accountId
	 * @param uri
	 * @param e
	 *            logError() - This method is used to log the error/exception along
	 *            with system, user and accountId params to log more details of
	 *            the action performed
	 */
	public static void logError(Class clazz, LogDetail logDetail, Exception e){
		String systemName = "";
		String userId = "";
		String accountId = "";
		String uri = "";
	    String errMsg = "" + e;
		
	    if (logDetail != null) {
	    	systemName = logDetail.getSystem();
        	userId = logDetail.getUserId();
        	accountId = logDetail.getAccountId();
        	uri = logDetail.getUri();
	        
		    // ensure no CRLF injection into logs for forging records
	        systemName = (systemName == null) ? "" : systemName.replace('\n', '_').replace('\r', '_');
	        userId = (userId == null) ? "" : userId.replace('\n', '_').replace('\r', '_');
	        accountId = (accountId == null) ? "" : accountId.replace('\n', '_').replace('\r', '_');
	        uri = (uri == null) ? "" : uri.replace('\n', '_').replace('\r', '_');
	        errMsg = errMsg.replace('\n', '_').replace('\r', '_');

	        
			LoggerFactory.getLogger(clazz).error(
					"Exception - SYSTEM={}, USERID={}, ACCOUNTID={}, ACIISST_SERVICE={}, errorMsg={}", systemName, userId,
					accountId, uri,  errMsg);

	    }

    }
	
	/**
	 * @param clazz
	 * @param system
	 * @param userId
	 * @param accountId
	 * @param uri
	 *            logInfo() - This method is used to log information 
	 *            with system, user and accountId params to log more details of
	 *            the action performed
	 */
	public static void logInfo(Class clazz,LogDetail logDetail){
		String systemName = "";
		String userId = "";
		String accountId = "";
		String uri = "";
		
	    if (logDetail != null) {
	    	systemName = logDetail.getSystem();
        	userId = logDetail.getUserId();
        	accountId = logDetail.getAccountId();
        	uri = logDetail.getUri();
        
		    // ensure no CRLF injection into logs for forging records
	        systemName = (systemName == null) ? "" : systemName.replace('\n', '_').replace('\r', '_');
	        userId = (userId == null) ? "" : userId.replace('\n', '_').replace('\r', '_');
	        accountId = (accountId == null) ? "" : accountId.replace('\n', '_').replace('\r', '_');
	        uri = (uri == null) ? "" : uri.replace('\n', '_').replace('\r', '_');
	        
			LoggerFactory.getLogger(clazz).info(
					"Info - SYSTEM={}, USERID={}, ACCOUNTID={}, ACIISST_SERVICE={}", systemName, userId,
					accountId, uri);

	    }
    }
}
