package com.anthem.aciisst.common.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class AcisstUtil {
	
	private AcisstUtil() {
		
	}
	
	public static int getDiffMonth(String startdate,String enddate) {
		
		String startyear=startdate.substring(0,startdate.length()-2);
		String endyear=enddate.substring(0,enddate.length()-2);
		String smm=startdate.length() > 2 ? startdate.substring(startdate.length() - 2) : startdate;
		String emm=enddate.length() > 2 ? enddate.substring(enddate.length() - 2) : enddate;
		int dyr= Integer.parseInt(endyear)-Integer.parseInt(startyear);
		int tot = 0;
		tot=Integer.parseInt(emm);
		if(dyr>0) {
				int mm=0;
				mm+=13-Integer.parseInt(smm);
				tot+=mm;
				tot+=(dyr-1)*12;
			
		}else if(dyr==0) {
			tot=tot-Integer.parseInt(smm);
			tot++;
		}
		return tot;
	}
	
	public static BigDecimal bigDecimaldivision(BigDecimal value1,BigDecimal value2) {
		
		BigDecimal result=BigDecimal.ZERO;
		if(value1.compareTo(BigDecimal.ZERO)!=0 && value2.compareTo(BigDecimal.ZERO)!=0) {
			result=value1.divide(value2, 4, RoundingMode.HALF_UP);			
		}
		
		return result;
		
		
	}
	
	public static byte[] convertInputstreamToByteArray(InputStream targetStream) throws IOException{
		byte[] byteArray = null;
		    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		    int nRead;
		    byte[] data = new byte[1024];		   
				while ((nRead = targetStream.read(data, 0, data.length)) != -1) {
				    buffer.write(data, 0, nRead);
				}
		    byteArray = buffer.toByteArray();
		    
	    return byteArray;
	}

}
