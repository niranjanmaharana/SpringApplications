package com.anthem.aciisst.account.web.view.response;

import java.util.List;

public class UserSegmentRequest extends BaseAccountStructureDTO{
	
	
	private List<SegmentKeyDTO> segmentKeys;
	
	public List<SegmentKeyDTO> getSegmentKeys() {
		return segmentKeys;
	}
	public void setSegmentKeys(List<SegmentKeyDTO> segmentKeys) {
		this.segmentKeys = segmentKeys;
	}
}
