package com.anthem.aciisst.account.web.view.response;

public class TimePeriodFilterResponse {
	private String currentperiodstart;
	private String currentperiodend;
	private String priorperiod1start;
	private String priorperiod1end;
	private String priorperiod2start;
	private String priorperiod2end;
	
	private int numberoftimeperiod;
	public String getCurrentperiodstart() {
		return currentperiodstart;
	}
	public void setCurrentperiodstart(String currentperiodstart) {
		this.currentperiodstart = currentperiodstart;
	}
	public String getCurrentperiodend() {
		return currentperiodend;
	}
	public void setCurrentperiodend(String currentperiodend) {
		this.currentperiodend = currentperiodend;
	}
	public String getPriorperiod1start() {
		return priorperiod1start;
	}
	public void setPriorperiod1start(String priorperiod1start) {
		this.priorperiod1start = priorperiod1start;
	}
	public String getPriorperiod1end() {
		return priorperiod1end;
	}
	public void setPriorperiod1end(String priorperiod1end) {
		this.priorperiod1end = priorperiod1end;
	}
	public String getPriorperiod2start() {
		return priorperiod2start;
	}
	public void setPriorperiod2start(String priorperiod2start) {
		this.priorperiod2start = priorperiod2start;
	}
	public String getPriorperiod2end() {
		return priorperiod2end;
	}
	public void setPriorperiod2end(String priorperiod2end) {
		this.priorperiod2end = priorperiod2end;
	}
	public int getNumberoftimeperiod() {
		return numberoftimeperiod;
	}
	public void setNumberoftimeperiod(int numberoftimeperiod) {
		this.numberoftimeperiod = numberoftimeperiod;
	}
}
