package com.anthem.aciisst.account.web.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("nas")
public class NasController {

	@Value("${export.path}")
	private String exportPath;
	
	@RequestMapping(method = RequestMethod.GET, value = "/write/{exportid}", produces="application/json")
	public String writer(@PathVariable("exportid") String exportId) {
		String msg = "writer: ";
		String fileName = exportPath + "dummy_nas_file.txt";
		if(exportId != null){
			
			fileName = exportPath + getPhysicalFileName(exportId, "txt");
		}
		try {
			String data = "Testing NAS Location on Docker. This is Test File";
			FileOutputStream out = new FileOutputStream(fileName);
			out.write(data.getBytes());
			out.close();
			msg = msg + data;
        } catch (Exception e) {
            e.printStackTrace();
            msg = msg + e;
        }
		
		return msg;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/read/{exportid}", produces="application/json")
	public String reader(@PathVariable("exportid") String exportId) {
		String nastext = "reader: ";
		String fileName = exportPath + "dummy_nas_file.txt";
		if(exportId != null){
			fileName = exportPath + getPhysicalFileName(exportId, "txt");
		}

		BufferedReader br = null;

		try {

				br = new BufferedReader(new FileReader(fileName));

				String sCurrentLine;

				while ((sCurrentLine = br.readLine()) != null) {
					nastext = nastext + sCurrentLine;
				}

        } catch (Exception e) {
            e.printStackTrace();
            nastext = nastext + e;
        }finally {

			try {

				if (br != null)
					br.close();
			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}
		return nastext;

	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/list",  produces="application/json")
	public String readFile() {
		String nastext = "reader: ";
		try {
			File file = new File(exportPath);
				
				if(file.exists()){
					nastext = nastext + "Folder Exists ";
				}
				nastext = nastext + "listing fies: ";
				String list [] = file.list();
				
				for(String s : list){
					nastext = nastext + s + "; ";
				}
        } catch (Exception e) {
            e.printStackTrace();
            nastext = nastext + e;
        }
		return nastext;

	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/folder/{name}", produces="application/json")
	public String createFolder(@PathVariable("name") String folderName) {
		String nastext = "createFolder: ";
		String name = null;
		if(!StringUtils.isEmpty(folderName) && folderName.matches("^[a-zA-Z0-9_-]*$")){
			name = folderName;
		}
		else{
			return "invalid request..";
		}

		try {
			File file = new File(exportPath + "/" + name);
			if(file != null){
				file.mkdirs();
				nastext = nastext + "Folder created- " + file.getAbsolutePath();
			}
          
        } catch (Exception e) {
            e.printStackTrace();
            nastext = nastext + e;
        }
		return nastext;

	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/test", produces="application/json")
	public String testMethod() {

		return "Welcome to The New CII Tool!!";
	}
	
	public String getPhysicalFileName(String exportId, String fileType) {

		/*
		 * Parse physical file name to ensure expected format.
		*/
		Pattern p = Pattern.compile("(^[a-zA-Z0-9_-]{1,})(\\.)(xlsx|xls|pdf|txt)$");
		Matcher m = p.matcher(exportId + "." + fileType);
		m.find();

		return m.group(1) + m.group(2) + m.group(3);
	}

}
