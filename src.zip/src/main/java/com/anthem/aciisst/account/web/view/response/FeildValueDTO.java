package com.anthem.aciisst.account.web.view.response;

public class FeildValueDTO {
	private String value;
	public FeildValueDTO() {
		
	}
	public FeildValueDTO(String value) {
		this.value=value;
	}
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
