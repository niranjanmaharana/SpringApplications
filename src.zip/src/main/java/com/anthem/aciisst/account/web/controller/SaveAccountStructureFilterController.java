package com.anthem.aciisst.account.web.controller;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.account.service.SaveAccountStructureFilterService;
import com.anthem.aciisst.account.web.view.request.SaveAccountStructureFilterCreateRequest;
import com.anthem.aciisst.account.web.view.request.SaveAccountStructureFilterRequest;
import com.anthem.aciisst.account.web.view.request.SaveAccountStructureFilterUpdateRequest;
import com.anthem.aciisst.account.web.view.response.SaveAccountStructureFilterCreateResponse;
import com.anthem.aciisst.account.web.view.response.SaveAccountStructureFilterResponse;
import com.anthem.aciisst.account.web.view.response.SaveAccountStructureFilterSearchResponse;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.exception.InvalidDataException;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.common.web.view.ResponseView;
import com.anthem.aciisst.security.dto.AppUser;

@CrossOrigin
@RestController
public class SaveAccountStructureFilterController {

	@Autowired
	SaveAccountStructureFilterService saveFilterService;

	/**
	 * @param request
	 * @param httpRequest
	 * @param principal
	 * @return ResponseView<List<SaveAccountStructureFilterSearchResponse>>
	 * 
	 * Get list of all active saved filter form ACIISST_SAVE_FLTR table for the user requesting this detail.
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/savefilter/search")
	public ResponseView<List<SaveAccountStructureFilterSearchResponse>> searchAccountStructure(
			@RequestBody SaveAccountStructureFilterRequest request, HttpServletRequest httpRequest, Principal principal) {
		ResponseView<List<SaveAccountStructureFilterSearchResponse>> responseView = new ResponseView<>();
		
		AppUser user = (AppUser) ((Authentication)principal).getPrincipal();
		int userIdInt = user.getUserIdInt();
		request.setAciisstUserId(userIdInt);
		
		try {
			List<SaveAccountStructureFilterSearchResponse> filterList = saveFilterService.searchSavedFilter(request);
			responseView.setData(filterList);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());

			LoggingUtil.logError(this.getClass(), new LogDetail(principal.getName(), request.getAccountId(), httpRequest.getRequestURI()), e);
		}

		return responseView;
	}
	
	/**
	 * @param id
	 * @param httpRequest
	 * @param principal
	 * @return ResponseView<SaveAccountStructureFilterResponse>
	 * 
	 * Get saved filter details for the given SAVE_FLTR_ID from ACIISST_SAVE_FLTR and ACIISST_SAVE_FLTR_DTL table.
	 * Response will contain Code and Description of all the account structure filters (i.e. Groups, SubGroups etc.) saved in the table.
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/savefilter/{id}")
	public ResponseView<SaveAccountStructureFilterResponse> getSavedFilter(@PathVariable int id, HttpServletRequest httpRequest, Principal principal) {
		ResponseView<SaveAccountStructureFilterResponse> responseView = new ResponseView<>();
		SaveAccountStructureFilterResponse response = new SaveAccountStructureFilterResponse();
		
		AppUser user = (AppUser) ((Authentication)principal).getPrincipal();
		int userIdInt = user.getUserIdInt();
		
		try {
				response = saveFilterService.getSavedFilterDtls(id, userIdInt);

				responseView.setData(response);
				responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
				responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);

		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());

			LoggingUtil.logError(this.getClass(), new LogDetail(principal.getName(), ACIISSTConstants.NA, httpRequest.getRequestURI()), e);
		}
		
		return responseView;
	}

	/**
	 * @param request
	 * @param httpRequest
	 * @param principal
	 * @return ResponseView<SaveAccountStructureFilterCreateResponse>
	 * 
	 * Create a new save filter record in ACIISST_SAVE_FLTR and ACIISST_SAVE_FLTR_DTL table.
	 *  
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/savefilter")
	public ResponseView<SaveAccountStructureFilterCreateResponse> createSaveFilter(
			@RequestBody SaveAccountStructureFilterCreateRequest request, HttpServletRequest httpRequest, Principal principal) {
		ResponseView<SaveAccountStructureFilterCreateResponse> responseView = new ResponseView<>();
		
		AppUser user = (AppUser) ((Authentication)principal).getPrincipal();
		int userIdInt = user.getUserIdInt();
		request.setAciisstUserId(userIdInt);
		
		try {
			SaveAccountStructureFilterCreateResponse response = saveFilterService.createSaveFilter(request);
			
			responseView.setData(response);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);

		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());

			LoggingUtil.logError(this.getClass(), new LogDetail(principal.getName(), request.getAccountId(), httpRequest.getRequestURI()), e);
		}
		
		return responseView;
	}
	
	/**
	 * @param request
	 * @param id
	 * @param httpRequest
	 * @param principal
	 * @return ResponseView<SaveAccountStructureFilterCreateResponse>
	 * 
	 * Update existing saved filter Name and Description for given SAVE_FLTR_ID in ACIISST_SAVE_FLTR table.
	 */
	@RequestMapping(method = RequestMethod.PUT, value = "/savefilter/{id}")
	public ResponseView<SaveAccountStructureFilterCreateResponse> updateSavedFilter(
			@RequestBody SaveAccountStructureFilterUpdateRequest request, @PathVariable int id, HttpServletRequest httpRequest, Principal principal) {
		ResponseView<SaveAccountStructureFilterCreateResponse> responseView = new ResponseView<>();
		
		AppUser user = (AppUser) ((Authentication)principal).getPrincipal();
		int userIdInt = user.getUserIdInt();
		request.setAciisstUserId(userIdInt);
		
		try {
				SaveAccountStructureFilterCreateResponse response = saveFilterService.updateSavedFilter(request, id);

				responseView.setData(response);
				responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
				responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());

			LoggingUtil.logError(this.getClass(), new LogDetail(principal.getName(), request.getAccountId(), httpRequest.getRequestURI()), e);
		}
		
		return responseView;
	}

	
	/**
	 * @param id
	 * @param httpRequest
	 * @param principal
	 * @return ResponseView<SaveAccountStructureFilterCreateResponse>
	 * 
	 * This will soft delete the existing record in ACIIST_SAVE_FLTR table.
	 * update ACTV_FLG and TRMNTN_DTM
	 */
	@RequestMapping(method = RequestMethod.DELETE, value = "/savefilter/{id}")
	public ResponseView<SaveAccountStructureFilterCreateResponse> deleteAccountStructureFilter(
			@PathVariable int id, HttpServletRequest httpRequest, Principal principal) {
		ResponseView<SaveAccountStructureFilterCreateResponse> responseView = new ResponseView<>();
		
		AppUser user = (AppUser) ((Authentication)principal).getPrincipal();
		int userIdInt = user.getUserIdInt();
		
		try {
				SaveAccountStructureFilterCreateResponse response = saveFilterService.deleteSavedFilter(id, userIdInt);
				
				responseView.setData(response);
				responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
				responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);

		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());

			LoggingUtil.logError(this.getClass(), new LogDetail(principal.getName(), ACIISSTConstants.NA, httpRequest.getRequestURI()), e);
		}
		
		return responseView;
	}

}