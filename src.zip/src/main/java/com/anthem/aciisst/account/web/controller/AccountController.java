package com.anthem.aciisst.account.web.controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.account.service.AccountService;
import com.anthem.aciisst.account.web.view.response.AccountResponseView;
import com.anthem.aciisst.account.web.view.response.AccountStructureFilterResponseView;
import com.anthem.aciisst.account.web.view.response.AccountStructureRequest;
import com.anthem.aciisst.account.web.view.response.AccountStructureResponseView;
import com.anthem.aciisst.account.web.view.response.KpiDTO;
import com.anthem.aciisst.account.web.view.response.KpiResponse;
import com.anthem.aciisst.account.web.view.response.KpiValue;
import com.anthem.aciisst.account.web.view.response.SessionKeyResponse;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;
import com.anthem.aciisst.common.web.view.ResponseView;
import com.anthem.aciisst.security.dto.AppUser;


/**
 * 
 * This controller will return the list of accounts ,recently accessed accounts
 */
@CrossOrigin
@RestController
@RequestMapping("account")
public class AccountController {

	@Autowired
	AccountService accountService;
	

	/**
	 * Service will get the all the accounts and recently accessed accouts for the
	 * given user
	 * 
	 * @param userId
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/filter")
	public ResponseView<List<AccountResponseView>> getUserAccounts(@RequestParam("SM_USER_ID") String smUserId,
			HttpServletRequest httpRequest) {
		ResponseView<List<AccountResponseView>> responseView = new ResponseView<>();
		try {

			List<AccountResponseView> accountList = accountService.getUserAccounts(smUserId);
			responseView.setData(accountList);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId( ACIISSTConstants.NA);
			logDetail.setUserId( smUserId);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			logDetail.setException(e);
			LoggingUtil.logError(this.getClass(),logDetail, e);

		}

		return responseView;
	}

	/**
	 * Service will do Account filter based on the request
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/search")
	public ResponseView<List<AccountResponseView>> accountSearch(@RequestParam("USER_ID") String smUserId,
			@RequestParam("SEARCH_TERM") String searchStr, HttpServletRequest httpRequest) {
		ResponseView<List<AccountResponseView>> responseView = new ResponseView<>();
		try {

			List<AccountResponseView> accountList = accountService.accountSearch(smUserId, searchStr);
			responseView.setData(accountList);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(ACIISSTConstants.NA);
			logDetail.setUserId(ACIISSTConstants.NA);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			logDetail.setException(e);
			LoggingUtil.logError(this.getClass(),logDetail, e);

		}

		return responseView;
	}

	/**
	 * This Service will update recently accessed Accounts for the given User Id
	 * 
	 * @param User_id
	 * @return List of recently accessed accounts
	 */

	@RequestMapping(method = RequestMethod.POST, value = "/recentlyAccessed")
	public ResponseView<List<AccountResponseView>> updateRecentlyAccessedAccounts(
			@RequestParam("SM_USER_ID") String userId, @RequestParam("ACCT_ID") String accountId,
			HttpServletRequest httpRequest) {
		ResponseView<List<AccountResponseView>> responseView = new ResponseView<>();
		try {
			int result=accountService.updateRecentlyAccessedAccounts(userId, accountId);
			if(result>0) {
				responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
				responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);				
			}else {
				responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
				responseView.setStatusDescription("Nothing Inserted");	
			}
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(accountId);
			logDetail.setUserId(userId);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			logDetail.setException(e);
			LoggingUtil.logError(this.getClass(),logDetail, e);
			
		}

		return responseView;
	}

	/**
	 * This service is to search the account name
	 * 
	 * @param searchKey
	 * @param searchValue
	 * @return search results for the search key
	 */
	/*@RequestMapping(method = RequestMethod.GET, value = "/searchaccounts")
	public ResponseView<List<AccountResponseView>> searchAccount(@RequestParam(value = "searchKey") String searchKey,
			@RequestParam(value = "searchValue") String searchValue, @RequestParam("SM_USER_ID") String smUserId) {

		List<AccountResponseView> accounts = accountService.searchAccount(searchKey, searchValue, smUserId);

		ResponseView<List<AccountResponseView>> responseView = new ResponseView<>();
		responseView.setData(accounts);

		return responseView;
	}*/

	/*@RequestMapping(method = RequestMethod.GET, value = "/activeaccounts")
	public ResponseView<List<AccountResponseView>> getAllActiveAccounts() {

		List<AccountResponseView> accountList = accountService.getAllActiveAccounts();
		ResponseView<List<AccountResponseView>> responseView = new ResponseView<>();
		responseView.setData(accountList);

		return responseView;
	}*/

	/**
	 * Service will do Account filter based on the request
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/filter/accountStructure/save")
	public ResponseView<List<AccountStructureResponseView>> getAccountDetails(
			@RequestBody AccountStructureRequest accountStructureRequest, HttpServletRequest httpRequest) {
		ResponseView<List<AccountStructureResponseView>> responseView = new ResponseView<>();
		try {
			String msg = accountService.updateUserSegmentKeys(accountStructureRequest, ACIISSTConstants.SEGMENT_KEYS);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(msg);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(accountStructureRequest.getAccountId());
			logDetail.setUserId(accountStructureRequest.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			logDetail.setException(e);
			LoggingUtil.logError(this.getClass(),logDetail, e);
			
		}

		return responseView;
	}

	/**
	 * Service will do Account filter based on the request
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/filter/accountStructure/{requiredFilter}")
	public List<AccountStructureFilterResponseView> getAccountDetails(@PathVariable String requiredFilter,
			@RequestBody AccountStructureRequest accountStructureRequest, HttpServletRequest httpRequest) {
		List<AccountStructureFilterResponseView> filterList = new ArrayList<>();
		try {
			filterList = accountService.getAccountStructureFilter(accountStructureRequest, requiredFilter);
			if (requiredFilter.equalsIgnoreCase(ACIISSTConstants.STATUS)) {
				filterList.addAll(accountService.getAccountStructureFilter(accountStructureRequest,
						ACIISSTConstants.SUBGRPRLUP_STATUS));
			}
		} catch (Exception e) {
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(accountStructureRequest.getAccountId());
			logDetail.setUserId(accountStructureRequest.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			logDetail.setException(e);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}

		return filterList;
	}

	

	
	/**
	 * Service will do Account filter based on the request
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/filter/uniqueKey")
	public ResponseView<SessionKeyResponse> getUniqueId(HttpServletRequest httpRequest) {
		ResponseView<SessionKeyResponse> responseView = new ResponseView<>();
		try {
			SessionKeyResponse sessionKey = new SessionKeyResponse();
			String uniqueId = accountService.getUniqueId();
			sessionKey.setSessionKey(uniqueId);
			responseView.setData(sessionKey);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(ACIISSTConstants.NA);
			logDetail.setUserId(ACIISSTConstants.NA);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			logDetail.setException(e);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}

		return responseView;
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/filter/kpi")
	public ResponseView<KpiResponse> getKPIDetails(@RequestBody KpiDTO kpiRequest, HttpServletRequest httpRequest) {
				Authentication authentication = SecurityContextHolder.getContext().getAuthentication();	
				AppUser user = (AppUser) authentication.getPrincipal();
	
		int userIdInt = user.getUserIdInt();
		kpiRequest.setAciisstUserId(userIdInt);
		
		ResponseView<KpiResponse> responseView = new ResponseView<>();
		try {
			KpiResponse resp = new KpiResponse();
			//Financial KPI
			KpiValue val = accountService.getFinancialKPIDetails(kpiRequest);
			resp.setFinancial(val);
			//Clinical KPI
			KpiValue clinical = accountService.getClinicalKpi(kpiRequest);			
			resp.setClinical(clinical);
			//Provider KPI
			KpiValue val2 = new KpiValue();
			val2.setDescription(null);
			val2.setKey(null);
			val2.setValue(null);
			val2.setSymbol(null);
			val2.setCurr_data(null);
			val2.setPrior1_data(null);
			val2.setPrior2_data(null);
			resp.setProvider(val2);
			responseView.setData(resp);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(kpiRequest.getAccountId());
			logDetail.setUserId(kpiRequest.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			logDetail.setException(e);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}

		return responseView;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/kpi/{kpiType}")
	public ResponseView<KpiValue> getKPIDetails(@PathVariable String kpiType,
			@RequestBody KpiDTO kpiRequest, HttpServletRequest httpRequest) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();	
		AppUser user = (AppUser) authentication.getPrincipal();
	
		int userIdInt = user.getUserIdInt();
		kpiRequest.setAciisstUserId(userIdInt);
		ResponseView<KpiValue> responseView = new ResponseView<>();
		KpiValue val = new KpiValue();
		
		try {			
			if (kpiType.equalsIgnoreCase(ACIISSTConstants.KPI_TYPE_FINANCIAL)) {
				val = accountService.getFinancialKPIDetails(kpiRequest);				
			} else if(kpiType.equalsIgnoreCase(ACIISSTConstants.KPI_TYPE_CLINICAL)){
				val = accountService.getClinicalKpi(kpiRequest);				
			} else if (kpiType.equalsIgnoreCase(ACIISSTConstants.KPI_TYPE_PROVIDER)){				
				val.setDescription(null);
				val.setKey(null);
				val.setValue(null);
				val.setSymbol(null);
				val.setCurr_data(null);
				val.setPrior1_data(null);
				val.setPrior2_data(null);				
			}
			responseView.setData(val);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(kpiRequest.getAccountId());
			logDetail.setUserId(kpiRequest.getUserId());
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			logDetail.setException(e);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}
		return responseView;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/filter/membershipReport/contractTier")
	public List<AccountStructureFilterResponseView> getContractTier(HttpServletRequest httpRequest) {
		List<AccountStructureFilterResponseView> responseView = new ArrayList<>();
		try {
			responseView = accountService.getContractTierValues();
		} catch (Exception e) {
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId( ACIISSTConstants.NA);
			logDetail.setUserId( ACIISSTConstants.NA);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			logDetail.setException(e);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}
		return responseView;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/properties")
	public ResponseView<List<Map<String, String>>> getAppProperties(HttpServletRequest httpRequest) {
		ResponseView<List<Map<String, String>>> responseView = new ResponseView<>();
		List<Map<String, String>> properties = new ArrayList<>();
		try {
			properties = accountService.getAppProperties();
			responseView.setData(properties);
			responseView.setStatus(ACIISSTConstants.RESPONSE_SUCCESS);
			responseView.setStatusDescription(ACIISSTConstants.RESPONSE_SUCCESS_DESCP);
		} catch (Exception e) {
			responseView.setStatus(ACIISSTConstants.RESPONSE_FAILURE);
			responseView.setStatusDescription(e.getMessage());
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId( ACIISSTConstants.NA);
			logDetail.setUserId( ACIISSTConstants.NA);
			logDetail.setUri(httpRequest.getRequestURI());
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			logDetail.setException(e);
			LoggingUtil.logError(this.getClass(),logDetail, e);
		}
		return responseView;
	}
	
	/*
	 * This Service will return the modules associated with the Account
	 * @param request
	 * @return
	 * 
	 */
	 			
		@RequestMapping(method = RequestMethod.POST, value = "/accountModule")
		public String getAccountModule(@RequestBody AccountResponseView acctRv){
			return accountService.generateModule(acctRv.getAccountId());
			
			
		}
		
	}
	


