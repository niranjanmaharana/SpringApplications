package com.anthem.aciisst.account.web.view.response;

import java.util.Date;
import java.util.List;

import com.anthem.aciisst.filter.web.view.response.GroupResponseView;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class AccountResponseView {

	private String accountId;
	private String accountName;
	@JsonInclude(Include.NON_NULL)
	private String key;
	@JsonInclude(Include.NON_NULL)
	private Date effectiveDate;
	@JsonInclude(Include.NON_NULL)
	private boolean phi;
	@JsonInclude(Include.NON_NULL)
	private String securityCode;
	@JsonInclude(Include.NON_NULL)
	private String subgroupRptg1LabelCode;
	@JsonInclude(Include.NON_NULL)
	private String subgroupRptg2LabelCode;
	@JsonInclude(Include.NON_NULL)
	private String subgroupRptg3LabelCode;
	@JsonInclude(Include.NON_NULL)
	private String subgroupRptg4LabelCode;
	@JsonInclude(Include.NON_NULL)
	private String grouppRptg1LabelCode;
	@JsonInclude(Include.NON_NULL)
	private String grouppRptg2LabelCode;
	@JsonInclude(Include.NON_NULL)
	private String grouppRptg3LabelCode;
	@JsonInclude(Include.NON_NULL)
	private String defaultHccThresholdAmount;
	@JsonInclude(Include.NON_NULL)
	private String defaultPaidAmountTypeDesc;
	@JsonInclude(Include.NON_NULL)
	private boolean displayDept;
	@JsonInclude(Include.NON_NULL)
	private boolean displayGroupRptg1Code;
	@JsonInclude(Include.NON_NULL)
	private boolean displayGroupRptg2Code;
	@JsonInclude(Include.NON_NULL)
	private boolean displayGroupRptg3Code;
	@JsonInclude(Include.NON_NULL)
	private boolean displayRlup1Code;
	@JsonInclude(Include.NON_NULL)
	private boolean displayRlup2Code;
	@JsonInclude(Include.NON_NULL)
	private boolean displayRlup3Code;
	@JsonInclude(Include.NON_NULL)
	private boolean displayRlup4Code;
	@JsonInclude(Include.NON_NULL)
	private boolean displayStatus;
	@JsonInclude(Include.NON_NULL)
	private Integer accountPlanMonthNbr;
	@JsonInclude(Include.NON_NULL)
	private String accountSizeClassificationnCode;
	@JsonInclude(Include.NON_NULL)
	private Integer accountDefaultRnoutMonthNbr;
	@JsonInclude(Include.NON_NULL)
	private String accountDefaultTmProdCode;
	@JsonInclude(Include.NON_NULL)
	private String rptgBrandLogoCd;
	
	@JsonInclude(Include.NON_NULL)
	private String account_3061_ind = "0";
	
	@JsonInclude(Include.NON_NULL)
	private String paidOrIncured = "paid";
	
	@JsonInclude(Include.NON_NULL)
	private String lastCompleteMonthLoaded;
	
	private String defaultMembershipBenchmark1Value = "";
	private String defaultClinicalBenchmark1Value = "";
	private String defaultCondDriverBenchmark1Value = "";
	private String defaultCostUtilBenchmark1Value = "";
	private String defaultProvNtwkBenchmark1Value = "";
	private String defaultSpcltyBenchmark1Value = "";
	
	@JsonInclude(Include.NON_NULL)
	private List<GroupResponseView> groups;

	public boolean isPhi() {
		return phi;
	}

	public List<GroupResponseView> getGroups() {
		return groups;
	}

	public void setGroups(List<GroupResponseView> groups) {
		this.groups = groups;
	}

	public void setPhi(boolean phi) {
		this.phi = phi;
	}

	public String isSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}

	public AccountResponseView(String accountId, String accountName, Date effectiveDate, Date terminationDate) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.effectiveDate = effectiveDate;
		this.terminationDate = terminationDate;
	}

	public AccountResponseView(String accountId, String accountName, Date effectiveDate, Date terminationDate,
			String securityCode, boolean phi) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.effectiveDate = effectiveDate;
		this.terminationDate = terminationDate;
		this.securityCode = securityCode;
		this.phi = phi;
	}

	@JsonIgnore
	private Date terminationDate;

	public String getSubgroupRptg4LabelCode() {
		return subgroupRptg4LabelCode;
	}

	public void setSubgroupRptg4LabelCode(String subgroupRptg4LabelCode) {
		this.subgroupRptg4LabelCode = subgroupRptg4LabelCode;
	}

	public AccountResponseView() {

	}

	public AccountResponseView(String accountId, String accountName, String key) {
		this.accountId = accountId;
		this.accountName = accountName;
		this.key = key;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public Date getTerminationDate() {
		return terminationDate;
	}

	public void setTerminationDate(Date terminationDate) {
		this.terminationDate = terminationDate;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getSubgroupRptg1LabelCode() {
		return subgroupRptg1LabelCode;
	}

	public void setSubgroupRptg1LabelCode(String subgroupRptg1LabelCode) {
		this.subgroupRptg1LabelCode = subgroupRptg1LabelCode;
	}

	public String getSubgroupRptg2LabelCode() {
		return subgroupRptg2LabelCode;
	}

	public void setSubgroupRptg2LabelCode(String subgroupRptg2LabelCode) {
		this.subgroupRptg2LabelCode = subgroupRptg2LabelCode;
	}

	public String getSubgroupRptg3LabelCode() {
		return subgroupRptg3LabelCode;
	}

	public void setSubgroupRptg3LabelCode(String subgroupRptg3LabelCode) {
		this.subgroupRptg3LabelCode = subgroupRptg3LabelCode;
	}

	public String getGrouppRptg1LabelCode() {
		return grouppRptg1LabelCode;
	}

	public void setGrouppRptg1LabelCode(String grouppRptg1LabelCode) {
		this.grouppRptg1LabelCode = grouppRptg1LabelCode;
	}

	public String getGrouppRptg2LabelCode() {
		return grouppRptg2LabelCode;
	}

	public void setGrouppRptg2LabelCode(String grouppRptg2LabelCode) {
		this.grouppRptg2LabelCode = grouppRptg2LabelCode;
	}

	public String getGrouppRptg3LabelCode() {
		return grouppRptg3LabelCode;
	}

	public void setGrouppRptg3LabelCode(String grouppRptg3LabelCode) {
		this.grouppRptg3LabelCode = grouppRptg3LabelCode;
	}

	public String getDefaultHccThresholdAmount() {
		return defaultHccThresholdAmount;
	}

	public void setDefaultHccThresholdAmount(String defaultHccThresholdAmount) {
		this.defaultHccThresholdAmount = defaultHccThresholdAmount;
	}

	public String getDefaultPaidAmountTypeDesc() {
		return defaultPaidAmountTypeDesc;
	}

	public void setDefaultPaidAmountTypeDesc(String defaultPaidAmountTypeDesc) {
		this.defaultPaidAmountTypeDesc = defaultPaidAmountTypeDesc;
	}
	
	public boolean isDisplayDept() {
		return displayDept;
	}

	public void setDisplayDept(boolean displayDept) {
		this.displayDept = displayDept;
	}

	public boolean isDisplayGroupRptg1Code() {
		return displayGroupRptg1Code;
	}

	public void setDisplayGroupRptg1Code(boolean displayGroupRptg1Code) {
		this.displayGroupRptg1Code = displayGroupRptg1Code;
	}

	public boolean isDisplayGroupRptg2Code() {
		return displayGroupRptg2Code;
	}

	public void setDisplayGroupRptg2Code(boolean displayGroupRptg2Code) {
		this.displayGroupRptg2Code = displayGroupRptg2Code;
	}

	public boolean isDisplayGroupRptg3Code() {
		return displayGroupRptg3Code;
	}

	public void setDisplayGroupRptg3Code(boolean displayGroupRptg3Code) {
		this.displayGroupRptg3Code = displayGroupRptg3Code;
	}

	public boolean isDisplayRlup1Code() {
		return displayRlup1Code;
	}

	public void setDisplayRlup1Code(boolean displayRlup1Code) {
		this.displayRlup1Code = displayRlup1Code;
	}

	public boolean isDisplayRlup2Code() {
		return displayRlup2Code;
	}

	public void setDisplayRlup2Code(boolean displayRlup2Code) {
		this.displayRlup2Code = displayRlup2Code;
	}

	public boolean isDisplayRlup3Code() {
		return displayRlup3Code;
	}

	public void setDisplayRlup3Code(boolean displayRlup3Code) {
		this.displayRlup3Code = displayRlup3Code;
	}

	public boolean isDisplayRlup4Code() {
		return displayRlup4Code;
	}

	public void setDisplayRlup4Code(boolean displayRlup4Code) {
		this.displayRlup4Code = displayRlup4Code;
	}

	public boolean isDisplayStatus() {
		return displayStatus;
	}

	public void setDisplayStatus(boolean displayStatus) {
		this.displayStatus = displayStatus;
	}

	public String getSecurityCode() {
		return securityCode;
	}

	public Integer getAccountPlanMonthNbr() {
		return accountPlanMonthNbr;
	}

	public void setAccountPlanMonthNbr(Integer accountPlanMonthNbr) {
		this.accountPlanMonthNbr = accountPlanMonthNbr;
	}

	public String getAccountSizeClassificationnCode() {
		return accountSizeClassificationnCode;
	}

	public void setAccountSizeClassificationnCode(String accountSizeClassificationnCode) {
		this.accountSizeClassificationnCode = accountSizeClassificationnCode;
	}

	public Integer getAccountDefaultRnoutMonthNbr() {
		return accountDefaultRnoutMonthNbr;
	}

	public void setAccountDefaultRnoutMonthNbr(Integer accountDefaultRnoutMonthNbr) {
		this.accountDefaultRnoutMonthNbr = accountDefaultRnoutMonthNbr;
	}

	public String getAccountDefaultTmProdCode() {
		return accountDefaultTmProdCode;
	}

	public void setAccountDefaultTmProdCode(String accountDefaultTmProdCode) {
		this.accountDefaultTmProdCode = accountDefaultTmProdCode;
	}

	public String getRptgBrandLogoCd() {
		return rptgBrandLogoCd;
	}

	public void setRptgBrandLogoCd(String rptgBrandLogoCd) {
		this.rptgBrandLogoCd = rptgBrandLogoCd;
	}

	public String getAccount_3061_ind() {
		return account_3061_ind;
	}

	public void setAccount_3061_ind(String account_3061_ind) {
		this.account_3061_ind = account_3061_ind;
	}

	public String getPaidOrIncured() {
		return paidOrIncured;
	}

	public void setPaidOrIncured(String paidOrIncured) {
		this.paidOrIncured = paidOrIncured;
	}

	public String getLastCompleteMonthLoaded() {
		return lastCompleteMonthLoaded;
	}

	public void setLastCompleteMonthLoaded(String lastCompleteMonthLoaded) {
		this.lastCompleteMonthLoaded = lastCompleteMonthLoaded;
	}

	public String getDefaultMembershipBenchmark1Value() {
		return defaultMembershipBenchmark1Value;
	}

	public void setDefaultMembershipBenchmark1Value(String defaultMembershipBenchmark1Value) {
		this.defaultMembershipBenchmark1Value = defaultMembershipBenchmark1Value;
	}

	public String getDefaultClinicalBenchmark1Value() {
		return defaultClinicalBenchmark1Value;
	}

	public void setDefaultClinicalBenchmark1Value(String defaultClinicalBenchmark1Value) {
		this.defaultClinicalBenchmark1Value = defaultClinicalBenchmark1Value;
	}

	public String getDefaultCondDriverBenchmark1Value() {
		return defaultCondDriverBenchmark1Value;
	}

	public void setDefaultCondDriverBenchmark1Value(String defaultCondDriverBenchmark1Value) {
		this.defaultCondDriverBenchmark1Value = defaultCondDriverBenchmark1Value;
	}

	public String getDefaultCostUtilBenchmark1Value() {
		return defaultCostUtilBenchmark1Value;
	}

	public void setDefaultCostUtilBenchmark1Value(String defaultCostUtilBenchmark1Value) {
		this.defaultCostUtilBenchmark1Value = defaultCostUtilBenchmark1Value;
	}

	public String getDefaultProvNtwkBenchmark1Value() {
		return defaultProvNtwkBenchmark1Value;
	}

	public void setDefaultProvNtwkBenchmark1Value(String defaultProvNtwkBenchmark1Value) {
		this.defaultProvNtwkBenchmark1Value = defaultProvNtwkBenchmark1Value;
	}

	public String getDefaultSpcltyBenchmark1Value() {
		return defaultSpcltyBenchmark1Value;
	}

	public void setDefaultSpcltyBenchmark1Value(String defaultSpcltyBenchmark1Value) {
		this.defaultSpcltyBenchmark1Value = defaultSpcltyBenchmark1Value;
	}

}
