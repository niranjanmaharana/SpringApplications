package com.anthem.aciisst.account.web.view.response;

public class AccountStructureRequest {
	private String userId;
	private String sessionKey;
	private String accountId;
	private String groups;
	private String products;
	private String subGroups;
	private String packages;
	private String status;
	private String subGroupRollup1;
	private String subGroupRollup2;
	private String subGroupRollup3;
	private String subGroupRollup4;
	private String employerGroupReporting1;
	private String employerGroupReporting2;
	private String employerGroupReporting3;
	private String departments;
	
	public String getPackages() {
		return packages;
	}
	public void setPackages(String packages) {
		this.packages = packages;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSubGroupRollup1() {
		return subGroupRollup1;
	}
	public void setSubGroupRollup1(String subGroupRollup1) {
		this.subGroupRollup1 = subGroupRollup1;
	}
	public String getSubGroupRollup2() {
		return subGroupRollup2;
	}
	public void setSubGroupRollup2(String subGroupRollup2) {
		this.subGroupRollup2 = subGroupRollup2;
	}
	public String getSubGroupRollup3() {
		return subGroupRollup3;
	}
	public void setSubGroupRollup3(String subGroupRollup3) {
		this.subGroupRollup3 = subGroupRollup3;
	}
	public String getSubGroupRollup4() {
		return subGroupRollup4;
	}
	public void setSubGroupRollup4(String subGroupRollup4) {
		this.subGroupRollup4 = subGroupRollup4;
	}
	public String getEmployerGroupReporting1() {
		return employerGroupReporting1;
	}
	public void setEmployerGroupReporting1(String employerGroupReporting1) {
		this.employerGroupReporting1 = employerGroupReporting1;
	}
	public String getEmployerGroupReporting2() {
		return employerGroupReporting2;
	}
	public void setEmployerGroupReporting2(String employerGroupReporting2) {
		this.employerGroupReporting2 = employerGroupReporting2;
	}
	public String getEmployerGroupReporting3() {
		return employerGroupReporting3;
	}
	public void setEmployerGroupReporting3(String employerGroupReporting3) {
		this.employerGroupReporting3 = employerGroupReporting3;
	}
	public String getDepartments() {
		return departments;
	}
	public void setDepartments(String departments) {
		this.departments = departments;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getSessionKey() {
		return sessionKey;
	}
	public void setSessionKey(String sessionKey) {
		this.sessionKey = sessionKey;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getProducts() {
		return products;
	}
	public void setProducts(String products) {
		this.products = products;
	}
	
	@Override
	public String toString() {
		return "AccountStructureRequest [userId=" + userId + ", sessionKey=" + sessionKey + ", accountId=" + accountId
				+ ", groupIds=" + groups + ", products=" + products + ", subgroups=" + subGroups + ", packages="
				+ packages + ", status=" + status + ", subGroupRollup1=" + subGroupRollup1 + ", subGroupRollup2="
				+ subGroupRollup2 + ", subGroupRollup3=" + subGroupRollup3 + ", subGroupRollup4=" + subGroupRollup4
				+ ", employerGroupReporting1=" + employerGroupReporting1 + ", employerGroupReporting2="
				+ employerGroupReporting2 + ", employerGroupReporting3=" + employerGroupReporting3 + ", departments="
				+ departments + "]";
	}
	public String getGroups() {
		return groups;
	}
	public void setGroups(String groups) {
		this.groups = groups;
	}
	public String getSubGroups() {
		return subGroups;
	}
	public void setSubGroups(String subGroups) {
		this.subGroups = subGroups;
	}
}
