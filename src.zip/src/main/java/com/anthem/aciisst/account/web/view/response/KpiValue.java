package com.anthem.aciisst.account.web.view.response;

public class KpiValue {

	private String key;
	private String value;
	private String description;
	private String symbol;
	private String curr_data;
	private String prior1_data;
	private String prior2_data;
	
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getCurr_data() {
		return curr_data;
	}
	public void setCurr_data(String curr_data) {
		this.curr_data = curr_data;
	}
	public String getPrior1_data() {
		return prior1_data;
	}
	public void setPrior1_data(String prior1_data) {
		this.prior1_data = prior1_data;
	}
	public String getPrior2_data() {
		return prior2_data;
	}
	public void setPrior2_data(String prior2_data) {
		this.prior2_data = prior2_data;
	}

}
