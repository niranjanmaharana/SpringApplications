package com.anthem.aciisst.account.web.view.response;

public class AccountStructureDisplayValueDTO {
	private String groups;
	private String products;
	private String subGroups;
	private String packages;
	private String status;
	private String subGroupRollup1;
	private String subGroupRollup2;
	private String subGroupRollup3;
	private String subGroupRollup4;
	private String employerGroupReporting1;
	private String employerGroupReporting2;
	private String employerGroupReporting3;
	private String departments;
	private String timeperiodType;
	private String runOutMonthValue;
	private String numberoftimeperiod;
	private String hccThreshold;
	private String paidTypeValue;
	private String currentPeriodStart;
	private String currentPeriodEnd;
	private String priorPeriod1Start;
	private String priorPeriod1End;
	private String priorPeriod2Start;
	private String priorPeriod2End;
	
	public String getGroups() {
		return groups;
	}
	public void setGroups(String groups) {
		this.groups = groups;
	}
	public String getProducts() {
		return products;
	}
	public void setProducts(String products) {
		this.products = products;
	}
	public String getSubGroups() {
		return subGroups;
	}
	public void setSubGroups(String subGroups) {
		this.subGroups = subGroups;
	}
	public String getPackages() {
		return packages;
	}
	public void setPackages(String packages) {
		this.packages = packages;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSubGroupRollup1() {
		return subGroupRollup1;
	}
	public void setSubGroupRollup1(String subGroupRollup1) {
		this.subGroupRollup1 = subGroupRollup1;
	}
	public String getSubGroupRollup2() {
		return subGroupRollup2;
	}
	public void setSubGroupRollup2(String subGroupRollup2) {
		this.subGroupRollup2 = subGroupRollup2;
	}
	public String getSubGroupRollup3() {
		return subGroupRollup3;
	}
	public void setSubGroupRollup3(String subGroupRollup3) {
		this.subGroupRollup3 = subGroupRollup3;
	}
	public String getSubGroupRollup4() {
		return subGroupRollup4;
	}
	public void setSubGroupRollup4(String subGroupRollup4) {
		this.subGroupRollup4 = subGroupRollup4;
	}
	public String getEmployerGroupReporting1() {
		return employerGroupReporting1;
	}
	public void setEmployerGroupReporting1(String employerGroupReporting1) {
		this.employerGroupReporting1 = employerGroupReporting1;
	}
	public String getEmployerGroupReporting2() {
		return employerGroupReporting2;
	}
	public void setEmployerGroupReporting2(String employerGroupReporting2) {
		this.employerGroupReporting2 = employerGroupReporting2;
	}
	public String getEmployerGroupReporting3() {
		return employerGroupReporting3;
	}
	public void setEmployerGroupReporting3(String employerGroupReporting3) {
		this.employerGroupReporting3 = employerGroupReporting3;
	}
	public String getDepartments() {
		return departments;
	}
	public void setDepartments(String departments) {
		this.departments = departments;
	}
	public String getRunOutMonthValue() {
		return runOutMonthValue;
	}
	public void setRunOutMonthValue(String runOutMonthValue) {
		this.runOutMonthValue = runOutMonthValue;
	}
	public String getHccThreshold() {
		return hccThreshold;
	}
	public void setHccThreshold(String hccThreshold) {
		this.hccThreshold = hccThreshold;
	}
	public String getPaidTypeValue() {
		return paidTypeValue;
	}
	public void setPaidTypeValue(String paidTypeValue) {
		this.paidTypeValue = paidTypeValue;
	}
	public String getTimeperiodType() {
		return timeperiodType;
	}
	public void setTimeperiodType(String timeperiodType) {
		this.timeperiodType = timeperiodType;
	}
	public String getNumberoftimeperiod() {
		return numberoftimeperiod;
	}
	public void setNumberoftimeperiod(String numberoftimeperiod) {
		this.numberoftimeperiod = numberoftimeperiod;
	}
	public String getCurrentPeriodStart() {
		return currentPeriodStart;
	}
	public void setCurrentPeriodStart(String currentPeriodStart) {
		this.currentPeriodStart = currentPeriodStart;
	}
	public String getCurrentPeriodEnd() {
		return currentPeriodEnd;
	}
	public void setCurrentPeriodEnd(String currentPeriodEnd) {
		this.currentPeriodEnd = currentPeriodEnd;
	}
	public String getPriorPeriod1Start() {
		return priorPeriod1Start;
	}
	public void setPriorPeriod1Start(String priorPeriod1Start) {
		this.priorPeriod1Start = priorPeriod1Start;
	}
	public String getPriorPeriod1End() {
		return priorPeriod1End;
	}
	public void setPriorPeriod1End(String priorPeriod1End) {
		this.priorPeriod1End = priorPeriod1End;
	}
	public String getPriorPeriod2Start() {
		return priorPeriod2Start;
	}
	public void setPriorPeriod2Start(String priorPeriod2Start) {
		this.priorPeriod2Start = priorPeriod2Start;
	}
	public String getPriorPeriod2End() {
		return priorPeriod2End;
	}
	public void setPriorPeriod2End(String priorPeriod2End) {
		this.priorPeriod2End = priorPeriod2End;
	}
}
