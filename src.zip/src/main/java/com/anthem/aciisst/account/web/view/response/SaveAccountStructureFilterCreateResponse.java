package com.anthem.aciisst.account.web.view.response;

public class SaveAccountStructureFilterCreateResponse {
	private int id;

	
	public SaveAccountStructureFilterCreateResponse(int id) {
		super();
		this.id = id;
	}
	public SaveAccountStructureFilterCreateResponse(){
		
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

}
