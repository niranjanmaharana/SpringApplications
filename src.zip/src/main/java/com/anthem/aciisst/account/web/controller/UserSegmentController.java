package com.anthem.aciisst.account.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.aciisst.account.service.UserSegmentService;
import com.anthem.aciisst.account.web.view.response.BaseAccountStructureDTO;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.LogDetail;
import com.anthem.aciisst.common.util.LoggingUtil;

@CrossOrigin
@RestController
public class UserSegmentController {

	@Autowired
	UserSegmentService userSegmentService;

	@RequestMapping(method = RequestMethod.DELETE, value = "/userSegment")
	public void deleteUserSegment(@RequestBody BaseAccountStructureDTO accout, HttpServletRequest httpRequest) {
		
		try {
			userSegmentService.deleteFromUserSegment(accout.getSessionKey(), Integer.valueOf(accout.getUserId()));
		} catch (Exception e) {
			
			LogDetail logDetail = new LogDetail();
			logDetail.setAccountId(accout.getAccountId());
			logDetail.setUserId( accout.getUserId());
			logDetail.setUri("addReportRunDate()");
			logDetail.setSystem(ACIISSTConstants.SYSTEM);
			LoggingUtil.logError(this.getClass(),logDetail, e);
			

		}
	}

}
