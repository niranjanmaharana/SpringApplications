package com.anthem.aciisst.account.web.view.request;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class SaveAccountStructureFilterRequest {
	private String accountId;
	
	@JsonIgnore
	private int aciisstUserId;

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public int getAciisstUserId() {
		return aciisstUserId;
	}

	public void setAciisstUserId(int aciisstUserId) {
		this.aciisstUserId = aciisstUserId;
	}

}
