package com.anthem.aciisst.account.web.view.response;

public class SegmentKeyDTO {
private int key;

public int getKey() {
	return key;
}

public void setKey(int key) {
	this.key = key;
}

}
