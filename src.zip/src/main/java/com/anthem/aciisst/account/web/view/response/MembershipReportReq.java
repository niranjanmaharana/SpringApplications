package com.anthem.aciisst.account.web.view.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class MembershipReportReq extends BaseAccountStructureDTO {
	private String reportType;
	private String currentPeriodStart;
	private String currentPeriodEnd;
	private String priorPeriod1Start;
	private String priorPeriod1End;
	private String priortPeriod2Start;
	private String priorPeriod2End;
	private String tierLevel;	
	private String timePeriodType;
	private List<String> coverage;
	private List<String> ageBand;
	private List<String> gender;
	private List<String> relationship;
	private List<String> healthStatus;
	private List<String> engagement;
	
	private List<String> msa;
	private List<String> state;
	private List<String> hcc;
	private List<String> hiddenMedicalColumns;
	private List<String> hiddenPharmacyColumns;
	
	@JsonIgnore
	private String coverageType;
	@JsonIgnore
	private List<String> coverageTypeList;
	
	
	public List<String> getHcc() {
		return hcc;
	}
	public void setHcc(List<String> hcc) {
		this.hcc = hcc;
	}
	public String getTimePeriodType() {
		return timePeriodType;
	}
	public void setTimePeriodType(String timePeriodType) {
		this.timePeriodType = timePeriodType;
	}

	public String getCoverageType() {
		return coverageType;
	}
	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}
	public String getReportType() {
		return reportType;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	public String getCurrentPeriodStart() {
		return currentPeriodStart;
	}
	public void setCurrentPeriodStart(String currentPeriodStart) {
		this.currentPeriodStart = currentPeriodStart;
	}
	public String getCurrentPeriodEnd() {
		return currentPeriodEnd;
	}
	public void setCurrentPeriodEnd(String currentPeriodEnd) {
		this.currentPeriodEnd = currentPeriodEnd;
	}
	public String getPriorPeriod1Start() {
		return priorPeriod1Start;
	}
	public void setPriorPeriod1Start(String priorPeriod1Start) {
		this.priorPeriod1Start = priorPeriod1Start;
	}
	public String getPriorPeriod1End() {
		return priorPeriod1End;
	}
	public void setPriorPeriod1End(String priorPeriod1End) {
		this.priorPeriod1End = priorPeriod1End;
	}
	public String getPriortPeriod2Start() {
		return priortPeriod2Start;
	}
	public void setPriortPeriod2Start(String priortPeriod2Start) {
		this.priortPeriod2Start = priortPeriod2Start;
	}
	public String getPriorPeriod2End() {
		return priorPeriod2End;
	}
	public void setPriorPeriod2End(String priorPeriod2End) {
		this.priorPeriod2End = priorPeriod2End;
	}
	public String getTierLevel() {
		return tierLevel;
	}
	public void setTierLevel(String tierLevel) {
		this.tierLevel = tierLevel;
	}
	public List<String> getCoverage() {
		return coverage;
	}
	public void setCoverage(List<String> coverage) {
		this.coverage = coverage;
	}
	public List<String> getAgeBand() {
		return ageBand;
	}
	public void setAgeBand(List<String> ageBand) {
		this.ageBand = ageBand;
	}
	public List<String> getGender() {
		return gender;
	}
	public void setGender(List<String> gender) {
		this.gender = gender;
	}
	public List<String> getRelationship() {
		return relationship;
	}
	public void setRelationship(List<String> relationship) {
		this.relationship = relationship;
	}
	public List<String> getHealthStatus() {
		return healthStatus;
	}
	public void setHealthStatus(List<String> healthStatus) {
		this.healthStatus = healthStatus;
	}
	public List<String> getEngagement() {
		return engagement;
	}
	public void setEngagement(List<String> engagement) {
		this.engagement = engagement;
	}
	public List<String> getMsa() {
		return msa;
	}
	public void setMsa(List<String> msa) {
		this.msa = msa;
	}
	public List<String> getState() {
		return state;
	}
	public void setState(List<String> state) {
		this.state = state;
	}
	public List<String> getHiddenMedicalColumns() {
		return hiddenMedicalColumns;
	}
	public void setHiddenMedicalColumns(List<String> hiddenMedicalColumns) {
		this.hiddenMedicalColumns = hiddenMedicalColumns;
	}
	public List<String> getHiddenPharmacyColumns() {
		return hiddenPharmacyColumns;
	}
	public void setHiddenPharmacyColumns(List<String> hiddenPharmacyColumns) {
		this.hiddenPharmacyColumns = hiddenPharmacyColumns;
	}
	
	
	

}
