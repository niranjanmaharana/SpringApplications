package com.anthem.aciisst.account.web.view.request;

import java.util.List;

public class SaveAccountStructureFilterCreateRequest extends SaveAccountStructureFilterRequest{
	private String name;
	private String description;
	private String type;
	
	private List<CodeAndDescriptionRequestView> groups;
	private List<CodeAndDescriptionRequestView> subGroups;
	private List<CodeAndDescriptionRequestView> products;
	private List<CodeAndDescriptionRequestView> packages;
	private List<CodeAndDescriptionRequestView> departments;
	private List<CodeAndDescriptionRequestView> status;
	private List<CodeAndDescriptionRequestView> subGroupRollup1;
	private List<CodeAndDescriptionRequestView> subGroupRollup2;
	private List<CodeAndDescriptionRequestView> subGroupRollup3;
	private List<CodeAndDescriptionRequestView> subGroupRollup4;
	private List<CodeAndDescriptionRequestView> employerGroupReporting1;
	private List<CodeAndDescriptionRequestView> employerGroupReporting2;
	private List<CodeAndDescriptionRequestView> employerGroupReporting3;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<CodeAndDescriptionRequestView> getGroups() {
		return groups;
	}
	public void setGroups(List<CodeAndDescriptionRequestView> groups) {
		this.groups = groups;
	}
	public List<CodeAndDescriptionRequestView> getSubGroups() {
		return subGroups;
	}
	public void setSubGroups(List<CodeAndDescriptionRequestView> subGroups) {
		this.subGroups = subGroups;
	}
	public List<CodeAndDescriptionRequestView> getProducts() {
		return products;
	}
	public void setProducts(List<CodeAndDescriptionRequestView> products) {
		this.products = products;
	}
	public List<CodeAndDescriptionRequestView> getPackages() {
		return packages;
	}
	public void setPackages(List<CodeAndDescriptionRequestView> packages) {
		this.packages = packages;
	}
	public List<CodeAndDescriptionRequestView> getDepartments() {
		return departments;
	}
	public void setDepartments(List<CodeAndDescriptionRequestView> departments) {
		this.departments = departments;
	}
	public List<CodeAndDescriptionRequestView> getStatus() {
		return status;
	}
	public void setStatus(List<CodeAndDescriptionRequestView> status) {
		this.status = status;
	}
	public List<CodeAndDescriptionRequestView> getSubGroupRollup1() {
		return subGroupRollup1;
	}
	public void setSubGroupRollup1(List<CodeAndDescriptionRequestView> subGroupRollup1) {
		this.subGroupRollup1 = subGroupRollup1;
	}
	public List<CodeAndDescriptionRequestView> getSubGroupRollup2() {
		return subGroupRollup2;
	}
	public void setSubGroupRollup2(List<CodeAndDescriptionRequestView> subGroupRollup2) {
		this.subGroupRollup2 = subGroupRollup2;
	}
	public List<CodeAndDescriptionRequestView> getSubGroupRollup3() {
		return subGroupRollup3;
	}
	public void setSubGroupRollup3(List<CodeAndDescriptionRequestView> subGroupRollup3) {
		this.subGroupRollup3 = subGroupRollup3;
	}
	public List<CodeAndDescriptionRequestView> getSubGroupRollup4() {
		return subGroupRollup4;
	}
	public void setSubGroupRollup4(List<CodeAndDescriptionRequestView> subGroupRollup4) {
		this.subGroupRollup4 = subGroupRollup4;
	}
	public List<CodeAndDescriptionRequestView> getEmployerGroupReporting1() {
		return employerGroupReporting1;
	}
	public void setEmployerGroupReporting1(List<CodeAndDescriptionRequestView> employerGroupReporting1) {
		this.employerGroupReporting1 = employerGroupReporting1;
	}
	public List<CodeAndDescriptionRequestView> getEmployerGroupReporting2() {
		return employerGroupReporting2;
	}
	public void setEmployerGroupReporting2(List<CodeAndDescriptionRequestView> employerGroupReporting2) {
		this.employerGroupReporting2 = employerGroupReporting2;
	}
	public List<CodeAndDescriptionRequestView> getEmployerGroupReporting3() {
		return employerGroupReporting3;
	}
	public void setEmployerGroupReporting3(List<CodeAndDescriptionRequestView> employerGroupReporting3) {
		this.employerGroupReporting3 = employerGroupReporting3;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}
