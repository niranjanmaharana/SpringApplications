package com.anthem.aciisst.account.web.view.response;

import java.util.ArrayList;
import java.util.List;

import com.anthem.aciisst.common.valueObject.CodeAndDescription;

public class SaveAccountStructureFilterResponse {
	private int id;
	private String name;
	private String description;
	private String type;
	private boolean active;
	private String accountId;
	
	private List<CodeAndDescription> groups = new ArrayList<>();
	private List<CodeAndDescription> subGroups = new ArrayList<>();
	private List<CodeAndDescription> products = new ArrayList<>();
	private List<CodeAndDescription> packages = new ArrayList<>();
	private List<CodeAndDescription> departments = new ArrayList<>();
	private List<CodeAndDescription> status = new ArrayList<>();
	private List<CodeAndDescription> subGroupRollup1 = new ArrayList<>();
	private List<CodeAndDescription> subGroupRollup2 = new ArrayList<>();
	private List<CodeAndDescription> subGroupRollup3 = new ArrayList<>();
	private List<CodeAndDescription> subGroupRollup4 = new ArrayList<>();
	private List<CodeAndDescription> employerGroupReporting1 = new ArrayList<>();
	private List<CodeAndDescription> employerGroupReporting2 = new ArrayList<>();
	private List<CodeAndDescription> employerGroupReporting3 = new ArrayList<>();
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public List<CodeAndDescription> getGroups() {
		return groups;
	}
	public void setGroups(List<CodeAndDescription> groups) {
		this.groups = groups;
	}
	public List<CodeAndDescription> getSubGroups() {
		return subGroups;
	}
	public void setSubGroups(List<CodeAndDescription> subGroups) {
		this.subGroups = subGroups;
	}
	public List<CodeAndDescription> getProducts() {
		return products;
	}
	public void setProducts(List<CodeAndDescription> products) {
		this.products = products;
	}
	public List<CodeAndDescription> getPackages() {
		return packages;
	}
	public void setPackages(List<CodeAndDescription> packages) {
		this.packages = packages;
	}
	public List<CodeAndDescription> getDepartments() {
		return departments;
	}
	public void setDepartments(List<CodeAndDescription> departments) {
		this.departments = departments;
	}
	public List<CodeAndDescription> getStatus() {
		return status;
	}
	public void setStatus(List<CodeAndDescription> status) {
		this.status = status;
	}
	public List<CodeAndDescription> getSubGroupRollup1() {
		return subGroupRollup1;
	}
	public void setSubGroupRollup1(List<CodeAndDescription> subGroupRollup1) {
		this.subGroupRollup1 = subGroupRollup1;
	}
	public List<CodeAndDescription> getSubGroupRollup2() {
		return subGroupRollup2;
	}
	public void setSubGroupRollup2(List<CodeAndDescription> subGroupRollup2) {
		this.subGroupRollup2 = subGroupRollup2;
	}
	public List<CodeAndDescription> getSubGroupRollup3() {
		return subGroupRollup3;
	}
	public void setSubGroupRollup3(List<CodeAndDescription> subGroupRollup3) {
		this.subGroupRollup3 = subGroupRollup3;
	}
	public List<CodeAndDescription> getSubGroupRollup4() {
		return subGroupRollup4;
	}
	public void setSubGroupRollup4(List<CodeAndDescription> subGroupRollup4) {
		this.subGroupRollup4 = subGroupRollup4;
	}
	public List<CodeAndDescription> getEmployerGroupReporting1() {
		return employerGroupReporting1;
	}
	public void setEmployerGroupReporting1(List<CodeAndDescription> employerGroupReporting1) {
		this.employerGroupReporting1 = employerGroupReporting1;
	}
	public List<CodeAndDescription> getEmployerGroupReporting2() {
		return employerGroupReporting2;
	}
	public void setEmployerGroupReporting2(List<CodeAndDescription> employerGroupReporting2) {
		this.employerGroupReporting2 = employerGroupReporting2;
	}
	public List<CodeAndDescription> getEmployerGroupReporting3() {
		return employerGroupReporting3;
	}
	public void setEmployerGroupReporting3(List<CodeAndDescription> employerGroupReporting3) {
		this.employerGroupReporting3 = employerGroupReporting3;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	
	
}
