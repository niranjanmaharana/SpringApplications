package com.anthem.aciisst.account.web.view.response;

public class SessionKeyResponse {
private String sessionKey;

public String getSessionKey() {
	return sessionKey;
}

public void setSessionKey(String sessionKey) {
	this.sessionKey = sessionKey;
}
}
