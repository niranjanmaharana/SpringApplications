package com.anthem.aciisst.account.web.view.response;

public class KpiDTO extends BaseAccountStructureDTO{
	private String timePeriod;
	private String currentPeriodStart;
	private String currentPeriodEnd;	
	private String priorPeriod1Start;
	private String priorPeriod1End;
	private String priorPeriod2Start;
	private String priorPeriod2End;
	private String account_3061_ind;
	private String paidOrIncured;
	private String runOutMonths;
	private String lastCompleteMonthDate;
	private String numberoftimeperiod;
	private String currRptgStartDate;
	private String currRptgEndDate;
	private String prior1RptgStartDate;
	private String prior1RptgEndDate;
	private String prior2RptgStartDate;
	private String prior2RptgEndDate;

	
	
	public String getAccount_3061_ind() {
		return account_3061_ind;
	}

	public void setAccount_3061_ind(String account_3061_ind) {
		this.account_3061_ind = account_3061_ind;
	}

	public String getPaidOrIncured() {
		return paidOrIncured;
	}

	public void setPaidOrIncured(String paidOrIncured) {
		this.paidOrIncured = paidOrIncured;
	}

	public String getRunOutMonths() {
		return runOutMonths;
	}

	public void setRunOutMonths(String runOutMonths) {
		this.runOutMonths = runOutMonths;
	}

	public String getNumberoftimeperiod() {
		return numberoftimeperiod;
	}

	public void setNumberoftimeperiod(String numberoftimeperiod) {
		this.numberoftimeperiod = numberoftimeperiod;
	}

	int aciisstUserId;

	public String getTimePeriod() {
		return timePeriod;
	}

	public void setTimePeriod(String timePeriod) {
		this.timePeriod = timePeriod;
	}

	public String getCurrentPeriodStart() {
		return currentPeriodStart;
	}

	public void setCurrentPeriodStart(String currentPeriodStart) {
		this.currentPeriodStart = currentPeriodStart;
	}

	public String getCurrentPeriodEnd() {
		return currentPeriodEnd;
	}

	public void setCurrentPeriodEnd(String currentPeriodEnd) {
		this.currentPeriodEnd = currentPeriodEnd;
	}

	public String getPriorPeriod1Start() {
		return priorPeriod1Start;
	}

	public void setPriorPeriod1Start(String priorPeriod1Start) {
		this.priorPeriod1Start = priorPeriod1Start;
	}

	public String getPriorPeriod1End() {
		return priorPeriod1End;
	}

	public void setPriorPeriod1End(String priorPeriod1End) {
		this.priorPeriod1End = priorPeriod1End;
	}

	public String getPriorPeriod2Start() {
		return priorPeriod2Start;
	}

	public void setPriorPeriod2Start(String priorPeriod2Start) {
		this.priorPeriod2Start = priorPeriod2Start;
	}

	public String getPriorPeriod2End() {
		return priorPeriod2End;
	}

	public void setPriorPeriod2End(String priorPeriod2End) {
		this.priorPeriod2End = priorPeriod2End;
	}
	
	public int getAciisstUserId() {
		return aciisstUserId;
	}

	public void setAciisstUserId(int aciisstUserId) {
		this.aciisstUserId = aciisstUserId;
	}
	public String getCurrRptgStartDate() {
		return currRptgStartDate;
	}

	public void setCurrRptgStartDate(String currRptgStartDate) {
		this.currRptgStartDate = currRptgStartDate;
	}

	public String getCurrRptgEndDate() {
		return currRptgEndDate;
	}

	public void setCurrRptgEndDate(String currRptgEndDate) {
		this.currRptgEndDate = currRptgEndDate;
	}

	public String getPrior1RptgStartDate() {
		return prior1RptgStartDate;
	}

	public void setPrior1RptgStartDate(String prior1RptgStartDate) {
		this.prior1RptgStartDate = prior1RptgStartDate;
	}

	public String getPrior1RptgEndDate() {
		return prior1RptgEndDate;
	}

	public void setPrior1RptgEndDate(String prior1RptgEndDate) {
		this.prior1RptgEndDate = prior1RptgEndDate;
	}

	public String getPrior2RptgStartDate() {
		return prior2RptgStartDate;
	}

	public void setPrior2RptgStartDate(String prior2RptgStartDate) {
		this.prior2RptgStartDate = prior2RptgStartDate;
	}

	public String getPrior2RptgEndDate() {
		return prior2RptgEndDate;
	}

	public void setPrior2RptgEndDate(String prior2RptgEndDate) {
		this.prior2RptgEndDate = prior2RptgEndDate;
	}

	public String getLastCompleteMonthDate() {
		return lastCompleteMonthDate;
	}

	public void setLastCompleteMonthDate(String lastCompleteMonthDate) {
		this.lastCompleteMonthDate = lastCompleteMonthDate;
	}


	
}
