package com.anthem.aciisst.account.web.view.response;

public class AccountStructureFilterResponseView {
	private String code;
	private String description;
	
	public AccountStructureFilterResponseView(String code, String description) {
		super();
		this.code = code;
		this.description = description;
	}
	public AccountStructureFilterResponseView() {
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
