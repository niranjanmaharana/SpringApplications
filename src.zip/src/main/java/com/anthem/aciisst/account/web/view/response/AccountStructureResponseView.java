package com.anthem.aciisst.account.web.view.response;

public class AccountStructureResponseView {
	private int segmentKey;
	private String groupId;
	private String groupName;
	private String empDprtNbr;
	private String planId;
	private String subGrpId;
	private String productCode;
	private String  grpSttsCode;
	private String subGrpRulp1;
	private String subGrpRulp2;
	private String subGrpRulp3;
	private String subGrpRulp4;
	private Character subGrpRulpStts1;
	private Character subGrpRulpStts2;
	private Character subGrpRulpStts3;
	private Character subGrpRulpStts4;
	private String empGrpReporting1;
	private String empGrpReporting2;
	private String empGrpReporting3;
	public int getSegmentKey() {
		return segmentKey;
	}
	public void setSegmentKey(int segmentKey) {
		this.segmentKey = segmentKey;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getEmpDprtNbr() {
		return empDprtNbr;
	}
	public void setEmpDprtNbr(String empDprtNbr) {
		this.empDprtNbr = empDprtNbr;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getSubGrpId() {
		return subGrpId;
	}
	public void setSubGrpId(String subGrpId) {
		this.subGrpId = subGrpId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getGrpSttsCode() {
		return grpSttsCode;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public void setGrpSttsCode(String grpSttsCode) {
		this.grpSttsCode = grpSttsCode;
	}
	public String getSubGrpRulp1() {
		return subGrpRulp1;
	}
	public void setSubGrpRulp1(String subGrpRulp1) {
		this.subGrpRulp1 = subGrpRulp1;
	}
	public String getSubGrpRulp2() {
		return subGrpRulp2;
	}
	public void setSubGrpRulp2(String subGrpRulp2) {
		this.subGrpRulp2 = subGrpRulp2;
	}
	public String getSubGrpRulp3() {
		return subGrpRulp3;
	}
	public void setSubGrpRulp3(String subGrpRulp3) {
		this.subGrpRulp3 = subGrpRulp3;
	}
	public String getSubGrpRulp4() {
		return subGrpRulp4;
	}
	public void setSubGrpRulp4(String subGrpRulp4) {
		this.subGrpRulp4 = subGrpRulp4;
	}
	public Character getSubGrpRulpStts1() {
		return subGrpRulpStts1;
	}
	public void setSubGrpRulpStts1(Character subGrpRulpStts1) {
		this.subGrpRulpStts1 = subGrpRulpStts1;
	}
	public Character getSubGrpRulpStts2() {
		return subGrpRulpStts2;
	}
	public void setSubGrpRulpStts2(Character subGrpRulpStts2) {
		this.subGrpRulpStts2 = subGrpRulpStts2;
	}
	public Character getSubGrpRulpStts3() {
		return subGrpRulpStts3;
	}
	public void setSubGrpRulpStts3(Character subGrpRulpStts3) {
		this.subGrpRulpStts3 = subGrpRulpStts3;
	}
	public Character getSubGrpRulpStts4() {
		return subGrpRulpStts4;
	}
	public void setSubGrpRulpStts4(Character subGrpRulpStts4) {
		this.subGrpRulpStts4 = subGrpRulpStts4;
	}
	public String getEmpGrpReporting1() {
		return empGrpReporting1;
	}
	public void setEmpGrpReporting1(String empGrpReporting1) {
		this.empGrpReporting1 = empGrpReporting1;
	}
	public String getEmpGrpReporting2() {
		return empGrpReporting2;
	}
	public void setEmpGrpReporting2(String empGrpReporting2) {
		this.empGrpReporting2 = empGrpReporting2;
	}
	public String getEmpGrpReporting3() {
		return empGrpReporting3;
	}
	public void setEmpGrpReporting3(String empGrpReporting3) {
		this.empGrpReporting3 = empGrpReporting3;
	}
	
	
}
