package com.anthem.aciisst.account.web.view.response;

import java.util.List;

public class ComparitiveIdentifierFilterResponseView {
	
	private List<FeildValueDTO> hcc;
	private List<FeildValueDTO> coverage;
	private List<FeildValueDTO> ageBand;
	private List<FeildValueDTO> gender;
	private List<FeildValueDTO> relationship;
	private List<FeildValueDTO> healthStatus;
	private List<FeildValueDTO> engagement;
	private List<FeildValueDTO> msa;
	private List<FeildValueDTO> state;
	private List<FeildValueDTO> membershipBenchmark;
	
	
	
	public List<FeildValueDTO> getCoverage() {
		return coverage;
	}
	public void setCoverage(List<FeildValueDTO> coverage) {
		this.coverage = coverage;
	}
	public List<FeildValueDTO> getHcc() {
		return hcc;
	}
	public void setHcc(List<FeildValueDTO> hcc) {
		this.hcc = hcc;
	}
	public List<FeildValueDTO> getAgeBand() {
		return ageBand;
	}
	public void setAgeBand(List<FeildValueDTO> ageBand) {
		this.ageBand = ageBand;
	}
	public List<FeildValueDTO> getGender() {
		return gender;
	}
	public void setGender(List<FeildValueDTO> gender) {
		this.gender=gender;
		
	}
	public List<FeildValueDTO> getRelationship() {
		return relationship;
	}
	public void setRelationship(List<FeildValueDTO> relationship) {
		this.relationship = relationship;
	}
	public List<FeildValueDTO> getHealthStatus() {
		return healthStatus;
	}
	public void setHealthStatus(List<FeildValueDTO> healthStatus) {
		this.healthStatus=healthStatus;
	}
	public List<FeildValueDTO> getEngagement() {
		return engagement;
	}
	public void setEngagement(List<FeildValueDTO> engagement) {
		this.engagement = engagement;
	}
	public List<FeildValueDTO> getMsa() {
		return msa;
	}
	public void setMsa(List<FeildValueDTO> msa) {
		this.msa = msa;
	}
	public List<FeildValueDTO> getState() {
		return state;
	}
	public void setState(List<FeildValueDTO> state) {
		this.state = state;
	}
	public List<FeildValueDTO> getMembershipBenchmark() {
		return membershipBenchmark;
	}
	public void setMembershipBenchmark(List<FeildValueDTO> membershipBenchmark) {
		this.membershipBenchmark = membershipBenchmark;
	}
	
	

}
