package com.anthem.aciisst.account.web.view.response;

public class KpiResponse {
private KpiValue financial;

private KpiValue clinical;

private KpiValue provider;

public KpiValue getClinical() {
	return clinical;
}

public void setClinical(KpiValue clinical) {
	this.clinical = clinical;
}

public KpiValue getProvider() {
	return provider;
}

public void setProvider(KpiValue provider) {
	this.provider = provider;
}


public KpiValue getFinancial() {
	return financial;
}

public void setFinancial(KpiValue financial) {
	this.financial = financial;
}
}
