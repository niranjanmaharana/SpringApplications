package com.anthem.aciisst.account.web.view.response;

public class TimePeriodFilterRequest extends BaseAccountStructureDTO{
	private String numberoftimeperiod;
	private String timeperiodType;
	private String currentPeriodEnd;
	private String paidOrIncured;
	private String runOutMonths;
	private String account_3061_ind;
	private String kpiInd = "N" ; // this is for KPI
	
	public String getPaidOrIncured() {
		return paidOrIncured;
	}
	public void setPaidOrIncured(String paidOrIncured) {
		this.paidOrIncured = paidOrIncured;
	}
	public String getRunOutMonths() {
		return runOutMonths;
	}
	public void setRunOutMonths(String runOutMonths) {
		this.runOutMonths = runOutMonths;
	}
	
	public String getAccount_3061_ind() {
		return account_3061_ind;
	}
	public void setAccount_3061_ind(String account_3061_ind) {
		this.account_3061_ind = account_3061_ind;
	}
	public String getNumberoftimeperiod() {
		return numberoftimeperiod;
	}
	public void setNumberoftimeperiod(String numberoftimeperiod) {
		this.numberoftimeperiod = numberoftimeperiod;
	}
	public String getTimeperiodType() {
		return timeperiodType;
	}
	public void setTimeperiodType(String timeperiodType) {
		this.timeperiodType = timeperiodType;
	}
	public String getCurrentPeriodEnd() {
		return currentPeriodEnd;
	}
	public void setCurrentPeriodEnd(String currentPeriodEnd) {
		this.currentPeriodEnd = currentPeriodEnd;
	}
	public String getKpiInd() {
		return kpiInd;
	}
	public void setKpiInd(String kpiInd) {
		this.kpiInd = kpiInd;
	}
	
}
