package com.anthem.aciisst.account.service;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.anthem.aciisst.account.web.view.request.CodeAndDescriptionRequestView;
import com.anthem.aciisst.account.web.view.request.SaveAccountStructureFilterCreateRequest;
import com.anthem.aciisst.account.web.view.request.SaveAccountStructureFilterRequest;
import com.anthem.aciisst.account.web.view.request.SaveAccountStructureFilterUpdateRequest;
import com.anthem.aciisst.account.web.view.response.SaveAccountStructureFilterCreateResponse;
import com.anthem.aciisst.account.web.view.response.SaveAccountStructureFilterResponse;
import com.anthem.aciisst.account.web.view.response.SaveAccountStructureFilterSearchResponse;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.exception.InvalidDataException;
import com.anthem.aciisst.common.util.DateUtil;
import com.anthem.aciisst.common.valueObject.CodeAndDescription;
import com.anthem.aciisst.persistence.dao.SaveAccountStructureFilterDAO;
import com.anthem.aciisst.persistence.dto.SaveFilterDTO;
import com.anthem.aciisst.persistence.dto.SaveFilterDtlDTO;

@Service
public class SaveAccountStructureFilterService {

	@Autowired
	SaveAccountStructureFilterDAO saveFilterDto;
	
	/**
	 * @param request
	 * @return List<SaveAccountStructureFilterSearchResponse>
	 * @throws SQLException
	 * 
	 * Get all Saved Filter from ACIISST_SAVE_FLTR table for given user id and account id
	 */
	public List<SaveAccountStructureFilterSearchResponse> searchSavedFilter(SaveAccountStructureFilterRequest request) throws SQLException {

		List<SaveFilterDTO> savedFilter = saveFilterDto.getSavedFiltersByAcctIdAndUserId(request.getAccountId(), request.getAciisstUserId());
		
		return savedFilter.stream()
						.map(s -> new SaveAccountStructureFilterSearchResponse(s.getId(), s.getName(), s.getDescription()))
						.collect(Collectors.toList());
	}
	
	/**
	 * @param saveFilterId
	 * @param aciisstUserId
	 * @return SaveAccountStructureFilterResponse
	 * @throws SQLException
	 * 
	 * Get a saved filter from ACIISST_SAVE_FLTR and ACIISST_SAVE_FLTR_DTL table for given user id and save filter id
	 */
	public SaveAccountStructureFilterResponse getSavedFilterDtls(int saveFilterId, int aciisstUserId) throws SQLException {
		List<SaveFilterDtlDTO> savedFilterList = saveFilterDto.getFilterDtlsById(saveFilterId, aciisstUserId);
		
		return prepareSaveFilterResponse(savedFilterList);
			
	}
	
	/**
	 * @param request
	 * @return SaveAccountStructureFilterCreateResponse
	 * @throws SQLException
	 * 
	 * Insert records in ACIISST_SAVE_FLTR and ACIISST_SAVE_FLTR_DTL table. 
	 */
	public SaveAccountStructureFilterCreateResponse createSaveFilter(SaveAccountStructureFilterCreateRequest request) throws SQLException {
		SaveAccountStructureFilterCreateResponse response = new SaveAccountStructureFilterCreateResponse();
		
		//Checking if Filter with same name is already exists.
		SaveFilterDTO dto = saveFilterDto.getSavedFilterByName(request.getAccountId(),request.getAciisstUserId(), request.getName());
		if(dto != null){
				throw new InvalidDataException("Filter already exists with this name. Please try again with different name.");
		}
		
		Timestamp currentTimestamp = DateUtil.getCurrentTimestamp();
		SaveFilterDTO filter = new SaveFilterDTO();
		filter.setName(request.getName());
		filter.setDescription(request.getDescription());
		filter.setTypeCd(request.getType());
		filter.setAcctId(request.getAccountId());
		filter.setActiveFlag(ACIISSTConstants.ACTV_FLG_Y);
		filter.setEffectiveDtm(currentTimestamp);
		filter.setTrmntnDtm(DateUtil.getHighEndDate());
		filter.setCreatdDtm(currentTimestamp);
		filter.setUpdtdDtm(currentTimestamp);
		filter.setCreatdByUserId(request.getAciisstUserId());
		filter.setUpdtdByUserId(request.getAciisstUserId());
		
		List<SaveFilterDtlDTO> filterDtlList = buildSaveFltrDtl(request, filter.getId(), currentTimestamp);
		saveFilterDto.addSaveFilter(filter, filterDtlList);

		response.setId(filter.getId());					
		
		return response;
	}
	
	/**
	 * @param request
	 * @return SaveAccountStructureFilterCreateResponse
	 * @throws SQLException
	 * 
	 * Update Filter Name and Description in ACIISST_SAVE_FLTR table
	 */
	public SaveAccountStructureFilterCreateResponse updateSavedFilter(SaveAccountStructureFilterUpdateRequest request, int filterId) throws SQLException {
		SaveAccountStructureFilterCreateResponse response = new SaveAccountStructureFilterCreateResponse();
		
		Timestamp currentTimestamp = DateUtil.getCurrentTimestamp();
		SaveFilterDTO filter = new SaveFilterDTO();
		
		filter.setId(filterId);
		filter.setName(request.getName());
		filter.setDescription(request.getDescription());
		filter.setUpdtdDtm(currentTimestamp);
		filter.setUpdtdByUserId(request.getAciisstUserId());
		filter.setCreatdByUserId(request.getAciisstUserId());
		
		saveFilterDto.updateSavedFilter(filter);
		
		response.setId(filterId);
		
		return response;
	}
	
	/**
	 * @param request
	 * @return SaveAccountStructureFilterCreateResponse
	 * @throws SQLException
	 * 
	 * Soft delete the existing record. Update ACTV_FLG to N and TRMNTN_DTM
	 */
	public SaveAccountStructureFilterCreateResponse deleteSavedFilter(int filterId, int aciisstUserId) throws SQLException {
		SaveAccountStructureFilterCreateResponse response = new SaveAccountStructureFilterCreateResponse();
		Timestamp currentTimestamp = DateUtil.getCurrentTimestamp();
		SaveFilterDTO filter = new SaveFilterDTO();
		
		filter.setId(filterId);
		filter.setActiveFlag(ACIISSTConstants.ACTV_FLG_N);
		filter.setTrmntnDtm(currentTimestamp);
		filter.setUpdtdDtm(currentTimestamp);
		filter.setUpdtdByUserId(aciisstUserId);
		filter.setCreatdByUserId(aciisstUserId);
		
		saveFilterDto.deleteSavedFilter(filter);
		
		response.setId(filterId);
		
		return response;
	}
	
	/**
	 * @param savedFilterList
	 * @return SaveAccountStructureFilterResponse
	 * 
	 * Create response structure for Save filter. This will contain all the records from ACIISST_SAVE_FLTR 
	 * and ACIISST_SAVE_FLTR_DTL table for the user and SAVE_FLTR_ID
	 */
	private SaveAccountStructureFilterResponse prepareSaveFilterResponse(List<SaveFilterDtlDTO> savedFilterList) {
		SaveAccountStructureFilterResponse response = new SaveAccountStructureFilterResponse();
		CodeAndDescription codeAndDesc = null;
		
		if (CollectionUtils.isEmpty(savedFilterList)){
			return null;
		}
		SaveFilterDtlDTO firstDto = savedFilterList.get(0);
		response.setId(firstDto.getSaveFltrId());
		response.setName(firstDto.getName());
		response.setDescription(firstDto.getDescription());
		response.setType(firstDto.getTypeCd());
		response.setAccountId(firstDto.getAcctId());
		response.setActive(ACIISSTConstants.ACTV_FLG_Y.equalsIgnoreCase(firstDto.getSaveFltrActiveFlag()) ? true : false);
		
		for(SaveFilterDtlDTO dto : savedFilterList){
			String paramName = dto.getFilterParamName();
			codeAndDesc = new CodeAndDescription();
			codeAndDesc.setCode(dto.getFilterCode());
			codeAndDesc.setDescription(dto.getFilterValue());
			
			if(ACIISSTConstants.GROUP.equalsIgnoreCase(paramName)){
				response.getGroups().add(codeAndDesc);
			} else if(ACIISSTConstants.SUBGROUP.equalsIgnoreCase(paramName)){
				response.getSubGroups().add(codeAndDesc);
			} else if(ACIISSTConstants.PRODUCT.equalsIgnoreCase(paramName)){
				response.getProducts().add(codeAndDesc);
			} else if(ACIISSTConstants.PACKAGE.equalsIgnoreCase(paramName)){
				response.getPackages().add(codeAndDesc);
			} else if(ACIISSTConstants.DEPARTMENT.equalsIgnoreCase(paramName)){
				response.getDepartments().add(codeAndDesc);
			} else if(ACIISSTConstants.STATUS.equalsIgnoreCase(paramName)){
				response.getStatus().add(codeAndDesc);
			} else if(ACIISSTConstants.SUBGROUPROLLUP1.equalsIgnoreCase(paramName)){
				response.getSubGroupRollup1().add(codeAndDesc);
			} else if(ACIISSTConstants.SUBGROUPROLLUP2.equalsIgnoreCase(paramName)){
				response.getSubGroupRollup2().add(codeAndDesc);
			} else if(ACIISSTConstants.SUBGROUPROLLUP3.equalsIgnoreCase(paramName)){
				response.getSubGroupRollup3().add(codeAndDesc);
			} else if(ACIISSTConstants.SUBGROUPROLLUP4.equalsIgnoreCase(paramName)){
				response.getSubGroupRollup4().add(codeAndDesc);
			} else if(ACIISSTConstants.EMPLOYERGROUPREPORTING1.equalsIgnoreCase(paramName)){
				response.getEmployerGroupReporting1().add(codeAndDesc);
			} else if(ACIISSTConstants.EMPLOYERGROUPREPORTING2.equalsIgnoreCase(paramName)){
				response.getEmployerGroupReporting2().add(codeAndDesc);
			} else if(ACIISSTConstants.EMPLOYERGROUPREPORTING3.equalsIgnoreCase(paramName)){
				response.getEmployerGroupReporting3().add(codeAndDesc);
			}
		}
		
		return response;
	}
	

	/**
	 * @param request
	 * @param filterId
	 * @param currentTimestamp
	 * @return List<SaveFilterDtlDTO>
	 * @throws SQLException
	 * 
	 *  Create SaveFltrDtl object from input request to add new filter details in ACIISST_SAVE_FLTR_DTL table
	 */
	private List<SaveFilterDtlDTO> buildSaveFltrDtl(SaveAccountStructureFilterCreateRequest request, int filterId, Timestamp currentTimestamp) throws SQLException{
		List<SaveFilterDtlDTO> filterDtlList = new ArrayList<>();
		
		if(!CollectionUtils.isEmpty(request.getGroups())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.GROUP, request.getAciisstUserId(), request.getGroups(), filterDtlList, currentTimestamp);
		}
		if(!CollectionUtils.isEmpty(request.getSubGroups())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.SUBGROUP, request.getAciisstUserId(), request.getSubGroups(), filterDtlList, currentTimestamp);
		}
		if(!CollectionUtils.isEmpty(request.getProducts())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.PRODUCT, request.getAciisstUserId(), request.getProducts(), filterDtlList, currentTimestamp);
		}
		if(!CollectionUtils.isEmpty(request.getPackages())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.PACKAGE, request.getAciisstUserId(), request.getPackages(), filterDtlList, currentTimestamp);
		}
		if(!CollectionUtils.isEmpty(request.getDepartments())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.DEPARTMENT, request.getAciisstUserId(), request.getDepartments(), filterDtlList, currentTimestamp);
		}
		if(!CollectionUtils.isEmpty(request.getStatus())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.STATUS, request.getAciisstUserId(), request.getStatus(), filterDtlList, currentTimestamp);
		}
		if(!CollectionUtils.isEmpty(request.getSubGroupRollup1())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.SUBGROUPROLLUP1, request.getAciisstUserId(), request.getSubGroupRollup1(), filterDtlList, currentTimestamp);
		}
		if(!CollectionUtils.isEmpty(request.getSubGroupRollup2())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.SUBGROUPROLLUP2, request.getAciisstUserId(), request.getSubGroupRollup2(), filterDtlList, currentTimestamp);
		}
		if(!CollectionUtils.isEmpty(request.getSubGroupRollup3())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.SUBGROUPROLLUP3, request.getAciisstUserId(), request.getSubGroupRollup3(), filterDtlList, currentTimestamp);
		}
		if(!CollectionUtils.isEmpty(request.getSubGroupRollup4())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.SUBGROUPROLLUP4, request.getAciisstUserId(), request.getSubGroupRollup4(), filterDtlList, currentTimestamp);
		}
		if(!CollectionUtils.isEmpty(request.getEmployerGroupReporting1())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.EMPLOYERGROUPREPORTING1, request.getAciisstUserId(), request.getEmployerGroupReporting1(), filterDtlList, currentTimestamp);
		}
		if(!CollectionUtils.isEmpty(request.getEmployerGroupReporting2())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.EMPLOYERGROUPREPORTING2, request.getAciisstUserId(), request.getEmployerGroupReporting2(), filterDtlList, currentTimestamp);
		}
		if(!CollectionUtils.isEmpty(request.getEmployerGroupReporting3())){
			prepareSaveFltrDtlDto(filterId, ACIISSTConstants.EMPLOYERGROUPREPORTING3, request.getAciisstUserId(), request.getEmployerGroupReporting3(), filterDtlList, currentTimestamp);
		}
		
		return filterDtlList;
		
	}
	
	/**
	 * @param filterId
	 * @param paramName
	 * @param aciisstUserId
	 * @param aFilterList
	 * @param filterDtlList
	 * @param currentTimestamp
	 * 
	 * Create SaveFltrDtl object from input request to add new filter details in ACIISST_SAVE_FLTR_DTL table.
	 */
	public void prepareSaveFltrDtlDto(int filterId, String paramName, int aciisstUserId, List<CodeAndDescriptionRequestView> aFilterList, List<SaveFilterDtlDTO> filterDtlList, Timestamp currentTimestamp){
		SaveFilterDtlDTO filterDtl = null;
		
		for(CodeAndDescriptionRequestView dto : aFilterList){
			filterDtl = new SaveFilterDtlDTO();
			filterDtl.setSaveFltrId(filterId);
			filterDtl.setFilterParamName(paramName);
			filterDtl.setFilterCode(dto.getCode());
			filterDtl.setFilterValue(dto.getDescription());
			filterDtl.setActvFlagCd(ACIISSTConstants.ACTV_FLG_Y);
			filterDtl.setCreatdDtm(currentTimestamp);
			filterDtl.setUpdtdDtm(currentTimestamp);
			filterDtl.setCreatdByUserId(aciisstUserId);
			filterDtl.setUpdtdByUserId(aciisstUserId);
			
			filterDtlList.add(filterDtl);
		}
	}
	
}