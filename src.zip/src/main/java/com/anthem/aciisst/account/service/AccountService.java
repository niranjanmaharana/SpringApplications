package com.anthem.aciisst.account.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.anthem.aciisst.account.web.view.response.AccountResponseView;
import com.anthem.aciisst.account.web.view.response.AccountStructureFilterResponseView;
import com.anthem.aciisst.account.web.view.response.AccountStructureRequest;
import com.anthem.aciisst.account.web.view.response.FeildValueDTO;
import com.anthem.aciisst.account.web.view.response.KpiDTO;
import com.anthem.aciisst.account.web.view.response.KpiValue;
import com.anthem.aciisst.account.web.view.response.SegmentKeyDTO;
import com.anthem.aciisst.account.web.view.response.UserSegmentRequest;
import com.anthem.aciisst.common.constants.ACIISSTConstants;
import com.anthem.aciisst.common.util.StringUtil;
import com.anthem.aciisst.filter.web.service.TimePeriodService;
import com.anthem.aciisst.filter.web.view.response.BenchmarkResponse;
import com.anthem.aciisst.persistence.dao.AccountDAO;
import com.anthem.aciisst.persistence.dao.AciisstAccntExmptDAO;
import com.anthem.aciisst.persistence.dao.AciisstDataAvailabiltyHistoryDAO;
import com.anthem.aciisst.persistence.dao.AppPropertyDAO;
import com.anthem.aciisst.persistence.dao.ClmsDashboardRepositoryDAO;
import com.anthem.aciisst.persistence.dao.MembershipDashboardRepositoryDAO;
import com.anthem.aciisst.persistence.dao.UserAccountAccessDAO;
import com.anthem.aciisst.persistence.dao.UserAccountSelectionDAO;
import com.anthem.aciisst.persistence.dao.UserDAO;
import com.anthem.aciisst.persistence.dto.AccountDTO;
import com.anthem.aciisst.persistence.dto.AciisstAccntExmptDTO;
import com.anthem.aciisst.persistence.dto.AppPropertyDTO;
import com.anthem.aciisst.persistence.dto.User;
import com.anthem.aciisst.persistence.dto.UserAccountAccessListDTO;
import com.anthem.aciisst.persistence.dto.UserAcctSlctnDTO;
import com.anthem.aciisst.user.service.UserService;

@Service
public class AccountService {
	@Autowired
	UserAccountAccessDAO userAccountAccessDAO;

	@Autowired
	UserService userService;

	@Autowired
	UserAccountSelectionDAO userAccountSelectionDAO;
	
	@Autowired
	TimePeriodService timePeriodService;
	
	@Autowired
	MembershipDashboardRepositoryDAO membershipDashbordRepositoryDao;
	
	@Autowired
	ClmsDashboardRepositoryDAO clmsDashboardRepositoryDao;
	@Autowired
	AccountDAO accountDao;
	
	@Autowired
	AciisstAccntExmptDAO aciisstAccntExmptDAO;
	
	@Autowired
	AppPropertyDAO appPropertyDAO;
	
	@Autowired
	AciisstDataAvailabiltyHistoryDAO dataAvaliHistDao;
	

	
	@Autowired
	UserDAO userDao;
	
	private static final Logger logger = LoggerFactory.getLogger(AccountService.class);

	/**
	 * @param userId
	 * @return recently accessed and all the accounts associated with user
	 * @throws SQLException 
	 */
	public List<AccountResponseView> getUserAccounts(String smUserId) throws SQLException {
		List<AccountResponseView> userAccounts = new LinkedList<>();

		User user = userDao.findByLognUserId(smUserId);
		if (user != null) {
			userAccounts.addAll(getAccountofUser(user));
			userAccounts.addAll(getRecentlyAccessedAccounts(user));
		}

		return userAccounts;

	}

	/**
	 * this method returns the all accounts associate with the user
	 * 
	 * @param userId
	 * @return
	 * @throws SQLException 
	 */
	public List<AccountResponseView> getAccountofUser(User user) throws SQLException {
		List<AccountDTO> accounts = null;
		List<AccountResponseView> respList = new ArrayList<>();
		
		
		if (user!=null && ACIISSTConstants.EXTERNAL_USER.equalsIgnoreCase(user.getUserCategoryCd().trim())) {

			accounts = accountDao.findUserAccounts(user.getLognUserId());
			respList.addAll(prepareAccountResponse(accounts, ACIISSTConstants.ALL_ACCOUNT));
		}

		return respList;

	}

	private List<AccountResponseView> prepareAccountResponse(List<AccountDTO> accounts, String key) throws SQLException {
		List<AccountResponseView> responseList = new ArrayList<>();
		
		if (!CollectionUtils.isEmpty(accounts)) {
			
			String lastCompleteMonthLoaded = timePeriodService.getDateAsMONyyyy(timePeriodService.getLastCompleteMonthLoaded());
			AciisstAccntExmptDTO aciisstAccntExmpt = null;
			
			
			AppPropertyDTO defaultValue = null;
			BenchmarkResponse benchmarkDefaultValue = null;
			String defaultMembershipBenchmark1Value = "";
			String defaultClinicalBenchmark1Value = "";
			String defaultMembershipBenchmarkSGValue = "";
			String defaultClinicalBenchmarkSGValue = "";
			String defaultCondDriverBenchmark1Value = "";
			String defaultCostUtilBenchmark1Value = "";
			String defaultProvNtwkBenchmark1Value = "";
			String defaultSpcltyBenchmark1Value = "";

			defaultValue = appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.MBRSHP_SMALL_ACCT_BENCHMARK);
			if(defaultValue!=null) {
				benchmarkDefaultValue = StringUtil.prepareBenchmark(defaultValue.getAciisstPrptyValTxt());
				defaultMembershipBenchmarkSGValue = benchmarkDefaultValue.getCode();
			}

			defaultValue = appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.MBRSHP_BENCHMARK1);
			if(defaultValue!=null) {
				benchmarkDefaultValue = StringUtil.prepareBenchmark(defaultValue.getAciisstPrptyValTxt());
				defaultMembershipBenchmark1Value = benchmarkDefaultValue.getCode();
			}
			defaultValue = appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.CLINICAL_BENCHMARK1);
			if(defaultValue!=null) {
				benchmarkDefaultValue = StringUtil.prepareBenchmark(defaultValue.getAciisstPrptyValTxt());
				defaultClinicalBenchmark1Value = benchmarkDefaultValue.getCode();
			}
			
			defaultValue = appPropertyDAO.getFilterValueFromAppProperty(ACIISSTConstants.CLINICAL_SMALL_ACCT_BENCHMARK);
			if(defaultValue!=null) {
				benchmarkDefaultValue = StringUtil.prepareBenchmark(defaultValue.getAciisstPrptyValTxt());
				defaultClinicalBenchmarkSGValue = benchmarkDefaultValue.getCode();
			}
			
			ListIterator<AccountDTO> itr = accounts.listIterator();
			while (itr.hasNext()) {
				AccountResponseView responseObj = new AccountResponseView();
				AccountDTO account = itr.next();
				responseObj.setAccountId(account.getAccountId());
				responseObj.setAccountName(account.getAccountName());
				responseObj.setKey(key);
				responseObj.setSubgroupRptg1LabelCode(!StringUtils.isEmpty(account.getSubgrpRptg1LblCd())
						? account.getSubgrpRptg1LblCd() : ACIISSTConstants.SUBGRPRPTG1LBLCD1);
				responseObj.setSubgroupRptg2LabelCode(!StringUtils.isEmpty(account.getSubgrpRptg2LblCd())
						? account.getSubgrpRptg2LblCd() : ACIISSTConstants.SUBGRPRPTG1LBLCD2);
				responseObj.setSubgroupRptg3LabelCode(!StringUtils.isEmpty(account.getSubgrpRptg3LblCd())
						? account.getSubgrpRptg3LblCd() : ACIISSTConstants.SUBGRPRPTG1LBLCD3);
				responseObj.setSubgroupRptg4LabelCode(!StringUtils.isEmpty(account.getSubgrpRptg4LblCd())
						? account.getSubgrpRptg4LblCd() : ACIISSTConstants.SUBGRPRPTG1LBLCD4);
				responseObj.setGrouppRptg1LabelCode(!StringUtils.isEmpty(account.getGrpRptg1LblCd())
						? account.getGrpRptg1LblCd() : ACIISSTConstants.GROUPRPTG1LABELCODE);
				responseObj.setGrouppRptg2LabelCode(!StringUtils.isEmpty(account.getGrpRptg2LblCd())
						? account.getGrpRptg2LblCd() : ACIISSTConstants.GROUPRPTG2LABELCODE);
				responseObj.setGrouppRptg3LabelCode(!StringUtils.isEmpty(account.getGrpRptg3LblCd())
						? account.getGrpRptg3LblCd() : ACIISSTConstants.GROUPRPTG3LABELCODE);					
				String hccAcctThresholdDefault = account.getDfltHccThrshldAmt() != null ? account.getDfltHccThrshldAmt().trim() : null;
				try {
					Integer.parseInt(hccAcctThresholdDefault);
				} catch (NumberFormatException e) {
					AppPropertyDTO defaultHccThresholdFilter = appPropertyDAO
	          				.getFilterValueFromAppProperty(ACIISSTConstants.DEFAULT_HCC_THRESHOLD_VALUE);                
	                 if (!ObjectUtils.isEmpty(defaultHccThresholdFilter)){	
	                	 hccAcctThresholdDefault = defaultHccThresholdFilter.getAciisstPrptyValTxt();
	                 }
				}
				responseObj.setDefaultHccThresholdAmount(hccAcctThresholdDefault);
				responseObj.setDisplayDept(account.getRptgDsplyDeptInd().equalsIgnoreCase("Y") ? true : false);
				responseObj.setDisplayGroupRptg1Code(account.getRptgDsplyGrpRptg1Cd().equalsIgnoreCase("Y") ? true : false);
				responseObj.setDisplayGroupRptg2Code(account.getRptgDsplyGrpRptg2Cd().equalsIgnoreCase("Y") ? true : false);
				responseObj.setDisplayGroupRptg3Code(account.getRptgDsplyGrpRptg3Cd().equalsIgnoreCase("Y") ? true : false);
				responseObj.setDisplayRlup1Code(account.getRptgDsplyRlup1Cd().equalsIgnoreCase("Y") ? true : false);
				responseObj.setDisplayRlup2Code(account.getRptgDsplyRlup2Cd().equalsIgnoreCase("Y") ? true : false);
				responseObj.setDisplayRlup3Code(account.getRptgDsplyRlup3Cd().equalsIgnoreCase("Y") ? true : false);
				responseObj.setDisplayRlup4Code(account.getRptgDsplyRlup4Cd().equalsIgnoreCase("Y") ? true : false);
				responseObj.setDisplayStatus(account.getRptgDsplySttsCd().equalsIgnoreCase("Y") ? true : false);//
				if(account.getAcctPlanMnthNbr()!=null && (account.getAcctPlanMnthNbr().intValue()<=12 && account.getAcctPlanMnthNbr().intValue()>=1)) {
					
					responseObj.setAccountPlanMonthNbr(account.getAcctPlanMnthNbr());
				}else {
					responseObj.setAccountPlanMonthNbr(Integer.valueOf(1));
				}
				if(account.getDfltTmPrdCd()!=null && !account.getDfltTmPrdCd().equalsIgnoreCase("NA")) {					
					responseObj.setAccountDefaultTmProdCode(account.getDfltTmPrdCd().toLowerCase());
				}else {
					responseObj.setAccountDefaultTmProdCode("r12m");
				}
				responseObj.setAccountSizeClassificationnCode(account.getAcctSizeClsfctnCd());				
				responseObj.setRptgBrandLogoCd(account.getRptgBrndLogoCd() != null ? account.getRptgBrndLogoCd().trim() : null);
				aciisstAccntExmpt =aciisstAccntExmptDAO.getAcctExmpt(account.getAccountId());				
				if(aciisstAccntExmpt != null){
					String rptgIncrdIndCd = aciisstAccntExmpt.getRptgIncrdIndCd() == null ? null: aciisstAccntExmpt.getRptgIncrdIndCd().trim();
					responseObj.setAccount_3061_ind("Y".equalsIgnoreCase(rptgIncrdIndCd)?ACIISSTConstants.ACCOUNT_3061_IND_Y:ACIISSTConstants.ACCOUNT_3061_IND_N);
				}
				
				if(ACIISSTConstants.ACCOUNT_3061_IND_Y.equalsIgnoreCase(responseObj.getAccount_3061_ind())){
					responseObj.setPaidOrIncured(ACIISSTConstants.INCURRED);
				}else{
					responseObj.setPaidOrIncured(ACIISSTConstants.PAID);
				}
				
				responseObj.setLastCompleteMonthLoaded(lastCompleteMonthLoaded);
				
				if ("SMALL".equalsIgnoreCase(account.getAcctSizeClsfctnCd())) {
					responseObj.setDefaultClinicalBenchmark1Value(defaultClinicalBenchmarkSGValue);
					responseObj.setDefaultCondDriverBenchmark1Value(defaultCondDriverBenchmark1Value);
					responseObj.setDefaultCostUtilBenchmark1Value(defaultCostUtilBenchmark1Value);
					responseObj.setDefaultMembershipBenchmark1Value(defaultMembershipBenchmarkSGValue);
					responseObj.setDefaultProvNtwkBenchmark1Value(defaultProvNtwkBenchmark1Value);
					responseObj.setDefaultSpcltyBenchmark1Value(defaultSpcltyBenchmark1Value);
				}else{
					responseObj.setDefaultClinicalBenchmark1Value(defaultClinicalBenchmark1Value);
					responseObj.setDefaultCondDriverBenchmark1Value(defaultCondDriverBenchmark1Value);
					responseObj.setDefaultCostUtilBenchmark1Value(defaultCostUtilBenchmark1Value);
					responseObj.setDefaultMembershipBenchmark1Value(defaultMembershipBenchmark1Value);
					responseObj.setDefaultProvNtwkBenchmark1Value(defaultProvNtwkBenchmark1Value);
					responseObj.setDefaultSpcltyBenchmark1Value(defaultSpcltyBenchmark1Value);
				}
				responseList.add(responseObj);
			}
		}
		return responseList;

	}

	/**
	 * this method returns the recently accessed accounts for the user
	 * 
	 * @param UserId
	 * @return
	 * @throws SQLException 
	 */
	public List<AccountResponseView> getRecentlyAccessedAccounts(User user) throws SQLException {
		List<AccountDTO> userRecentAcctList;
		List<AccountResponseView> responseList = new ArrayList<>();

		if (ACIISSTConstants.EXTERNAL_USER.equalsIgnoreCase(user.getUserCategoryCd().trim())) {
			userRecentAcctList = accountDao.getRecentlyAccessedAccountForExternalUser(user.getUserId());
		}else {
			
			userRecentAcctList =accountDao.getRecentlyAccessedAccountForInternalUser(user.getUserId());
		}
		
		if(!CollectionUtils.isEmpty(userRecentAcctList)) {
			
			logger.info("AccountService - start of method - getRecentlyAccessedAccounts Size- {}",
					userRecentAcctList.size());
			
			responseList=prepareAccountResponse(
					userRecentAcctList.subList(0, (userRecentAcctList.size()) < 10 ? userRecentAcctList.size() : 10),
					ACIISSTConstants.RECENTLY_ACCESSED);
		}


		return responseList;
	}

	/**
	 * Method for Account Structure Search
	 * 
	 * @param searchStr
	 * @param smUserId
	 * 
	 * @return
	 * @throws SQLException 
	 */
	public List<AccountResponseView> accountSearch(String smUserId, String searchStr) throws SQLException {
		List<AccountDTO> accounts = null;
		List<AccountResponseView> respList = new ArrayList<>();
		User user = userDao.findByLognUserId(smUserId);

		if (!ObjectUtils.isEmpty(user) && (ACIISSTConstants.INTERNAL_USER
				.equalsIgnoreCase(user.getUserCategoryCd().trim()))) {
			
			accounts = accountDao.getInternalUserAccountsWithSearch(user.getLognUserId(), searchStr.toLowerCase());
			respList.addAll(prepareAccountResponse(accounts, ACIISSTConstants.ALL_ACCOUNT));
			logger.info("Get Account For Internal User- {} RespList size- {} ", user.getLognUserId(), respList.size());
		}
		return respList;
	}

	/**
	 * method update the recently accessed accounts for the user
	 * 
	 * @param UserId
	 * @return
	 * @throws SQLException 
	 */
	public int updateRecentlyAccessedAccounts(String userId, String acctId) throws SQLException {
		
		User user = userDao.findByLognUserId(userId);
		if(user!=null) {
			UserAcctSlctnDTO userAcctSlc=userAccountSelectionDAO.getRecentlyAccessed(acctId, user.getUserId());
			if(userAcctSlc!=null) {
				return	userAccountSelectionDAO.updateRecentlyAccessed(acctId, user.getUserId());
			}else {
				return userAccountSelectionDAO.saveRecentlyAccessed(acctId,user.getUserId());
			}
		}
		return -1;

	}

	/**
	 * Method will return All accounts which is assigned to user with security
	 * code Y
	 * 
	 * @param userId
	 * @return
	 */
	/*public List<AccountResponseView> getInternalUserSplAccountDrop(String userId) {

		List<UserAccountAccessList> internalUserSpecialAcct = userAccountAccessRepository
				.getInternalUserSpecialAccounts(userId);

		return internalUserSpecialAcct.stream().map(a -> new AccountResponseView(a.getAccount().getAccountId(),
				a.getAccount().getAccountName(), ACIISSTConstants.ALL_ACCOUNT)).collect(Collectors.toList());

	}*/

	/**
	 * Method wil return All the active accounts by checking termination date
	 * for the account
	 * 
	 * @return
	 * @throws SQLException 
	 */
	/*public List<AccountResponseView> getAllActiveAccounts() {

		List<Account> accounts = accountRepository.findAllactiveAccount();
		return accounts.stream().map(s -> new AccountResponseView(s.getAccountId(), s.getAccountName(),
				s.getAcctEfctvDt(), s.getAcctTrmntnDt())).collect(Collectors.toList());
	}*/

	public List<AccountStructureFilterResponseView> getAccountStructureFilter(AccountStructureRequest request,
			String requiredFilter) throws SQLException {
		List<Object[]> accountStructureFilters = accountDao.getAccountStructureFilters(request, requiredFilter,
				isExternalSecurityGroupFlag(request));
		List<AccountStructureFilterResponseView> responseList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(accountStructureFilters)) {
			if (!requiredFilter.equalsIgnoreCase(ACIISSTConstants.SUBGRPRLUP_STATUS)) {
				AccountStructureFilterResponseView allOption = new AccountStructureFilterResponseView(
						ACIISSTConstants.ALL_SELECTED, ACIISSTConstants.ALL_SELECTED);
				responseList.add(allOption);
			}
			ListIterator<Object[]> itr = accountStructureFilters.listIterator();
			while (itr.hasNext()) {
				AccountStructureFilterResponseView filter = new AccountStructureFilterResponseView();
				Object[] filterObj = itr.next();
				filter.setCode((String) filterObj[0]);
				filter.setDescription((String) filterObj[1]);
				responseList.add(filter);
			}
		}

		return responseList;
	}

	/*public List<String> getAccountStructureFilterForExport(String accountId, String sessionKey, String userId,
			String requiredFilter) {
		User user = userRepository.getUserDetails(userId);
		List<Object[]> accountStructureFilters = accountRepository.getAccountStructureFiltersForExport(accountId,
				sessionKey, user.getUserId(), requiredFilter);
		List<String> responseList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(accountStructureFilters)) {
			ListIterator<Object[]> itr = accountStructureFilters.listIterator();
			while (itr.hasNext()) {
				Object[] filterObj = itr.next();
				if (!StringUtils.isEmpty((String) filterObj[1]))
					responseList.add((String) filterObj[1]);
			}
		}
		return responseList;
	}*/

	private boolean isExternalSecurityGroupFlag(AccountStructureRequest request) throws SQLException {
		boolean externalGrpSecurityInd = false;
		User user = userDao.findByLognUserId(request.getUserId());
		
		if (ACIISSTConstants.EXTERNAL_USER.equals(user.getUserCategoryCd().trim())) {
			UserAccountAccessListDTO accountAccess = userAccountAccessDAO.findOneActive(request.getAccountId(),
					user.getUserId());
			if (accountAccess != null) {
				String groupSecurityFlag;
				groupSecurityFlag = accountAccess.getGrpScrtyFlag().trim();
				if (ACIISSTConstants.TRUE_FLAG.equals(groupSecurityFlag)) {
					externalGrpSecurityInd = true;
				}
			}
		}
		return externalGrpSecurityInd;
	}

	public String updateUserSegmentKeys(AccountStructureRequest request, String requiredFilter) throws Exception {
		String message = "Segment keys not found for account id = " + request.getAccountId();
		List<SegmentKeyDTO> segmentKeys = new ArrayList<>();
		UserSegmentRequest userSegmentRequest = new UserSegmentRequest();
		
		List<Object[]> accountStructureFilters = accountDao.getAccountStructureFilters(request, requiredFilter, isExternalSecurityGroupFlag(request));
		if (!CollectionUtils.isEmpty(accountStructureFilters)) {
			message = "Successfully added Segment keys for account id = " + request.getAccountId();
			ListIterator<Object[]> itr = accountStructureFilters.listIterator();

			while (itr.hasNext()) {
				Object[] filterObj = itr.next();
				SegmentKeyDTO segmentKeyDto = new SegmentKeyDTO();
				segmentKeyDto.setKey((int) filterObj[0]);
				segmentKeys.add(segmentKeyDto);
			}
		}
		userSegmentRequest.setAccountId(request.getAccountId());
		userSegmentRequest.setUserId(request.getUserId());
		userSegmentRequest.setSessionKey(request.getSessionKey());
		userSegmentRequest.setSegmentKeys(segmentKeys);
		User user = userDao.findByLognUserId(userSegmentRequest.getUserId());

		accountDao.addUserSegment(userSegmentRequest, user);
			
		return message;
	}

	

	public String getUniqueId() {		
		return  UUID.randomUUID().toString();
	}

	/**
	 * @param searchKey
	 * @param searchValue
	 * @param smUserId
	 * @return
	 */
	/*public List<AccountResponseView> searchAccount(String searchKey, String searchValue, String smUserId) {
		final String pattern = searchValue.toLowerCase();
		List<Account> accounts = new ArrayList<>();
		switch (searchKey) {
		case ACIISSTConstants.ACCOUNT_ID:
			accounts = accountRepository.searchInactiveAccountsForUserByID(pattern, smUserId);
			break;
		case ACIISSTConstants.ACCOUNT_NAME:
			accounts = accountRepository.searchInactiveAccountsForUserByName(pattern, smUserId);
			break;
		default:
			break;
		}
		return accounts.stream().map(s -> new AccountResponseView(s.getAccountId(), s.getAccountName(),
				s.getAcctEfctvDt(), s.getAcctTrmntnDt())).collect(Collectors.toList());

	}
*/
	public List<FeildValueDTO> setData(List<Object[]> dataList) {

		List<FeildValueDTO> data = new ArrayList<>();
		if (!CollectionUtils.isEmpty(dataList)) {
			ListIterator<Object[]> itr = dataList.listIterator();
			FeildValueDTO value1 = new FeildValueDTO();
			value1.setValue(ACIISSTConstants.ALL_CAMELCASE);
			data.add(value1);
			while (itr.hasNext()) {
				FeildValueDTO value = new FeildValueDTO();
				Object filter = itr.next();
				StringBuilder sb = new StringBuilder();
				value.setValue(sb.append("").append(filter).toString());
				data.add(value);
			}

		}
		return data;

	}

	
	public String getRunOutMonths(String endDate,KpiDTO request) {
		if(endDate!=null) {
			
			Calendar timePeriodEndDate = Calendar.getInstance();
			String crEndmm = endDate.length() > 2 ? endDate.substring(endDate.length() - 2) : endDate;
			String crEndyyyy = endDate.length() > 4 ? endDate.substring(0, endDate.length() - 2) : endDate;
			
			int crEndMonthinMM = Integer.parseInt(crEndmm);
			int crEndYear = Integer.parseInt(crEndyyyy);		
			timePeriodEndDate.set(Calendar.MONTH, crEndMonthinMM);
			timePeriodEndDate.set(Calendar.YEAR, crEndYear);
			timePeriodEndDate.add(Calendar.MONTH, -1);
			
			int runoutMonthInt = 0;
			String runOutMonthsStr = request.getRunOutMonths();
			if(!StringUtils.isEmpty(runOutMonthsStr)){
				runoutMonthInt = Integer.parseInt(runOutMonthsStr);
			}
			timePeriodEndDate.add(Calendar.MONTH, -runoutMonthInt);
			return timePeriodEndDate.get(Calendar.YEAR) + String.format("%02d", (timePeriodEndDate.get(Calendar.MONTH) + 1));
		}
		return null;
	}
	
public KpiValue getFinancialKPIDetails(KpiDTO request) throws SQLException {
	KpiValue value = new KpiValue();
		DecimalFormat dformat = new DecimalFormat("0.0");
		
		if(ACIISSTConstants.ACCOUNT_3061_IND_Y.equalsIgnoreCase(request.getAccount_3061_ind()) && ACIISSTConstants.INCURRED.equalsIgnoreCase(request.getPaidOrIncured())) {
			Calendar timePeriodEndDate = Calendar.getInstance();
			Date dataThrougDate = dataAvaliHistDao.getDataAvailabilityHistory();
			if (dataThrougDate != null) {
				timePeriodEndDate.setTimeInMillis(dataThrougDate.getTime());
			}else {
				timePeriodEndDate.add(Calendar.MONTH, -1);//get prior completed month
			}
			String endDate= timePeriodEndDate.get(Calendar.YEAR) + String.format("%02d", (timePeriodEndDate.get(Calendar.MONTH) + 1));
			request.setLastCompleteMonthDate(endDate);
		}else if(ACIISSTConstants.ACCOUNT_3061_IND_N.equalsIgnoreCase(request.getAccount_3061_ind()) && ACIISSTConstants.INCURRED.equalsIgnoreCase(request.getPaidOrIncured())) {
			request.setCurrRptgEndDate(getRunOutMonths(request.getCurrentPeriodEnd(),request));
			request.setPrior1RptgEndDate(getRunOutMonths(request.getPriorPeriod1End(),request));
			request.setPrior2RptgEndDate(getRunOutMonths(request.getPriorPeriod2End(),request));
		}
		
		List<List<String>> kpiData = clmsDashboardRepositoryDao.getTotalPMPM(request);		
		
		BigDecimal avgCurrPMPM = null;
		BigDecimal avgPrior1PMPM = null;
		BigDecimal avgPrior2PMPM = null;
		BigDecimal trend = BigDecimal.ZERO;		
		
		
		//ListIterator<Object[]> itr = kpiData.listIterator();
		ListIterator<List<String>> itr = kpiData.listIterator();
		while (itr.hasNext()) {
			List<String> data = itr.next();	
			
			if (ACIISSTConstants.KPI_CUR_PMPM.equalsIgnoreCase(data.get(0))) {
				avgCurrPMPM = new BigDecimal(data.get(3));
				if (avgCurrPMPM.compareTo(BigDecimal.ZERO) != 0){
					value.setCurr_data(avgCurrPMPM.setScale(2, RoundingMode.HALF_UP).toString());
				}else
					value.setCurr_data(null);
				
			}else if (ACIISSTConstants.KPI_PRIOR1_PMPM.equalsIgnoreCase(data.get(0))) {
				avgPrior1PMPM = new BigDecimal(data.get(3));
				if (avgPrior1PMPM.compareTo(BigDecimal.ZERO) != 0){
					value.setPrior1_data(avgPrior1PMPM.setScale(2, RoundingMode.HALF_UP).toString());
				}else
					value.setPrior1_data(null);
				
			}else if (ACIISSTConstants.KPI_PRIOR2_PMPM.equalsIgnoreCase(data.get(0))) {
				avgPrior2PMPM = new BigDecimal(data.get(3));
				if (avgPrior2PMPM.compareTo(BigDecimal.ZERO) != 0){
					value.setPrior2_data(avgPrior2PMPM.setScale(2, RoundingMode.HALF_UP).toString());
				}else
					value.setPrior2_data(null);				
			}			
		}

		if ((avgCurrPMPM != null && avgPrior1PMPM != null) && (avgCurrPMPM.compareTo(BigDecimal.ZERO) != 0 && avgPrior1PMPM.compareTo(BigDecimal.ZERO) != 0)){

			trend = (avgCurrPMPM.subtract(avgPrior1PMPM)).equals(BigDecimal.ZERO) ? BigDecimal.ZERO
					: (avgCurrPMPM.subtract(avgPrior1PMPM).multiply(new BigDecimal(100))).divide(avgPrior1PMPM, 2, RoundingMode.HALF_UP);
		}
		else if ((avgCurrPMPM != null && avgPrior2PMPM != null) && (avgCurrPMPM.compareTo(BigDecimal.ZERO) != 0 && avgPrior2PMPM.compareTo(BigDecimal.ZERO) != 0)){

			trend = (avgCurrPMPM.subtract(avgPrior2PMPM)).equals(BigDecimal.ZERO) ? BigDecimal.ZERO
					: (avgCurrPMPM.subtract(avgPrior2PMPM).multiply(new BigDecimal(100))).divide(avgPrior2PMPM, 2, RoundingMode.HALF_UP);
		}
		trend = new BigDecimal(dformat.format(trend));
		
		if (avgCurrPMPM != null && avgCurrPMPM.compareTo(BigDecimal.ZERO) != 0) {
			value.setValue("$" + ((avgCurrPMPM.setScale(2, RoundingMode.HALF_UP)).toString()));		
		} else {
			value.setValue(null);
		}
		value.setKey(ACIISSTConstants.KPI_TOTAL_PMPM);
		
		if (trend.compareTo(BigDecimal.ZERO) < 0) {

			value.setSymbol(ACIISSTConstants.KPI_DOWN_SYMBOL);
		} else {

			value.setSymbol(ACIISSTConstants.KPI_UP_SYMBOL);
		}
		value.setDescription(dformat.format(Math.abs(trend.doubleValue())) + "%");
		return value;
	}
	

	public KpiValue getClinicalKpi(KpiDTO request) throws SQLException {
		
		DecimalFormat dformat = new DecimalFormat("0.0");

		//List<Object[]> kpiData = membershipDashbordRepository.getClinicalKpi(request);
		List<List<String>> kpiData = membershipDashbordRepositoryDao.getClinicalKpi(request);
		
		int currMonthsTotal = 0;
		int prior1MonthsTotal = 0;
		int prio2MonthsTotal = 0;
		BigDecimal currTotalRiskScore = BigDecimal.ZERO;
		BigDecimal prior1TotalRiskScore = BigDecimal.ZERO;
		BigDecimal prior2TotalRiskScore = BigDecimal.ZERO;
		
		
		BigDecimal trend = BigDecimal.ZERO;
		
		KpiValue value = new KpiValue();
		//ListIterator<Object[]> itr = kpiData.listIterator();
		ListIterator<List<String>> itr = kpiData.listIterator();
		
		while (itr.hasNext()) {
			List<String> data = itr.next();			
			
			// adding total for each time periods (current, prior1, prior2)
			try {
				int month = Integer.parseInt(data.get(0));
				BigDecimal riskScore = new BigDecimal(data.get(1));
				int totalMonth = Integer.parseInt(data.get(2));

				if (month >= Integer.parseInt(request.getCurrentPeriodStart()) && month <= Integer.parseInt(request.getCurrentPeriodEnd())) {
					currTotalRiskScore= currTotalRiskScore.add(riskScore);
					currMonthsTotal += totalMonth;
				}
				else if (month >= Integer.parseInt(request.getPriorPeriod1Start()) && month <= Integer.parseInt(request.getPriorPeriod1End())) {
					prior1TotalRiskScore= prior1TotalRiskScore.add(riskScore);
					prior1MonthsTotal += totalMonth;
				}
				else if (month >= Integer.parseInt(request.getPriorPeriod2Start()) && month <= Integer.parseInt(request.getPriorPeriod2End())) {
					prior2TotalRiskScore= prior2TotalRiskScore.add(riskScore);
					prio2MonthsTotal += totalMonth;
				}
			} catch (NumberFormatException e) {
				logger.debug("Exception :{} ",e);
			}
		}
		BigDecimal avgCurrRiskScore = null;
		if (currMonthsTotal != 0){
			avgCurrRiskScore = (currTotalRiskScore.divide(new BigDecimal(currMonthsTotal), 2, RoundingMode.HALF_UP));
			value.setCurr_data(avgCurrRiskScore.toString());
		}
		
		BigDecimal avgPrior1RiskScore = null;
		if (prior1MonthsTotal != 0){		
			avgPrior1RiskScore = (prior1TotalRiskScore.divide(new BigDecimal(prior1MonthsTotal), 2, RoundingMode.HALF_UP));
			value.setPrior1_data(avgPrior1RiskScore.toString());
		}
		BigDecimal avgPrior2RiskScore = null;
		if (prio2MonthsTotal != 0){	
			avgPrior2RiskScore = (prior2TotalRiskScore.divide(new BigDecimal(prio2MonthsTotal), 2, RoundingMode.HALF_UP));
			value.setPrior2_data(avgPrior2RiskScore.toString());
		}
		
		if (avgCurrRiskScore !=null && avgPrior1RiskScore != null) {

			trend = (avgCurrRiskScore.subtract(avgPrior1RiskScore)).equals(BigDecimal.ZERO) ? BigDecimal.ZERO
					: (avgCurrRiskScore.subtract(avgPrior1RiskScore).multiply(new BigDecimal(100))).divide(avgPrior1RiskScore, 2, RoundingMode.HALF_UP);
		}
		else if (avgCurrRiskScore != null && avgPrior2RiskScore != null) {
			trend = (avgCurrRiskScore.subtract(avgPrior2RiskScore)).equals(BigDecimal.ZERO) ? BigDecimal.ZERO
					: (avgCurrRiskScore.subtract(avgPrior2RiskScore).multiply(new BigDecimal(100))).divide(avgPrior2RiskScore, 2, RoundingMode.HALF_UP);
		}
		trend = new BigDecimal(dformat.format(trend));
		if (avgCurrRiskScore != null) {
			value.setValue(avgCurrRiskScore.toString());
		} else {
			value.setValue(null);			
		}
		value.setKey(ACIISSTConstants.KPI_CLINICAL);
		
		if (trend.compareTo(BigDecimal.ZERO) < 0) {

			value.setSymbol(ACIISSTConstants.KPI_DOWN_SYMBOL);
		} else {

			value.setSymbol(ACIISSTConstants.KPI_UP_SYMBOL);

		}
		value.setDescription(dformat.format(Math.abs(trend.doubleValue())) + "%");
		return value;
		
	}

	public List<Map<String, String>> getAppProperties() throws SQLException {
		List<AppPropertyDTO> properties = appPropertyDAO.findAll();
		List<Map<String, String>> propList = new ArrayList<>();
		Map<String, String> aciisstPropertiesMap = properties.stream()
				.collect(Collectors.toMap(AppPropertyDTO::getAciisstPrptyNm, AppPropertyDTO::getAciisstPrptyValTxt));
		propList.add(aciisstPropertiesMap);
		return propList;
	}

	public List<FeildValueDTO> setFilterData(List<String> dataList) {

		List<FeildValueDTO> data = new ArrayList<>();
		if (!CollectionUtils.isEmpty(dataList)) {
			ListIterator<String> itr = dataList.listIterator();
			while (itr.hasNext()) {
				FeildValueDTO value = new FeildValueDTO();
				Object filter = itr.next();
				StringBuilder sb = new StringBuilder();
				value.setValue(sb.append(filter).toString());
				data.add(value);
			}

		}
		return data;

	}

	public List<AccountStructureFilterResponseView> getContractTierValues() throws SQLException {
		List<AccountStructureFilterResponseView> responseList = new ArrayList<>();
		AppPropertyDTO contractTierFilters = appPropertyDAO
				.getFilterValueFromAppProperty(ACIISSTConstants.CONTRACT_TIER_LVL_FILTER);
		if (!ObjectUtils.isEmpty(contractTierFilters)) {
			// Prepare Key value response from String in format
			// All|All;1-17|1-17;18-26|18-26
			responseList = StringUtil
					.setCodeDescValuesForFilters(Arrays.asList(contractTierFilters.getAciisstPrptyValTxt().split(";")));
		}
		return responseList;
	}
	/*
	 * Returns the modules for the respective Account
	 * @param accountId
	 * @return String
	 * 
	 */
	public String generateModule(String accountId) {
		
		String msg = null;
	      JSONArray array = new JSONArray();
		
	      try {
	          if(accountId!= null){	    	    
	     	 
	    	  JSONObject obj = new JSONObject();
	    	  obj.put("module", "membership");
	    	  obj.put("enabled", true);
	    	  array.put(obj);
	    	 
	    	  JSONObject obj1 = new JSONObject();
	    	  obj1.put("module", "condition");
	    	  obj1.put("enabled", true);
	    	  array.put(obj1);
	    	  
	    	  JSONObject obj2 = new JSONObject();
	    	  obj2.put("module", "financialcost");
	    	  obj2.put("enabled", true);
	    	  array.put(obj2);
	    	  
	    	  JSONObject obj3 = new JSONObject();
	    	  obj3.put("module", "clinical");
	    	  obj3.put("enabled", true);
	    	  array.put(obj3);
	    	  
	    	  JSONObject obj4 = new JSONObject();
	    	  obj4.put("module", "provider");
	    	  obj4.put("enabled", true);
	    	  array.put(obj4);
	    	  
	    	  JSONObject obj5 = new JSONObject();
	    	  obj5.put("module", "pharmacy");
	    	  obj5.put("enabled", true);
	    	  array.put(obj5);
	    	  
	    	  JSONObject obj6 = new JSONObject();
	    	  obj6.put("module", "medrx");
	    	  obj6.put("enabled", false);
	    	  array.put(obj6);
	    	  
	    	  JSONObject obj7 = new JSONObject();
	    	  obj7.put("module", "totalhealth");
	    	  obj7.put("enabled", false);
	    	  array.put(obj7);
	    	  
	    	  JSONObject obj8 = new JSONObject();
	    	  obj8.put("module", "anthemonthego");
	    	  obj8.put("enabled", false);
	    	  array.put(obj8);
	    	  
	    	  JSONObject obj9 = new JSONObject();
	    	  obj9.put("module", "soladvisor");
	    	  obj9.put("enabled", false);
	    	  array.put(obj9);
	    	  
	    	  JSONObject obj10 = new JSONObject();
	    	  obj10.put("module", "executive");
	    	  obj10.put("enabled", true);
	    	  array.put(obj10);
	       	  msg = array.toString();
	       	  
	       	  
			
		} }
	          catch (JSONException e) {
			
			e.printStackTrace();
		}

	      System.out.print(msg);
	      return msg;
	   }
	

}
