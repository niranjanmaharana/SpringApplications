package com.anthem.aciisst.account.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anthem.aciisst.persistence.dao.UserSegmentDAO;

@Service
public class UserSegmentService {
	
	@Autowired
	UserSegmentDAO userSegmentDAO;
	
	public void deleteFromUserSegment(String sesnId, int aciisstUserId) throws SQLException{
		userSegmentDAO.deleteUserSegment(sesnId, aciisstUserId);
	}
}
